# BeraTalk UI/UX QA — v1.2.0-ui

## Interaction model
- Fixed bottom navigation; no swipe-driven main tabs.
- Progressive sign-in/setup with one decision at a time.
- Home has one dominant mission surface and real activity counts only.
- Learn exposes one current task, then transitions to the next.
- Chat is the real partner voice thread, not a simulated conversation.
- Library distinguishes Draft vs Native confirmed material.
- Us uses only real pair/activity/progress state.

## Real motion
- Setup step transitions use `AnimatedContent`.
- Main-tab content crossfades.
- Mission progress animates as persisted tasks complete.
- AI/building state has a continuously animated progress sweep and presence pulse.
- Learn tasks transition with `AnimatedContent`.
- AI coach response appears with animated visibility.
- Recording controls pulse and render live microphone amplitude.
- Voice playback animates its active state.
- Timed conversation challenges count down and refresh when complete.

These animations are tied to runtime state; they are not looping decorative GIFs or fixed fake waveforms.

## Visual system
- Pure white `#FFFFFF` page canvas and ordinary card surfaces.
- Near-black `#0D0D0F` primary text and readable `#6F6F78` secondary text.
- Default accent is violet with pink support; selectable Cobalt, Emerald and Tangerine themes are available in Settings.
- Accent is concentrated in selected navigation, primary buttons, progress and hero panels.
- Ordinary content cards remain white with subtle borders and 6–10dp elevation.
- The selected bottom-tab icon sits in a filled circular accent control with a white glyph.
- 20–24dp outer spacing, generous vertical rhythm and 22–30dp corner radii keep screens open and organized.
- The brand mark and BeraTalk wordmark are black; the launcher uses a bold abstract lowercase `bt` monogram on white.

## Placeholder regression checks
R7 fails before compilation if it finds `DemoData`, `FakeWave`, `PartnerVoiceBubble`, `preview-pair`, `BERA01`, or an empty `onClick = {}` in app runtime source.


## 1.2.0-ui reference-driven redesign
- Pure white app canvas and white elevated cards; no off-white page background.
- Default Violet palette with user-selectable Violet, Cobalt, Emerald and Tangerine themes in Settings.
- Custom bottom navigation uses a colored circular selected icon with a white glyph, inspired by the supplied transit-app reference.
- Stronger 6–10dp card elevation, larger rounded corners, consistent 18–24dp screen spacing and clearer hierarchy.
- Home, Learn, Chat challenge and Us hero surfaces use controlled accent gradients; ordinary cards remain white.
- Black BeraTalk wordmark and bold abstract lowercase bt monogram replace the former multicolor speech-wave logo.
- Launcher icon is a black lowercase bt monogram on white.
- Theme changes persist locally and apply immediately to buttons, progress, selected tabs, hero panels and accent states.
- Existing real AI, Firestore, audio, verification and adaptive-learning behavior is preserved.
