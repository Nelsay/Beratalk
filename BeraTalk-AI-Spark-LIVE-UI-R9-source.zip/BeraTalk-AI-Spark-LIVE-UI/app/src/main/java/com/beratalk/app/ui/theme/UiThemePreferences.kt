package com.beratalk.app.ui.theme

import android.content.Context

class UiThemePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("beratalk_ui", Context.MODE_PRIVATE)

    fun loadTheme(): BeraUiTheme = BeraUiTheme.fromKey(prefs.getString("theme", null))

    fun saveTheme(theme: BeraUiTheme) {
        prefs.edit().putString("theme", theme.key).apply()
    }
}
