package com.beratalk.app.data

import android.content.Context
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.LessonTask
import com.beratalk.app.model.LessonTaskType
import com.beratalk.app.model.Mission

/**
 * AI may organize, sequence and explain lessons, but it must not invent minority-language
 * translations. Native-language phrases must come from verified language-bank entries.
 */
interface LessonEngine {
    suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String> = emptyList()
    ): Mission
}

class HybridAiLessonEngine(context: Context) : LessonEngine {
    private val router = AiClientRouter(context)
    private val fallback = SafeLocalLessonEngine()

    fun hasLiveAi(): Boolean = router.isConfigured()

    override suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission {
        return router.buildMission(learningLanguage, verifiedEntries, recentWeaknesses)
            ?: fallback.buildMission(learningLanguage, verifiedEntries, recentWeaknesses)
    }
}

class SafeLocalLessonEngine : LessonEngine {
    override suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission {
        val usable = verifiedEntries.filter { it.verified && it.language.equals(learningLanguage, true) }
        val withAudio = usable.filter { !it.audioPath.isNullOrBlank() }
        val first = usable.firstOrNull()
        val second = usable.drop(1).firstOrNull() ?: first

        val tasks = buildList {
            if (withAudio.isNotEmpty()) {
                add(
                    LessonTask(
                        type = LessonTaskType.LISTEN,
                        title = "Hear the real voice first",
                        instruction = "Play your partner's recording twice. Listen for rhythm before looking at the meaning.",
                        entryId = withAudio.first().id,
                        durationSeconds = 45
                    )
                )
            }
            if (first != null) {
                add(
                    LessonTask(
                        type = LessonTaskType.RECALL,
                        title = "Recall it before revealing the answer",
                        instruction = "Look at the verified phrase and try to remember what it means. Reveal only after you commit to an answer.",
                        entryId = first.id,
                        durationSeconds = 45
                    )
                )
                add(
                    LessonTask(
                        type = LessonTaskType.SPEAK,
                        title = "Say it with your own voice",
                        instruction = "Say the verified phrase aloud, then compare yourself with your partner's real recording if one exists.",
                        entryId = second?.id,
                        durationSeconds = 60
                    )
                )
            } else {
                add(
                    LessonTask(
                        type = LessonTaskType.ASK_PARTNER,
                        title = "Get your first real phrase",
                        instruction = "Ask your partner to teach one phrase you genuinely need today, add its meaning, and record how they naturally say it."
                    )
                )
            }
            add(
                LessonTask(
                    type = LessonTaskType.CONVERSATION,
                    title = "Use it in a real exchange",
                    instruction = if (usable.isEmpty())
                        "Open Chat and ask your partner to teach you something you can use immediately."
                    else
                        "Open Chat and use at least one verified phrase naturally before switching back to English.",
                    entryId = first?.id,
                    durationSeconds = 120
                )
            )
        }

        return Mission(
            id = "local-${System.currentTimeMillis()}",
            title = if (usable.isEmpty()) "Build today's language from your partner" else "Use ${usable.size.coerceAtMost(3)} real ${learningLanguage} phrase${if (usable.size == 1) "" else "s"}",
            subtitle = if (usable.isEmpty()) "No invented lesson: the next step is to collect real language." else "Listen, remember, speak, then use it with the person who actually speaks it.",
            minutes = 10,
            steps = tasks.map { it.title },
            tasks = tasks,
            coachMessage = if (recentWeaknesses.isNotEmpty()) "I kept this session focused on what was difficult last time." else "This session is built only from language your partner has verified.",
            source = "local"
        )
    }
}
