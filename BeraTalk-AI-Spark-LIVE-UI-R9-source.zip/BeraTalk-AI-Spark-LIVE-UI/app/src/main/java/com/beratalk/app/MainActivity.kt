package com.beratalk.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.beratalk.app.audio.VoicePlayer
import com.beratalk.app.audio.VoiceRecorder
import com.beratalk.app.data.FirebaseGateway
import com.beratalk.app.data.AiClientRouter
import com.beratalk.app.data.AiProvider
import com.beratalk.app.data.HybridAiLessonEngine
import com.beratalk.app.data.SecureAiSettings
import com.beratalk.app.export.LanguagePackExporter
import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.BankType
import com.beratalk.app.model.CoachChallenge
import com.beratalk.app.model.CoachNudge
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.LearningSession
import com.beratalk.app.model.LessonTask
import com.beratalk.app.model.LessonTaskType
import com.beratalk.app.model.Mission
import com.beratalk.app.model.VoiceMessage
import com.beratalk.app.ui.theme.BeraCoral
import com.beratalk.app.ui.theme.BeraCoralDeep
import com.beratalk.app.ui.theme.BeraOrange
import com.beratalk.app.ui.theme.BeraOrangeDeep
import com.beratalk.app.ui.theme.BeraTalkTheme
import com.beratalk.app.ui.theme.BeraUiTheme
import com.beratalk.app.ui.theme.UiThemePreferences
import com.beratalk.app.ui.theme.BeraTeal
import com.beratalk.app.ui.theme.BeraTealDeep
import com.beratalk.app.ui.theme.Canvas
import com.beratalk.app.ui.theme.Border
import com.beratalk.app.ui.theme.CoralTint
import com.beratalk.app.ui.theme.OrangeTint
import com.beratalk.app.ui.theme.TealTint
import com.beratalk.app.ui.theme.Ink
import com.beratalk.app.ui.theme.Muted
import com.beratalk.app.ui.theme.Soft
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val uiPreferences = remember { UiThemePreferences(context) }
            var uiTheme by remember { mutableStateOf(uiPreferences.loadTheme()) }
            BeraTalkTheme(theme = uiTheme) {
                BeraTalkRoot(
                    uiTheme = uiTheme,
                    onUiThemeChange = { next ->
                        uiTheme = next
                        uiPreferences.saveTheme(next)
                    }
                )
            }
        }
    }
}

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    LEARN("Learn", Icons.Default.AutoAwesome),
    CHAT("Chat", Icons.Default.ChatBubble),
    LIBRARY("Library", Icons.Default.LibraryBooks),
    US("Us", Icons.Default.People)
}

@Composable
fun BeraTalkRoot(uiTheme: BeraUiTheme, onUiThemeChange: (BeraUiTheme) -> Unit) {
    val context = LocalContext.current
    val gateway = remember { FirebaseGateway(context) }
    var signedIn by remember { mutableStateOf(gateway.currentUid != null) }
    var profile by remember { mutableStateOf<AppProfile?>(null) }
    var checkingProfile by remember { mutableStateOf(false) }

    LaunchedEffect(signedIn) {
        if (signedIn && gateway.configured) {
            checkingProfile = true
            profile = runCatching { gateway.loadProfile() }.getOrNull()?.takeIf { !it.pairId.isNullOrBlank() }
            checkingProfile = false
        }
    }

    AnimatedContent(targetState = signedIn, label = "auth") { active ->
        if (!active) {
            AuthScreen(gateway = gateway, onSignedIn = { signedIn = true })
        } else if (checkingProfile) {
            LoadingScreen()
        } else if (profile == null) {
            SetupScreen(gateway = gateway) { completed -> profile = completed }
        } else {
            MainShell(profile = profile!!, gateway = gateway, uiTheme = uiTheme, onUiThemeChange = onUiThemeChange, onSignOut = {
                gateway.signOut()
                signedIn = false
                profile = null
            })
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Color.White), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandLockup(markSize = 44.dp)
            Spacer(Modifier.height(22.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(150.dp).height(5.dp).clip(CircleShape),
                color = BeraTealDeep,
                trackColor = TealTint
            )
            Spacer(Modifier.height(14.dp))
            Text("Loading your language pair…", color = Muted)
        }
    }
}

@Composable
private fun SetupScreen(gateway: FirebaseGateway, onComplete: (AppProfile) -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf(0) }
    var speaks by remember { mutableStateOf("Esan") }
    var learning by remember { mutableStateOf("Igala") }
    var dialect by remember { mutableStateOf("") }
    var dailyMinutes by remember { mutableStateOf(10) }
    var joinMode by remember { mutableStateOf(false) }
    var inviteCode by remember { mutableStateOf("") }
    var createdCode by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val totalSteps = 4

    Surface(color = Canvas, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (step > 0 && createdCode == null) {
                        IconButton(onClick = { step--; error = null }) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    BrandLockup(markSize = 34.dp, compact = true)
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.size(48.dp))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    repeat(totalSteps) { index ->
                        val active = index <= step
                        Box(
                            Modifier.weight(1f).height(5.dp).clip(CircleShape)
                                .background(if (active) BeraTealDeep else Border)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("STEP ${step + 1} OF $totalSteps", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
            }
            item {
                AnimatedContent(targetState = step, label = "setupStep") { current ->
                    SetupStepCard {
                        when (current) {
                            0 -> {
                                Text("What do you naturally speak?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Start with the language you can genuinely teach from everyday life.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(24.dp))
                                LanguageChoice(selected = speaks, onSelected = { chosen ->
                                    speaks = chosen
                                    if (learning == chosen) learning = if (chosen == "Esan") "Igala" else "Esan"
                                })
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 1 }
                            }
                            1 -> {
                                Text("What do you want to learn?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Your partner will be the real language source. BeraTalk will organize the practice.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(24.dp))
                                LanguageChoice(selected = learning, onSelected = { chosen ->
                                    learning = chosen
                                    if (speaks == chosen) speaks = if (chosen == "Esan") "Igala" else "Esan"
                                })
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 2 }
                            }
                            2 -> {
                                Text("Make the learning fit your life", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Keep this lightweight. You can change the details later.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(22.dp))
                                OutlinedTextField(
                                    value = dialect,
                                    onValueChange = { dialect = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Dialect / local variant (optional)") },
                                    supportingText = { Text("Example: the Esan or Igala variety you actually speak at home.") },
                                    shape = RoundedCornerShape(18.dp)
                                )
                                Spacer(Modifier.height(20.dp))
                                Text("Daily practice", style = MaterialTheme.typography.titleMedium, color = Ink)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(5, 10, 20, 30).forEach { minutes ->
                                        val active = dailyMinutes == minutes
                                        Surface(
                                            modifier = Modifier.weight(1f).clickable { dailyMinutes = minutes },
                                            color = if (active) BeraOrangeDeep else Color.White,
                                            shape = RoundedCornerShape(15.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (active) BeraOrangeDeep.copy(alpha = .24f) else Border)
                                        ) {
                                            Text("$minutes min", Modifier.padding(vertical = 12.dp), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 3 }
                            }
                            else -> {
                                Text(if (createdCode == null) "Connect with your partner" else "Your pair is ready", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (createdCode == null) "Create the pair on one phone, then use the six-character code on the other." else "Send this code to your partner. You can enter BeraTalk now and they can join from their phone.",
                                    color = Muted,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Spacer(Modifier.height(22.dp))
                                if (createdCode == null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        PairModeChip("Create pair", !joinMode) { joinMode = false; error = null }
                                        PairModeChip("Join partner", joinMode) { joinMode = true; error = null }
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    if (joinMode) {
                                        OutlinedTextField(
                                            value = inviteCode,
                                            onValueChange = { inviteCode = it.uppercase().filter { it.isLetterOrDigit() }.take(6) },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("Partner code") },
                                            supportingText = { Text("Enter the six-character code from your partner's phone.") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(18.dp)
                                        )
                                    } else {
                                        Surface(color = TealTint, shape = RoundedCornerShape(18.dp)) {
                                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.People, null, tint = BeraTealDeep)
                                                Spacer(Modifier.width(11.dp))
                                                Text("You'll get a private code after creating the pair.", color = Ink, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                } else {
                                    Surface(color = Ink, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("YOUR PRIVATE PAIR CODE", color = Color.White.copy(.72f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.height(8.dp))
                                            Text(createdCode.orEmpty(), style = MaterialTheme.typography.displaySmall, color = Color.White, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                                error?.let {
                                    Spacer(Modifier.height(14.dp))
                                    Surface(color = CoralTint, shape = RoundedCornerShape(16.dp)) { Text(it, Modifier.fillMaxWidth().padding(13.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium) }
                                }
                                Spacer(Modifier.height(22.dp))
                                val label = when {
                                    busy -> "Setting things up…"
                                    createdCode != null -> "Enter BeraTalk"
                                    joinMode -> "Join language pair"
                                    else -> "Create language pair"
                                }
                                PrimaryButton(label, enabled = !busy && (createdCode != null || !joinMode || inviteCode.length == 6)) {
                                    val base = AppProfile(
                                        displayName = gateway.currentDisplayName,
                                        speaks = speaks,
                                        learning = learning,
                                        dialect = dialect.trim(),
                                        dailyMinutes = dailyMinutes
                                    )
                                    if (createdCode != null) {
                                        scope.launch {
                                            val stored = runCatching { gateway.loadProfile() }.getOrNull()
                                            if (stored?.pairId.isNullOrBlank()) error = "Your pair could not be loaded. Please create it again." else onComplete(stored!!)
                                        }
                                    } else scope.launch {
                                        busy = true
                                        error = null
                                        if (!gateway.configured) {
                                            error = "Firebase is not configured in this build. BeraTalk will not create fake local pairs."
                                        } else {
                                            runCatching {
                                                gateway.saveProfile(base)
                                                if (joinMode) {
                                                    val pairId = gateway.joinPair(inviteCode)
                                                    val final = base.copy(pairId = pairId)
                                                    gateway.saveProfile(final)
                                                    onComplete(final)
                                                } else {
                                                    val created = gateway.createPair(base)
                                                    gateway.saveProfile(base.copy(pairId = created.pairId))
                                                    createdCode = created.inviteCode
                                                }
                                            }.onFailure { error = it.message ?: "Could not connect the pair." }
                                        }
                                        busy = false
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupStepCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border.copy(alpha = .65f))
    ) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) { content() }
    }
}

@Composable
private fun LanguageChoice(selected: String, onSelected: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Esan", "Igala").forEach { language ->
            val active = selected == language
            Surface(
                modifier = Modifier.weight(1f).clickable { onSelected(language) },
                color = if (active) BeraTealDeep else Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = if (active) 5.dp else 0.dp, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) BeraTealDeep else Border)
            ) {
                Text(language, Modifier.padding(vertical = 14.dp), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PairModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) BeraTealDeep else Color.White, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) BeraTealDeep else Border), shadowElevation = if (selected) 4.dp else 0.dp, modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = if (selected) Color.White else Ink, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AuthScreen(gateway: FirebaseGateway, onSignedIn: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var signUp by remember { mutableStateOf(false) }

    val infinite = rememberInfiniteTransition(label = "logoFloat")
    val logoScale by infinite.animateFloat(
        initialValue = .99f, targetValue = 1.015f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale"
    )

    Surface(color = Color.White, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.scale(logoScale)) { BrandLockup(markSize = 48.dp) }
                    Spacer(Modifier.height(26.dp))
                    Text(
                        "Learn their language from them.",
                        style = MaterialTheme.typography.displaySmall,
                        color = Ink,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Real voices, real corrections, and AI-guided conversations built around the person you care about.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Muted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
            item {
                OutlinedTextField(
                    value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email") }, leadingIcon = { Icon(Icons.Outlined.Mail, null, tint = Ink) },
                    singleLine = true, shape = RoundedCornerShape(18.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }
            item {
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null, tint = Ink) },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true, shape = RoundedCornerShape(18.dp)
                )
            }
            item {
                PrimaryButton(
                    text = if (busy) "Please wait…" else if (signUp) "Create account" else "Continue",
                    enabled = !busy && email.isNotBlank() && password.length >= 6
                ) {
                    scope.launch {
                        busy = true; error = null
                        runCatching {
                            if (signUp) gateway.createEmailAccount(email, password) else gateway.signInEmail(email, password)
                        }.onSuccess { onSignedIn() }.onFailure { error = it.message }
                        busy = false
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                    Text("  or  ", color = Muted, style = MaterialTheme.typography.labelMedium)
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                }
            }
            item {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            error = null
                            if (!gateway.configured) {
                                error = "Add your Firebase google-services.json first to enable Google sign-in."
                                return@launch
                            }
                            runCatching { googleSignIn(context, gateway) }
                                .onSuccess { onSignedIn() }
                                .onFailure { error = it.message ?: "Google sign-in failed" }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border)
                ) {
                    Text("G", fontWeight = FontWeight.Black, color = Color(0xFF1A73E8))
                    Spacer(Modifier.width(12.dp))
                    Text("Continue with Google", color = Ink, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (signUp) "Already have an account?" else "New to BeraTalk?", color = Muted)
                    TextButton(onClick = { signUp = !signUp }) { Text(if (signUp) "Sign in" else "Create account", color = BeraTealDeep, fontWeight = FontWeight.Bold) }
                }
            }
            error?.let { message ->
                item {
                    Surface(color = CoralTint, shape = RoundedCornerShape(18.dp)) {
                        Text(message, modifier = Modifier.fillMaxWidth().padding(15.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (!gateway.configured) {
                item {
                    Surface(color = TealTint, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BeraTealDeep.copy(alpha = .12f))) {
                        Column(Modifier.padding(17.dp)) {
                            Text("Firebase-ready build", style = MaterialTheme.typography.titleMedium, color = Ink)
                            Spacer(Modifier.height(5.dp))
                            Text("Authentication activates after app/google-services.json is added.", color = Muted)
                        }
                    }
                }
            }
        }
    }
}

private suspend fun googleSignIn(context: Context, gateway: FirebaseGateway) {
    val clientIdRes = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    require(clientIdRes != 0) { "Google web client ID not found. Re-download google-services.json after enabling Google sign-in in Firebase." }
    val webClientId = context.getString(clientIdRes)
    val googleOption = GetGoogleIdOption.Builder()
        .setServerClientId(webClientId)
        .setFilterByAuthorizedAccounts(false)
        .setAutoSelectEnabled(false)
        .build()
    val request = GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
    val result = CredentialManager.create(context).getCredential(context, request)
    val credential = GoogleIdTokenCredential.createFrom(result.credential.data)
    gateway.signInGoogle(credential.idToken)
}

@Composable
private fun MainShell(profile: AppProfile, gateway: FirebaseGateway, uiTheme: BeraUiTheme, onUiThemeChange: (BeraUiTheme) -> Unit, onSignOut: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var showSettings by remember { mutableStateOf(false) }
    var aiSettingsRevision by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val entries = remember { mutableStateListOf<LanguageEntry>() }
    val messages = remember { mutableStateListOf<VoiceMessage>() }
    val lessonEngine = remember { HybridAiLessonEngine(context) }
    val aiRouter = remember { AiClientRouter(context) }
    var currentProfile by remember(profile) { mutableStateOf(profile) }
    var session by remember { mutableStateOf<LearningSession?>(null) }
    var missionBusy by remember { mutableStateOf(false) }
    var entriesReady by remember { mutableStateOf(false) }
    var savedSessionChecked by remember { mutableStateOf(false) }
    var missionError by remember { mutableStateOf<String?>(null) }

    fun persistSession(next: LearningSession) {
        val pairId = currentProfile.pairId?.takeIf { gateway.configured } ?: return
        scope.launch { runCatching { gateway.saveLearningSession(pairId, next) } }
    }

    fun generateMission() {
        if (missionBusy) return
        scope.launch {
            missionBusy = true
            missionError = null
            runCatching {
                lessonEngine.buildMission(currentProfile.learning, entries.toList(), session?.reviewNotes.orEmpty())
            }.onSuccess { mission ->
                val next = LearningSession(mission = mission, reviewNotes = session?.reviewNotes.orEmpty().takeLast(10))
                session = next
                persistSession(next)
            }.onFailure {
                missionError = it.message ?: "Could not build the next mission."
            }
            missionBusy = false
        }
    }

    LaunchedEffect(currentProfile.pairId, gateway.configured) {
        val pairId = currentProfile.pairId
        if (gateway.configured && !pairId.isNullOrBlank()) {
            runCatching { gateway.ensurePairMemberName(pairId) }
            val partnerName = runCatching { gateway.loadPartnerName(pairId) }.getOrNull()
            if (!partnerName.isNullOrBlank() && partnerName != currentProfile.partnerName) {
                currentProfile = currentProfile.copy(partnerName = partnerName)
            }
        }
    }

    LaunchedEffect(currentProfile.pairId, gateway.configured) {
        savedSessionChecked = false
        session = null
        val pairId = currentProfile.pairId?.takeIf { gateway.configured }
        session = pairId?.let { runCatching { gateway.loadLearningSession(it) }.getOrNull() }
        savedSessionChecked = true
        if (pairId == null) entriesReady = true
    }

    LaunchedEffect(savedSessionChecked, entriesReady, aiSettingsRevision) {
        if (!savedSessionChecked || !entriesReady) return@LaunchedEffect
        if (session == null || aiSettingsRevision > 0) generateMission()
    }

    LaunchedEffect(savedSessionChecked, entriesReady, entries.size) {
        if (!savedSessionChecked || !entriesReady || missionBusy) return@LaunchedEffect
        val waitingForRealLanguage = session?.mission?.effectiveTasks?.any { it.type == LessonTaskType.ASK_PARTNER } == true
        val nowHasVerifiedLanguage = entries.any { it.verified && it.language.equals(currentProfile.learning, true) }
        if (waitingForRealLanguage && nowHasVerifiedLanguage) generateMission()
    }

    DisposableEffect(currentProfile.pairId, gateway.configured) {
        val pairId = currentProfile.pairId?.takeIf { gateway.configured }
        val partnerRegistration = pairId?.let { id ->
            gateway.observePartnerName(id) { name ->
                if (name != currentProfile.partnerName) currentProfile = currentProfile.copy(partnerName = name)
            }
        }
        val messageRegistration = pairId?.let { id ->
            gateway.observeMessages(id) { incoming ->
                messages.clear()
                messages.addAll(incoming)
            }
        }
        val entryRegistration = pairId?.let { id ->
            gateway.observeEntries(id) { incoming ->
                entries.clear()
                entries.addAll(incoming)
                entriesReady = true
            }
        }
        if (pairId == null) entriesReady = true
        onDispose {
            partnerRegistration?.remove()
            messageRegistration?.remove()
            entryRegistration?.remove()
        }
    }

    if (showSettings) {
        AiSettingsScreen(
            uiTheme = uiTheme,
            onUiThemeChange = onUiThemeChange,
            onBack = { showSettings = false },
            onSettingsChanged = { aiSettingsRevision++ }
        )
        return
    }

    Scaffold(
        containerColor = Canvas,
        bottomBar = {
            BeraBottomBar(selected = tab, onSelected = { tab = it })
        }
    ) { insets ->
        Crossfade(targetState = tab, modifier = Modifier.padding(insets), label = "tabs") { current ->
            when (current) {
                Tab.HOME -> HomeScreen(
                    profile = currentProfile,
                    session = session,
                    missionBusy = missionBusy,
                    missionError = missionError,
                    verifiedCount = entries.count { it.verified && it.language.equals(currentProfile.learning, true) },
                    voiceCount = messages.size,
                    aiLive = aiRouter.isConfigured(),
                    onStartMission = { tab = Tab.LEARN },
                    onGenerateMission = ::generateMission,
                    onChat = { tab = Tab.CHAT },
                    onLibrary = { tab = Tab.LIBRARY },
                    onAiSettings = { showSettings = true }
                )
                Tab.LEARN -> LearnScreen(
                    profile = currentProfile,
                    session = session,
                    entries = entries,
                    missionBusy = missionBusy,
                    aiLive = aiRouter.isConfigured(),
                    aiRouter = aiRouter,
                    resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                    onGenerateMission = ::generateMission,
                    onTaskCompleted = { task, needsReview ->
                        session?.let { old ->
                            val completed = old.completedTaskIds + task.id
                            val reviewTag = "type=${task.type}; entry_id=${task.entryId ?: "none"}; task=${task.title}"
                            val reviews = if (needsReview) (old.reviewNotes + reviewTag).takeLast(20) else old.reviewNotes
                            val next = old.copy(completedTaskIds = completed, reviewNotes = reviews, updatedAt = System.currentTimeMillis())
                            session = next
                            persistSession(next)
                        }
                    },
                    onChat = { tab = Tab.CHAT },
                    onLibrary = { tab = Tab.LIBRARY },
                    onAiSettings = { showSettings = true }
                )
                Tab.CHAT -> ChatScreen(
                    profile = currentProfile,
                    messages = messages,
                    entries = entries,
                    aiRouter = aiRouter,
                    aiSettingsRevision = aiSettingsRevision,
                    resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                    onOpenAiSettings = { showSettings = true },
                    onOpenLibrary = { tab = Tab.LIBRARY },
                    onRecorded = { file, duration, correctionFor ->
                        val pairId = currentProfile.pairId
                        val localMessage = VoiceMessage(localAudioPath = file.absolutePath, durationMs = duration, correctionFor = correctionFor)
                        messages.add(localMessage)
                        if (gateway.configured && pairId != null) {
                            scope.launch {
                                runCatching { gateway.sendVoiceMessage(pairId, file, duration, correctionFor) }
                                    .onFailure { messages.removeAll { it.id == localMessage.id } }
                            }
                        }
                    }
                )
                Tab.LIBRARY -> LibraryScreen(
                    entries = entries,
                    profile = currentProfile,
                    resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                    onAddEntry = { entry ->
                        val pairId = currentProfile.pairId
                        if (gateway.configured && pairId != null) {
                            scope.launch { runCatching { gateway.addEntry(pairId, entry) } }
                        } else {
                            entries.add(0, entry)
                        }
                    },
                    onVerifyEntry = { entry ->
                        val pairId = currentProfile.pairId
                        if (gateway.configured && pairId != null) {
                            scope.launch { runCatching { gateway.setEntryVerified(pairId, entry.id, true) } }
                        } else {
                            val index = entries.indexOfFirst { it.id == entry.id }
                            if (index >= 0) entries[index] = entry.copy(verified = true)
                        }
                    }
                )
                Tab.US -> UsScreen(currentProfile, session, entries.count { it.verified }, messages.size, onSignOut = onSignOut, onSettings = { showSettings = true })
            }
        }
    }
}

@Composable
private fun BeraBottomBar(selected: Tab, onSelected: (Tab) -> Unit) {
    Surface(
        color = Color.White,
        shadowElevation = 18.dp,
        modifier = Modifier.fillMaxWidth().navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tab.entries.forEach { item ->
                val active = selected == item
                val iconScale by animateFloatAsState(if (active) 1.08f else .94f, tween(220), label = "tabScale")
                Column(
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable { onSelected(item) }.padding(vertical = 3.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(39.dp).scale(iconScale).clip(CircleShape).background(if (active) BeraTeal else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(item.icon, item.label, tint = if (active) Color.White else Muted, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        item.label,
                        color = if (active) BeraTealDeep else Muted,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun BrandMonogram(size: Dp = 38.dp, modifier: Modifier = Modifier) {
    val stroke = size * .14f
    Box(modifier = modifier.size(size)) {
        Box(
            Modifier.offset(x = size * .08f, y = size * .08f)
                .width(stroke).height(size * .78f)
                .clip(RoundedCornerShape(999.dp)).background(Ink)
        )
        Box(
            Modifier.offset(x = size * .15f, y = size * .39f)
                .size(size * .43f)
                .border(stroke, Ink, CircleShape)
        )
        Box(
            Modifier.offset(x = size * .62f, y = size * .19f)
                .width(stroke).height(size * .66f)
                .clip(RoundedCornerShape(999.dp)).background(Ink)
        )
        Box(
            Modifier.offset(x = size * .50f, y = size * .31f)
                .width(size * .41f).height(stroke)
                .clip(RoundedCornerShape(999.dp)).background(Ink)
        )
    }
}

@Composable
private fun BrandLockup(markSize: Dp = 40.dp, compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        BrandMonogram(size = markSize)
        Spacer(Modifier.width(if (compact) 9.dp else 11.dp))
        Text(
            "BeraTalk",
            color = Ink,
            style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black
        )
    }
}

private fun themePreviewColor(theme: BeraUiTheme): Color = when (theme) {
    BeraUiTheme.VIOLET -> Color(0xFF8B5CF6)
    BeraUiTheme.COBALT -> Color(0xFF3B82F6)
    BeraUiTheme.EMERALD -> Color(0xFF10B981)
    BeraUiTheme.TANGERINE -> Color(0xFFF97316)
}

@Composable
private fun ThemeChoice(theme: BeraUiTheme, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Ink else Border),
        shadowElevation = if (selected) 5.dp else 0.dp
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(themePreviewColor(theme)))
            Spacer(Modifier.height(7.dp))
            Text(theme.label, color = Ink, style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.Black else FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineLarge, color = Ink)
            subtitle?.let { Spacer(Modifier.height(5.dp)); Text(it, style = MaterialTheme.typography.bodyMedium, color = Muted) }
        }
        action?.invoke()
    }
}

@Composable
private fun HomeScreen(
    profile: AppProfile,
    session: LearningSession?,
    missionBusy: Boolean,
    missionError: String?,
    verifiedCount: Int,
    voiceCount: Int,
    aiLive: Boolean,
    onStartMission: () -> Unit,
    onGenerateMission: () -> Unit,
    onChat: () -> Unit,
    onLibrary: () -> Unit,
    onAiSettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 34.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            ScreenHeader(
                "${currentGreeting()}, ${profile.displayName.ifBlank { "there" }}",
                "${profile.learning} grows from real voices—not a canned course."
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                    Text(profile.displayName.firstOrNull()?.uppercase() ?: "Y", color = Color.White, fontWeight = FontWeight.Black)
                }
            }
        }
        item {
            AiPresenceStrip(aiLive = aiLive, onAiSettings = onAiSettings)
        }
        item {
            when {
                missionBusy -> BuildingMissionCard(aiLive)
                session != null -> LiveMissionCard(session = session, onClick = onStartMission, onRefresh = onGenerateMission)
                else -> EmptyMissionCard(missionError = missionError, onGenerate = onGenerateMission)
            }
        }
        item {
            RealStatsStrip(
                verifiedCount = verifiedCount,
                voiceCount = voiceCount,
                completedToday = session?.completedTaskIds?.size ?: 0
            )
        }
        if (verifiedCount == 0) {
            item {
                ActionPanel(
                    eyebrow = "THE ENGINE NEEDS REAL LANGUAGE",
                    title = "Teach BeraTalk its first ${profile.learning} phrase",
                    body = "Add something your partner actually says, its meaning, and ideally their recording. That becomes real lesson material immediately.",
                    button = "Add real language",
                    accent = BeraOrange,
                    onClick = onLibrary
                )
            }
        } else {
            item {
                ActionPanel(
                    eyebrow = "LIVE WITH YOUR PARTNER",
                    title = "Move from practice into conversation",
                    body = if (voiceCount == 0) "Your voice thread is empty. Start with one natural message and let the AI set the challenge." else "$voiceCount real voice note${if (voiceCount == 1) "" else "s"} in your shared conversation.",
                    button = "Open conversation",
                    accent = BeraTeal,
                    onClick = onChat
                )
            }
        }
    }
}

@Composable
private fun AiPresenceStrip(aiLive: Boolean, onAiSettings: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "aiPresence")
    val pulse by infinite.animateFloat(
        initialValue = .45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "aiPulse"
    )
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onAiSettings)
    ) {
        Row(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(11.dp).clip(CircleShape).background((if (aiLive) BeraTealDeep else BeraOrangeDeep).copy(alpha = if (aiLive) pulse else 1f)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (aiLive) "AI coach is live" else "AI coach is not connected", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge)
                Text(if (aiLive) "Missions and challenges are generated as you use the app." else "Connect Gemini or OpenAI to activate adaptive tasks.", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
            Icon(Icons.Default.Settings, null, tint = Ink, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun BuildingMissionCard(aiLive: Boolean) {
    val infinite = rememberInfiniteTransition(label = "missionThinking")
    val sweep by infinite.animateFloat(0.12f, .88f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sweep")
    Surface(color = Color.Transparent, shape = RoundedCornerShape(30.dp), shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.background(Brush.linearGradient(listOf(BeraTealDeep, BeraTeal))).padding(22.dp)) {
            Text(if (aiLive) "AI IS BUILDING YOUR NEXT MISSION" else "BUILDING YOUR NEXT MISSION", color = Color.White.copy(.86f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(16.dp))
            Text("Reading your verified language bank…", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text("No stock lesson content is being inserted.", color = Color.White.copy(.65f), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(20.dp))
            LinearProgressIndicator(progress = { sweep }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = Color.White, trackColor = Color.White.copy(.22f))
        }
    }
}

@Composable
private fun LiveMissionCard(session: LearningSession, onClick: () -> Unit, onRefresh: () -> Unit) {
    val mission = session.mission
    val press = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .985f else 1f, label = "missionPress")
    val progress by animateFloatAsState(session.progress.coerceIn(0f, 1f), animationSpec = tween(500), label = "missionProgress")
    Card(
        modifier = Modifier.fillMaxWidth().scale(scale).clickable(interactionSource = press, indication = null, onClick = onClick),
        shape = RoundedCornerShape(30.dp),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(Modifier.background(Brush.linearGradient(listOf(BeraTealDeep, BeraTeal))).padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color.White.copy(alpha = .94f), shape = RoundedCornerShape(999.dp)) {
                    Text(if (mission.source == "ai") "LIVE AI MISSION" else "SAFE LOCAL MISSION", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.weight(1f))
                Text("${mission.minutes} min", color = Color.White.copy(.72f), style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(22.dp))
            Text(mission.title, style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text(mission.subtitle, color = Color.White.copy(.72f), style = MaterialTheme.typography.bodyLarge)
            if (mission.coachMessage.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.AutoAwesome, null, tint = BeraTeal, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(mission.coachMessage, color = Color.White.copy(.76f), style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(22.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = Color.White, trackColor = Color.White.copy(.24f))
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (session.progress >= 1f) "Mission complete" else "${session.completedTaskIds.size}/${mission.effectiveTasks.size} tasks · continue", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Default.AutoAwesome, "Generate a fresh mission", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun EmptyMissionCard(missionError: String?, onGenerate: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(26.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("No mission loaded", style = MaterialTheme.typography.headlineMedium, color = Ink)
            Spacer(Modifier.height(6.dp))
            Text(missionError ?: "Build a mission from the language currently in your verified bank.", color = Muted)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Build mission now", onClick = onGenerate)
        }
    }
}

@Composable
private fun RealStatsStrip(verifiedCount: Int, voiceCount: Int, completedToday: Int) {
    Surface(modifier = Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp) {
        Row(Modifier.padding(vertical = 17.dp)) {
            RealStat(verifiedCount.toString(), "verified", BeraTeal)
            Box(Modifier.width(1.dp).height(44.dp).background(Border))
            RealStat(voiceCount.toString(), "voice notes", BeraCoral)
            Box(Modifier.width(1.dp).height(44.dp).background(Border))
            RealStat(completedToday.toString(), "tasks done", BeraOrange)
        }
    }
}

@Composable
private fun RowScope.RealStat(value: String, label: String, accent: Color) {
    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(7.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(3.dp))
        Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun ActionPanel(eyebrow: String, title: String, body: String, button: String, accent: Color, onClick: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(19.dp)) {
            Box(Modifier.width(42.dp).height(6.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.height(13.dp))
            Text(eyebrow, color = Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, color = Ink)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(14.dp))
            TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) {
                Text("$button  →", color = Ink, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun LearnScreen(
    profile: AppProfile,
    session: LearningSession?,
    entries: List<LanguageEntry>,
    missionBusy: Boolean,
    aiLive: Boolean,
    aiRouter: AiClientRouter,
    resolveAudio: suspend (String) -> String?,
    onGenerateMission: () -> Unit,
    onTaskCompleted: (LessonTask, Boolean) -> Unit,
    onChat: () -> Unit,
    onLibrary: () -> Unit,
    onAiSettings: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var coachNudge by remember(session?.mission?.id) { mutableStateOf<CoachNudge?>(null) }
    var coachThinking by remember { mutableStateOf(false) }
    val mission = session?.mission
    val tasks = mission?.effectiveTasks.orEmpty()
    val currentTask = tasks.firstOrNull { it.id !in (session?.completedTaskIds ?: emptySet()) }
    val finished = mission != null && currentTask == null && tasks.isNotEmpty()

    fun complete(task: LessonTask, needsReview: Boolean) {
        val completedNow = (session?.completedTaskIds?.size ?: 0) + 1
        onTaskCompleted(task, needsReview)
        if (aiLive) {
            coachThinking = true
            scope.launch {
                coachNudge = aiRouter.buildCoachNudge(profile.learning, entries, completedNow, tasks.size, task.title)
                coachThinking = false
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 36.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { ScreenHeader("Learn", "One active task. Real material. Immediate action.") }
        if (!aiLive) {
            item { AiPresenceStrip(aiLive = false, onAiSettings = onAiSettings) }
        }
        when {
            missionBusy -> item { BuildingMissionCard(aiLive) }
            mission == null -> item { EmptyMissionCard(null, onGenerateMission) }
            else -> {
                item { MissionProgressHeader(session!!) }
                coachNudge?.let { nudge -> item { CoachNudgeCard(nudge) } }
                if (coachThinking) item { CoachThinkingRow() }
                if (currentTask != null) {
                    item {
                        AnimatedContent(targetState = currentTask.id, label = "liveTask") {
                            LiveTaskCard(
                                task = currentTask,
                                entry = currentTask.entryId?.let { id -> entries.firstOrNull { it.id == id } },
                                resolveAudio = resolveAudio,
                                onComplete = { needsReview -> complete(currentTask, needsReview) },
                                onChat = onChat,
                                onLibrary = onLibrary
                            )
                        }
                    }
                } else if (finished) {
                    item {
                        Surface(color = Color.White, shape = RoundedCornerShape(28.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(22.dp)) {
                                Icon(Icons.Default.CheckCircle, null, tint = BeraTealDeep, modifier = Modifier.size(38.dp))
                                Spacer(Modifier.height(12.dp))
                                Text("You finished the mission.", style = MaterialTheme.typography.headlineMedium, color = Ink)
                                Spacer(Modifier.height(6.dp))
                                Text("Now make the skill survive outside the lesson: use it with your partner.", color = Muted)
                                Spacer(Modifier.height(18.dp))
                                PrimaryButton("Take it into Chat", onClick = onChat)
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = onGenerateMission, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                                    Text("Generate another mission", color = Ink, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MissionProgressHeader(session: LearningSession) {
    val animated by animateFloatAsState(session.progress.coerceIn(0f, 1f), tween(500), label = "learnProgress")
    Surface(color = Color.Transparent, shape = RoundedCornerShape(24.dp), shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.background(Brush.linearGradient(listOf(BeraTealDeep, BeraTeal))).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (session.mission.source == "ai") "ADAPTIVE MISSION" else "OFFLINE-SAFE MISSION", color = Color.White.copy(.82f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("${session.completedTaskIds.size}/${session.mission.effectiveTasks.size}", color = Color.White.copy(.65f), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(session.mission.title, color = Color.White, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(progress = { animated }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Color.White, trackColor = Color.White.copy(.23f))
        }
    }
}

@Composable
private fun CoachNudgeCard(nudge: CoachNudge) {
    AnimatedVisibility(visible = true, enter = fadeIn() + scaleIn()) {
        Surface(color = Color.White, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(BeraOrange), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Ink, modifier = Modifier.size(18.dp)) }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text(nudge.headline, color = Ink, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(3.dp))
                    Text(nudge.message, color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun CoachThinkingRow() {
    val infinite = rememberInfiniteTransition(label = "coachThinking")
    val a by infinite.animateFloat(.25f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "a")
    val b by infinite.animateFloat(1f, .25f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "b")
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AutoAwesome, null, tint = BeraTealDeep, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("Coach is adapting the next step", color = Muted)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(6.dp).clip(CircleShape).background(BeraTealDeep.copy(a)))
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(6.dp).clip(CircleShape).background(BeraTealDeep.copy(b)))
    }
}

@Composable
private fun LiveTaskCard(
    task: LessonTask,
    entry: LanguageEntry?,
    resolveAudio: suspend (String) -> String?,
    onComplete: (Boolean) -> Unit,
    onChat: () -> Unit,
    onLibrary: () -> Unit
) {
    var reveal by remember(task.id) { mutableStateOf(false) }
    var interactionDone by remember(task.id) { mutableStateOf(false) }
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    var playingReference by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    Surface(color = Color.White, shape = RoundedCornerShape(28.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 9.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(21.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TaskTypeBadge(task.type)
                Spacer(Modifier.weight(1f))
                if (task.durationSeconds > 0) Text("~${task.durationSeconds}s", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(18.dp))
            Text(task.title, style = MaterialTheme.typography.headlineMedium, color = Ink)
            Spacer(Modifier.height(7.dp))
            Text(task.instruction, color = Muted, style = MaterialTheme.typography.bodyLarge)

            if (entry != null) {
                Spacer(Modifier.height(18.dp))
                VerifiedPhraseBlock(entry = entry, revealMeaning = reveal || task.type != LessonTaskType.RECALL)
            }

            Spacer(Modifier.height(18.dp))
            when (task.type) {
                LessonTaskType.LISTEN -> {
                    if (entry?.audioPath.isNullOrBlank()) {
                        Surface(color = OrangeTint, shape = RoundedCornerShape(16.dp)) {
                            Text("This verified entry has no recording yet. Add your partner's real voice before treating listening practice as complete.", Modifier.padding(13.dp), color = Ink)
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = onLibrary, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Add a real recording", color = Ink, fontWeight = FontWeight.Bold) }
                    } else {
                        ReferenceAudioButton(playing = playingReference, onClick = {
                            entry?.audioPath?.let { path ->
                                playingReference = true
                                scope.launch {
                                    val local = resolveAudio(path)
                                    if (local == null) {
                                        playingReference = false
                                    } else {
                                        player.play(local, onDone = { playingReference = false; interactionDone = true })
                                    }
                                }
                            }
                        })
                    }
                }
                LessonTaskType.RECALL -> {
                    OutlinedButton(onClick = { reveal = !reveal; if (!reveal) Unit else interactionDone = true }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                        Text(if (reveal) "Hide meaning" else "Reveal meaning", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
                LessonTaskType.SPEAK -> {
                    SpeakPracticeControl(entry = entry, resolveAudio = resolveAudio, onPracticeRecorded = { interactionDone = true })
                }
                LessonTaskType.CONVERSATION -> {
                    PrimaryButton("Open live conversation") { interactionDone = true; onChat() }
                    Spacer(Modifier.height(8.dp))
                    Text("Come back and mark complete after you actually use it.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
                LessonTaskType.ASK_PARTNER -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        OutlinedButton(onClick = { interactionDone = true; onChat() }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Ask in Chat", color = Ink, fontWeight = FontWeight.Bold) }
                        OutlinedButton(onClick = { interactionDone = true; onLibrary() }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Add phrase", color = Ink, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            if (task.type == LessonTaskType.RECALL && reveal) {
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Button(
                        onClick = { onComplete(false) },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
                    ) { Text("Got it", fontWeight = FontWeight.Black) }
                    OutlinedButton(
                        onClick = { onComplete(true) },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Review again", color = Ink, fontWeight = FontWeight.Bold) }
                }
            } else {
                PrimaryButton(
                    text = if (interactionDone) "Complete this task" else "Do the task first",
                    enabled = interactionDone,
                    onClick = { onComplete(false) }
                )
                if (interactionDone) {
                    TextButton(onClick = { onComplete(true) }, modifier = Modifier.fillMaxWidth()) {
                        Text("I need another round", color = BeraOrangeDeep, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskTypeBadge(type: LessonTaskType) {
    val (text, tint) = when (type) {
        LessonTaskType.LISTEN -> "LISTEN" to TealTint
        LessonTaskType.RECALL -> "RECALL" to OrangeTint
        LessonTaskType.SPEAK -> "SPEAK" to CoralTint
        LessonTaskType.CONVERSATION -> "USE IT" to TealTint
        LessonTaskType.ASK_PARTNER -> "PARTNER" to OrangeTint
    }
    Surface(color = tint, shape = RoundedCornerShape(999.dp)) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun VerifiedPhraseBlock(entry: LanguageEntry, revealMeaning: Boolean) {
    Surface(color = Color.White, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Verified, null, tint = BeraTealDeep, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text("VERIFIED ${entry.language.uppercase()}", color = BeraTealDeep, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(10.dp))
            Text(entry.nativeText, style = MaterialTheme.typography.headlineMedium, color = Ink)
            AnimatedVisibility(revealMeaning) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    Text(entry.meaning, color = Muted, style = MaterialTheme.typography.bodyLarge)
                    if (entry.dialect.isNotBlank()) {
                        Spacer(Modifier.height(5.dp))
                        Text("Variant · ${entry.dialect}", color = BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReferenceAudioButton(playing: Boolean, onClick: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "referencePlaying")
    val pulse by infinite.animateFloat(.78f, 1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "referencePulse")
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 6.dp, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).scale(if (playing) pulse else 1f).clip(CircleShape).background(BeraTealDeep), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(if (playing) "Playing real partner voice…" else "Play partner recording", color = Ink, fontWeight = FontWeight.Black)
                Text("Nothing synthesized or substituted", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun SpeakPracticeControl(entry: LanguageEntry?, resolveAudio: suspend (String) -> String?, onPracticeRecorded: () -> Unit) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    var recording by remember { mutableStateOf(false) }
    var recordedPath by remember { mutableStateOf<String?>(null) }
    var level by remember { mutableStateOf(0f) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true }
    }
    LaunchedEffect(recording) {
        while (recording) {
            level = (recorder.amplitude().toFloat() / 32767f).coerceIn(0f, 1f)
            kotlinx.coroutines.delay(80)
        }
        level = 0f
    }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel(); player.stop() } }

    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LiveMicMeter(level = level, active = recording)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (recording) "Listening to your practice" else if (recordedPath != null) "Your take is ready" else "Record your own take", color = Ink, fontWeight = FontWeight.Black)
                    Text("Compare yourself with the real reference—AI does not declare minority-language pronunciation 'correct'.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(if (recording) BeraCoral else Ink).clickable {
                    if (recording) {
                        val file = recorder.stop().first
                        recording = false
                        recordedPath = file?.absolutePath
                        if (file != null) onPracticeRecorded()
                    } else {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }, contentAlignment = Alignment.Center) {
                    Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = Color.White)
                }
            }
            if (recordedPath != null) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(onClick = { recordedPath?.let { player.play(it) } }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Play mine", color = Ink, fontWeight = FontWeight.Bold) }
                    OutlinedButton(enabled = !entry?.audioPath.isNullOrBlank(), onClick = {
                        entry?.audioPath?.let { path ->
                            scope.launch { resolveAudio(path)?.let { player.play(it) } }
                        }
                    }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Play partner", color = if (entry?.audioPath.isNullOrBlank()) Muted else Ink, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun LiveMicMeter(level: Float, active: Boolean) {
    val animated by animateFloatAsState(if (active) level.coerceAtLeast(.08f) else .04f, tween(90), label = "micLevel")
    Row(Modifier.width(54.dp).height(34.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        val factors = listOf(.45f, .75f, 1f, .65f, .9f, .55f, .8f)
        factors.forEach { factor ->
            val h = (7f + 25f * (animated * factor).coerceIn(0f, 1f)).dp
            Box(Modifier.width(4.dp).height(h).clip(CircleShape).background(if (active) BeraCoralDeep else Muted.copy(.35f)))
        }
    }
}

@Composable
private fun ChatScreen(
    profile: AppProfile,
    messages: MutableList<VoiceMessage>,
    entries: List<LanguageEntry>,
    aiRouter: AiClientRouter,
    aiSettingsRevision: Int,
    resolveAudio: suspend (String) -> String?,
    onOpenAiSettings: () -> Unit,
    onOpenLibrary: () -> Unit,
    onRecorded: (File, Long, String?) -> Unit
) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    var recording by remember { mutableStateOf(false) }
    var currentDuration by remember { mutableStateOf(0L) }
    var tick by remember { mutableStateOf(0L) }
    var micLevel by remember { mutableStateOf(0f) }
    var helpVisible by remember { mutableStateOf(false) }
    var helpNote by remember { mutableStateOf<String?>(null) }
    var correctionFor by remember { mutableStateOf<String?>(null) }
    var challenge by remember { mutableStateOf<CoachChallenge?>(null) }
    var challengeBusy by remember { mutableStateOf(false) }
    var challengeRevision by remember { mutableStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    var remaining by remember { mutableStateOf(0) }
    var playingId by remember { mutableStateOf<String?>(null) }
    var playbackProgress by remember { mutableStateOf(0f) }
    val verifiedEntries = entries.filter { it.verified && it.language.equals(profile.learning, true) }
    val aiLive = aiRouter.isConfigured()

    fun generateChallenge() {
        if (challengeBusy) return
        scope.launch {
            challengeBusy = true
            challenge = if (aiLive) aiRouter.buildConversationChallenge(profile.learning, verifiedEntries, messages.size) else null
            if (challenge == null) {
                val entry = verifiedEntries.firstOrNull()
                challenge = CoachChallenge(
                    title = if (entry == null) "Get one real phrase" else "Use a verified phrase naturally",
                    instruction = if (entry == null) "Ask your partner to teach and record one phrase you genuinely need right now." else "Use the selected verified phrase in a real voice note, then ask one follow-up question.",
                    durationSeconds = 60,
                    entryId = entry?.id,
                    source = "local"
                )
            }
            remaining = challenge?.durationSeconds ?: 60
            timerRunning = false
            challengeBusy = false
        }
    }

    fun playAudio(message: VoiceMessage, speed: Float = 1f) {
        scope.launch {
            val local = resolveAudio(message.localAudioPath) ?: return@launch
            playingId = message.id
            player.play(local, speed) { playingId = null }
        }
    }

    LaunchedEffect(aiSettingsRevision, challengeRevision, verifiedEntries.size) { generateChallenge() }
    LaunchedEffect(playingId) {
        playbackProgress = 0f
        while (playingId != null) {
            playbackProgress = player.progress()
            kotlinx.coroutines.delay(90)
        }
        playbackProgress = 0f
    }
    LaunchedEffect(timerRunning, remaining) {
        if (timerRunning && remaining > 0) {
            kotlinx.coroutines.delay(1000)
            remaining -= 1
        } else if (timerRunning && remaining <= 0) {
            timerRunning = false
            kotlinx.coroutines.delay(650)
            challengeRevision++
        }
    }
    LaunchedEffect(recording) {
        while (recording) {
            currentDuration = System.currentTimeMillis() - tick
            micLevel = (recorder.amplitude().toFloat() / 32767f).coerceIn(0f, 1f)
            kotlinx.coroutines.delay(80)
        }
        micLevel = 0f
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true; tick = System.currentTimeMillis() }
    }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel(); player.stop() } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color.White, shape = RoundedCornerShape(13.dp), shadowElevation = 5.dp) { BrandMonogram(size = 42.dp, modifier = Modifier.padding(7.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.partnerName.ifBlank { "Your language partner" }, style = MaterialTheme.typography.titleMedium, color = Ink)
                Text("${profile.learning} ↔ ${profile.speaks} · voice to voice", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = { helpVisible = !helpVisible }) { Icon(Icons.Default.MoreHoriz, "Conversation tools", tint = Ink) }
        }
        AnimatedVisibility(helpVisible) {
            Column(Modifier.fillMaxWidth().background(OrangeTint).padding(horizontal = 20.dp, vertical = 12.dp)) {
                val lastPartner = messages.lastOrNull { it.senderId != "me" }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Assist("Play slower", enabled = lastPartner != null) { lastPartner?.let { playAudio(it, .75f) } }
                    Assist("Ask meaning", enabled = true) { helpNote = "Record a voice note asking your partner what the unclear phrase means in this context." }
                    Assist("Add phrase", enabled = true) { onOpenLibrary() }
                }
                helpNote?.let { note -> Spacer(Modifier.height(8.dp)); Text(note, color = Ink, style = MaterialTheme.typography.bodyMedium) }
            }
        }

        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                LiveChallengeCard(
                    challenge = challenge,
                    entry = challenge?.entryId?.let { id -> verifiedEntries.firstOrNull { it.id == id } },
                    busy = challengeBusy,
                    aiLive = aiLive,
                    timerRunning = timerRunning,
                    remaining = remaining,
                    onStartTimer = {
                        remaining = challenge?.durationSeconds ?: 60
                        timerRunning = true
                    },
                    onRefresh = { challengeRevision++ },
                    onAiSettings = onOpenAiSettings
                )
            }
            if (messages.isEmpty()) {
                item {
                    Surface(color = Color.White, shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Mic, null, tint = BeraTealDeep, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("No pretend conversation here.", style = MaterialTheme.typography.titleLarge, color = Ink)
                            Spacer(Modifier.height(5.dp))
                            Text("Your thread starts when one of you sends a real voice note.", color = Muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            }
            items(messages, key = { it.id }) { msg ->
                VoiceBubble(
                    mine = msg.senderId == "me",
                    seconds = (msg.durationMs / 1000).coerceAtLeast(1).toInt(),
                    correction = msg.correctionFor != null,
                    playing = playingId == msg.id,
                    progress = if (playingId == msg.id) playbackProgress else 0f,
                    onPlay = { playAudio(msg) },
                    onCorrect = if (msg.senderId != "me") ({ correctionFor = msg.id }) else null
                )
            }
        }

        Column(Modifier.fillMaxWidth().background(Color.White).padding(14.dp)) {
            AnimatedVisibility(recording) {
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    LiveMicMeter(level = micLevel, active = true)
                    Spacer(Modifier.width(10.dp))
                    Text(formatMs(currentDuration), fontWeight = FontWeight.Black, color = Ink)
                    Spacer(Modifier.weight(1f))
                    Text(if (correctionFor != null) "Recording a correction" else "Recording…", color = BeraCoralDeep, fontWeight = FontWeight.Bold)
                }
            }
            if (correctionFor != null && !recording) {
                Surface(color = OrangeTint, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Correction mode: your next recording will attach to that voice note.", Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { correctionFor = null }) { Text("Cancel", color = BeraOrangeDeep) }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onOpenLibrary) { Icon(Icons.Default.Add, "Add language to library", tint = Ink) }
                Surface(modifier = Modifier.weight(1f), color = Color.White, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 4.dp) {
                    Text(when {
                        recording && correctionFor != null -> "Say the correction naturally"
                        recording -> "Speak naturally—send when done"
                        correctionFor != null -> "Tap mic to record the correction"
                        else -> "Voice-first conversation"
                    }, Modifier.padding(horizontal = 16.dp, vertical = 14.dp), color = Muted)
                }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(56.dp).clip(CircleShape).background(if (recording) BeraCoralDeep else BeraTealDeep).clickable {
                    if (recording) {
                        val (file, duration) = recorder.stop()
                        recording = false
                        file?.let { onRecorded(it, duration, correctionFor) }
                        correctionFor = null
                    } else {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true; tick = System.currentTimeMillis() } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }, contentAlignment = Alignment.Center) {
                    Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun LiveChallengeCard(
    challenge: CoachChallenge?,
    entry: LanguageEntry?,
    busy: Boolean,
    aiLive: Boolean,
    timerRunning: Boolean,
    remaining: Int,
    onStartTimer: () -> Unit,
    onRefresh: () -> Unit,
    onAiSettings: () -> Unit
) {
    Surface(color = Color.Transparent, shape = RoundedCornerShape(24.dp), shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.background(Brush.linearGradient(listOf(BeraTealDeep, BeraTeal))).padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(Color.White))
                Spacer(Modifier.width(7.dp))
                Text(if (aiLive) "LIVE AI CHALLENGE" else "LOCAL CHALLENGE", color = Color.White.copy(.88f), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRefresh, enabled = !busy) { Icon(Icons.Default.AutoAwesome, "New challenge", tint = Color.White.copy(.75f)) }
            }
            if (busy) {
                Spacer(Modifier.height(7.dp))
                Text("Building a challenge from your verified bank…", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = Color.White, trackColor = Color.White.copy(.22f))
            } else if (challenge != null) {
                Text(challenge.title, color = Color.White, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(5.dp))
                Text(challenge.instruction, color = Color.White.copy(.70f), style = MaterialTheme.typography.bodyMedium)
                if (entry != null) {
                    Spacer(Modifier.height(12.dp))
                    Surface(color = Color.White.copy(.08f), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(entry.nativeText, color = Color.White, fontWeight = FontWeight.Black)
                            Text(entry.meaning, color = Color.White.copy(.58f), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color.White, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable(enabled = !timerRunning, onClick = onStartTimer)) {
                        Text(if (timerRunning) formatSeconds(remaining) else "Start ${challenge.durationSeconds}s", Modifier.padding(horizontal = 13.dp, vertical = 8.dp), color = BeraTealDeep, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(if (timerRunning) "Keep going until the timer ends." else "Start when both of you are ready.", color = Color.White.copy(.6f), style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Text("No challenge available", color = Color.White, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(7.dp))
                TextButton(onClick = onAiSettings, contentPadding = PaddingValues(0.dp)) { Text("Check AI settings →", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun VoiceBubble(mine: Boolean, seconds: Int, correction: Boolean, playing: Boolean, progress: Float, onPlay: () -> Unit, onCorrect: (() -> Unit)?) {
    val infinite = rememberInfiniteTransition(label = "voicePlaying")
    val pulse by infinite.animateFloat(.7f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "voicePulse")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        if (correction) {
            Text("Replying with a pronunciation correction", color = BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
        }
        Card(
            shape = if (mine) RoundedCornerShape(22.dp, 6.dp, 22.dp, 22.dp) else RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp),
            colors = CardDefaults.cardColors(containerColor = if (mine) BeraTealDeep else Color.White),
            elevation = CardDefaults.cardElevation(5.dp),
            border = if (mine) null else androidx.compose.foundation.BorderStroke(1.dp, Border)
        ) {
            Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).scale(if (playing) pulse else 1f).clip(CircleShape).background(if (mine) Color.White.copy(.14f) else Soft).clickable(onClick = onPlay), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, null, tint = if (mine) Color.White else Ink)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.width(150.dp)) {
                    Text(if (playing) "Playing…" else "Voice note", color = if (mine) Color.White else Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(5.dp))
                    LinearProgressIndicator(progress = { if (playing) progress.coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape), color = if (mine) BeraOrange else BeraTealDeep, trackColor = if (mine) Color.White.copy(.16f) else Soft)
                }
                Spacer(Modifier.width(9.dp))
                Text(formatSeconds(seconds), color = if (mine) Color.White.copy(.65f) else Muted, style = MaterialTheme.typography.labelMedium)
            }
        }
        if (onCorrect != null) {
            TextButton(onClick = onCorrect, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                Text("Send correction", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Assist(text: String, enabled: Boolean, onClick: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.clickable(enabled = enabled, onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = if (enabled) Ink else Muted.copy(.5f), style = MaterialTheme.typography.labelMedium)
    }
}

private fun formatMs(ms: Long): String = "%02d:%02d".format((ms / 60000), (ms / 1000) % 60)
private fun formatSeconds(seconds: Int): String = "%d:%02d".format((seconds / 60), seconds % 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryScreen(entries: MutableList<LanguageEntry>, profile: AppProfile, resolveAudio: suspend (String) -> String?, onAddEntry: (LanguageEntry) -> Unit, onVerifyEntry: (LanguageEntry) -> Unit) {
    val context = LocalContext.current
    val exporter = remember { LanguagePackExporter(context) }
    val exportScope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(BankType.WORD) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var exportLanguage by remember { mutableStateOf(profile.speaks) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            exportScope.launch {
                runCatching {
                    val hydratedEntries = entries.map { entry ->
                        val resolved = entry.audioPath?.let { resolveAudio(it) }
                        if (resolved != null) entry.copy(audioPath = resolved) else entry.copy(audioPath = null)
                    }
                    val file = exporter.export(exportLanguage, hydratedEntries)
                    context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                }
            }
        }
    }
    val filtered = entries.filter { it.type == selected && (search.isBlank() || it.nativeText.contains(search, true) || it.meaning.contains(search, true)) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        LazyColumn(
            modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ScreenHeader("Your language library", "Everything you teach each other becomes reusable learning material.") {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(BeraTealDeep).clickable { showAdd = true }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, null, tint = Color.White) }
                }
            }
            item {
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search words, meanings, stories…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp)
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(BankType.entries) { type ->
                        val active = selected == type
                        Surface(
                            color = if (active) BeraTealDeep else Color.White, shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { selected = type }
                        ) {
                            Text(type.label, Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (filtered.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(7.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Book, null, tint = BeraTealDeep, modifier = Modifier.size(40.dp)); Spacer(Modifier.height(12.dp)); Text("Nothing here yet", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(6.dp)); Text("Add something you naturally say. Your bank grows while you live your life.", color = Muted)
                        }
                    }
                }
            }
            items(filtered, key = { it.id }) { entry -> EntryCard(entry, resolveAudio, onVerifyEntry) }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(7.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Own your language data", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(5.dp)); Text("Export a portable ZIP with the language entries and any locally saved recordings.", color = Muted)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(profile.speaks, profile.learning).distinct().forEach { language ->
                                OutlinedButton(onClick = { exportLanguage = language; exportLauncher.launch("${language.lowercase()}-language-pack.zip") }, shape = RoundedCornerShape(14.dp)) {
                                    Text("Export $language", color = Ink, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddEntrySheet(initialType = selected, profile = profile, onDismiss = { showAdd = false }, onSave = { onAddEntry(it); showAdd = false })
    }
}

@Composable
private fun EntryCard(entry: LanguageEntry, resolveAudio: suspend (String) -> String?, onVerify: (LanguageEntry) -> Unit) {
    val player = remember { VoicePlayer() }
    val playbackScope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { player.stop() } }
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(6.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(if (entry.language == "Igala") TealTint else OrangeTint), contentAlignment = Alignment.Center) {
                    Icon(if (entry.type == BankType.STORY) Icons.Default.Book else Icons.Default.GraphicEq, null, tint = if (entry.language == "Igala") BeraTealDeep else BeraOrangeDeep)
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(entry.nativeText, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(7.dp))
                        Surface(color = if (entry.verified) TealTint else OrangeTint, shape = RoundedCornerShape(999.dp)) {
                            Text(if (entry.verified) "VERIFIED" else "DRAFT", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = if (entry.verified) BeraTealDeep else BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(entry.meaning, color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    Text("${entry.language}${if (entry.dialect.isNotBlank()) " · ${entry.dialect}" else ""}", color = if (entry.language == "Igala") BeraTealDeep else BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                IconButton(enabled = !entry.audioPath.isNullOrBlank(), onClick = {
                    entry.audioPath?.let { path -> playbackScope.launch { resolveAudio(path)?.let { player.play(it) } } }
                }) { Icon(Icons.Default.PlayArrow, null, tint = if (entry.audioPath.isNullOrBlank()) Muted.copy(.45f) else Ink) }
            }
            if (!entry.verified) {
                Spacer(Modifier.height(12.dp))
                Surface(color = OrangeTint, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("AI is ignoring this entry until a native speaker confirms it.", Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { onVerify(entry) }) { Text("Confirm", color = BeraOrangeDeep, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEntrySheet(initialType: BankType, profile: AppProfile, onDismiss: () -> Unit, onSave: (LanguageEntry) -> Unit) {
    var type by remember { mutableStateOf(initialType) }
    var language by remember { mutableStateOf(profile.speaks) }
    var nativeConfirmed by remember { mutableStateOf(true) }
    var nativeText by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    var notes by remember { mutableStateOf("") }
    var dialect by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var audioPath by remember { mutableStateOf<String?>(null) }
    var audioDuration by remember { mutableStateOf(0L) }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true }
    }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel() } }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Color.White) {
        LazyColumn(contentPadding = PaddingValues(20.dp, 6.dp, 20.dp, 34.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            item { Text("Add to ${type.label}", style = MaterialTheme.typography.headlineMedium) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(BankType.entries) { b -> Surface(color = if (b == type) BeraTealDeep else Color.White, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (b == type) BeraTealDeep else Border), modifier = Modifier.clickable { type = b }) { Text(b.label, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = if (b == type) Color.White else Ink, fontWeight = FontWeight.Bold) } } }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Esan", "Igala").forEach { lang -> Surface(color = if (language == lang) BeraTealDeep else Color.White, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (language == lang) BeraTealDeep else Border), modifier = Modifier.clickable { language = lang; nativeConfirmed = lang.equals(profile.speaks, true) }) { Text(lang, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = if (language == lang) Color.White else Ink, fontWeight = FontWeight.Bold) } }
                }
            }
            item { OutlinedTextField(nativeText, { nativeText = it }, Modifier.fillMaxWidth(), label = { Text(if (type == BankType.STORY) "Title / language text" else "How you actually say it") }, shape = RoundedCornerShape(18.dp), minLines = if (type == BankType.STORY) 3 else 1) }
            item { OutlinedTextField(meaning, { meaning = it }, Modifier.fillMaxWidth(), label = { Text("Meaning / natural translation") }, shape = RoundedCornerShape(18.dp), minLines = 2) }
            item {
                TextButton(onClick = { showAdvanced = !showAdvanced }, contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)) {
                    Text(if (showAdvanced) "Hide extra details" else "Add dialect or cultural context", color = BeraTealDeep, fontWeight = FontWeight.Bold)
                }
            }
            if (showAdvanced) {
                item { OutlinedTextField(dialect, { dialect = it }, Modifier.fillMaxWidth(), label = { Text("Dialect / variant (optional)") }, shape = RoundedCornerShape(18.dp)) }
                item { OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("Context or cultural note (optional)") }, shape = RoundedCornerShape(18.dp), minLines = 2) }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(5.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) BeraCoralDeep else BeraTealDeep)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (recording) "Recording…" else if (audioPath != null) "Pronunciation saved" else "Record pronunciation", fontWeight = FontWeight.Bold)
                            Text(if (audioPath != null) "${(audioDuration / 1000).coerceAtLeast(1)} sec · original voice kept" else "Add the real native pronunciation. No transcription required.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                        }
                        TextButton(onClick = {
                            if (recording) {
                                val (file, duration) = recorder.stop(); recording = false; audioPath = file?.absolutePath; audioDuration = duration
                            } else {
                                if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true }
                                else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }) { Text(if (recording) "Stop" else if (audioPath != null) "Redo" else "Record") }
                    }
                }
            }
            item {
                Surface(color = if (nativeConfirmed) TealTint else OrangeTint, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(if (nativeConfirmed) "Native-confirmed material" else "Draft material", color = Ink, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(4.dp))
                        Text(if (nativeConfirmed) "The AI may use this entry in lessons and challenges." else "The AI will ignore this entry until a native speaker confirms it.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Assist("Native confirmed", enabled = !nativeConfirmed) { nativeConfirmed = true }
                            Assist("Save as draft", enabled = nativeConfirmed) { nativeConfirmed = false }
                        }
                    }
                }
            }
            item {
                PrimaryButton("Save to bank", enabled = nativeText.isNotBlank() && meaning.isNotBlank()) {
                    onSave(LanguageEntry(type = type, language = language, nativeText = nativeText.trim(), meaning = meaning.trim(), notes = notes.trim(), dialect = dialect.trim(), audioPath = audioPath, verified = nativeConfirmed))
                }
            }
        }
    }
}

@Composable
private fun UsScreen(
    profile: AppProfile,
    session: LearningSession?,
    verifiedCount: Int,
    voiceCount: Int,
    onSignOut: () -> Unit,
    onSettings: () -> Unit
) {
    val missionProgress = session?.progress ?: 0f
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("Us", "Only activity that actually happened appears here.") { IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Ink) } } }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(9.dp)) {
                Column(Modifier.background(Brush.linearGradient(listOf(BeraTealDeep, BeraTeal))).padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(profile.displayName.firstOrNull()?.uppercase() ?: "Y", BeraTeal)
                        Spacer(Modifier.width(10.dp))
                        Icon(Icons.Default.Favorite, null, tint = BeraCoral, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Avatar(profile.partnerName.firstOrNull()?.uppercase() ?: "P", BeraOrange)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("${profile.displayName.ifBlank { "You" }} + ${profile.partnerName}", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("${profile.speaks} ↔ ${profile.learning}", color = Color.White.copy(.72f))
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DarkStat(verifiedCount.toString(), "verified")
                        DarkStat(voiceCount.toString(), "voice notes")
                        DarkStat((session?.completedTaskIds?.size ?: 0).toString(), "mission tasks")
                    }
                }
            }
        }
        item {
            Surface(color = Color.White, shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Current shared learning", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    if (session == null) {
                        Text("No mission has been created yet.", color = Muted)
                    } else {
                        Text(session.mission.title, color = Ink, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("${session.completedTaskIds.size} of ${session.mission.effectiveTasks.size} tasks completed", color = Muted)
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(progress = { missionProgress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = BeraTealDeep, trackColor = Soft)
                    }
                }
            }
        }
        item {
            Surface(color = Color.White, shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (profile.partnerName == "Waiting for partner") Icons.Default.People else Icons.Default.CheckCircle, null, tint = if (profile.partnerName == "Waiting for partner") BeraOrangeDeep else BeraTealDeep)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(if (profile.partnerName == "Waiting for partner") "Waiting for your partner to join" else "Your pair is connected", color = Ink, fontWeight = FontWeight.Black)
                        Text(if (profile.partnerName == "Waiting for partner") "When they join, their real name and voice activity will appear here." else "BeraTalk is using the shared pair, language bank, and real voice thread.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        if (voiceCount > 0) {
            item {
                Surface(modifier = Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 7.dp) {
                    Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(TealTint), contentAlignment = Alignment.Center) { Icon(Icons.Default.Mic, null, tint = BeraTealDeep) }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text("You started speaking together", style = MaterialTheme.typography.titleMedium, color = Ink)
                            Text("This milestone appears because the pair has real voice activity.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                Text("Sign out", color = Ink, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AiSettingsScreen(uiTheme: BeraUiTheme, onUiThemeChange: (BeraUiTheme) -> Unit, onBack: () -> Unit, onSettingsChanged: () -> Unit) {
    val context = LocalContext.current
    val secureSettings = remember { SecureAiSettings(context) }
    val router = remember { AiClientRouter(context) }
    val initial = remember { secureSettings.snapshot() }
    val scope = rememberCoroutineScope()

    var preferred by remember { mutableStateOf(initial.preferredProvider) }
    var geminiKey by remember { mutableStateOf(initial.geminiApiKey) }
    var openAiKey by remember { mutableStateOf(initial.openAiApiKey) }
    var geminiModel by remember { mutableStateOf(initial.geminiModel) }
    var openAiModel by remember { mutableStateOf(initial.openAiModel) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOpenAiKey by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf<AiProvider?>(null) }

    fun persistProvider(provider: AiProvider) {
        preferred = provider
        secureSettings.setPreferredProvider(provider)
        onSettingsChanged()
        status = when (provider) {
            AiProvider.AUTO -> "Auto mode: Gemini first, OpenAI fallback."
            AiProvider.GEMINI -> "Gemini is now the preferred AI provider."
            AiProvider.OPENAI -> "OpenAI is now the preferred AI provider."
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 14.dp, 20.dp, 34.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                Spacer(Modifier.width(4.dp))
                Column {
                    Text("Settings", style = MaterialTheme.typography.headlineLarge, color = Ink)
                    Text("Appearance, AI and private app controls.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Text("Appearance", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Border),
                shadowElevation = 7.dp
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Color theme", color = Ink, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("The background stays pure white. Accent color changes buttons, progress, selected tabs and hero panels.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(14.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        BeraUiTheme.entries.toList().chunked(2).forEach { rowThemes ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                rowThemes.forEach { option ->
                                    ThemeChoice(
                                        theme = option,
                                        selected = uiTheme == option,
                                        modifier = Modifier.weight(1f),
                                        onClick = { onUiThemeChange(option) }
                                    )
                                }
                                if (rowThemes.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Text("AI coach", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Border),
                shadowElevation = 6.dp
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("How BeraTalk uses AI", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "AI plans lessons, questions and practice. It is never allowed to invent Esan, Igala or another minority-language translation. Target-language wording must come from your verified bank or your partner.",
                        color = Ink.copy(alpha = .82f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        item {
            Text("Preferred provider", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AiProviderButton("Auto", preferred == AiProvider.AUTO, Modifier.weight(1f)) { persistProvider(AiProvider.AUTO) }
                AiProviderButton("Gemini", preferred == AiProvider.GEMINI, Modifier.weight(1f)) { persistProvider(AiProvider.GEMINI) }
                AiProviderButton("OpenAI", preferred == AiProvider.OPENAI, Modifier.weight(1f)) { persistProvider(AiProvider.OPENAI) }
            }
            Spacer(Modifier.height(8.dp))
            Text("Auto uses Gemini first and OpenAI as fallback when both keys are available.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        item {
            AiProviderSettingsBlock(
                title = "Gemini",
                description = "Used for lesson planning and guided conversation missions.",
                apiKey = geminiKey,
                onApiKeyChange = { geminiKey = it },
                model = geminiModel,
                onModelChange = { geminiModel = it },
                revealKey = showGeminiKey,
                onRevealChange = { showGeminiKey = !showGeminiKey },
                defaultModel = "gemini-3.7-flash",
                isTesting = testing == AiProvider.GEMINI,
                onSave = {
                    secureSettings.setGemini(geminiKey, geminiModel)
                    onSettingsChanged()
                    status = if (geminiKey.isBlank()) "Gemini key removed from this device." else "Gemini settings saved on this device."
                },
                onTest = {
                    secureSettings.setGemini(geminiKey, geminiModel)
                    onSettingsChanged()
                    testing = AiProvider.GEMINI
                    scope.launch {
                        val result = router.test(AiProvider.GEMINI)
                        status = result.fold(
                            onSuccess = { "Gemini connected successfully." },
                            onFailure = { "Gemini test failed: ${it.message ?: "Unknown error"}" }
                        )
                        testing = null
                    }
                }
            )
        }
        item {
            AiProviderSettingsBlock(
                title = "OpenAI",
                description = "Available as your second provider or Auto fallback.",
                apiKey = openAiKey,
                onApiKeyChange = { openAiKey = it },
                model = openAiModel,
                onModelChange = { openAiModel = it },
                revealKey = showOpenAiKey,
                onRevealChange = { showOpenAiKey = !showOpenAiKey },
                defaultModel = "gpt-5.6-luna",
                isTesting = testing == AiProvider.OPENAI,
                onSave = {
                    secureSettings.setOpenAi(openAiKey, openAiModel)
                    onSettingsChanged()
                    status = if (openAiKey.isBlank()) "OpenAI key removed from this device." else "OpenAI settings saved on this device."
                },
                onTest = {
                    secureSettings.setOpenAi(openAiKey, openAiModel)
                    onSettingsChanged()
                    testing = AiProvider.OPENAI
                    scope.launch {
                        val result = router.test(AiProvider.OPENAI)
                        status = result.fold(
                            onSuccess = { "OpenAI connected successfully." },
                            onFailure = { "OpenAI test failed: ${it.message ?: "Unknown error"}" }
                        )
                        testing = null
                    }
                }
            )
        }
        status?.let { message ->
            item {
                AnimatedVisibility(visible = true, enter = fadeIn(), exit = fadeOut()) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (message.contains("failed", ignoreCase = true)) BeraCoralDeep.copy(.35f) else Border),
                        shadowElevation = 4.dp
                    ) {
                        Text(message, Modifier.fillMaxWidth().padding(14.dp), color = Ink, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Text(
                "Security note: direct API keys are appropriate only for this private build. Do not distribute this APK publicly with personal provider keys saved in it.",
                color = Muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AiProviderButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val background by animateColorAsState(if (selected) BeraTealDeep else Color.White, label = "providerBackground")
    val foreground by animateColorAsState(if (selected) Color.White else Ink, label = "providerForeground")
    Surface(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        color = background,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) BeraTealDeep else Border)
    ) {
        Box(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), contentAlignment = Alignment.Center) {
            Text(label, color = foreground, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun AiProviderSettingsBlock(
    title: String,
    description: String,
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    model: String,
    onModelChange: (String) -> Unit,
    revealKey: Boolean,
    onRevealChange: () -> Unit,
    defaultModel: String,
    isTesting: Boolean,
    onSave: () -> Unit,
    onTest: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 7.dp
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(description, color = Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = apiKey,
                onValueChange = onApiKeyChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("API key") },
                visualTransformation = if (revealKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = onRevealChange) {
                        Icon(if (revealKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (revealKey) "Hide key" else "Show key", tint = Muted)
                    }
                },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = model,
                onValueChange = onModelChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Model") },
                supportingText = { Text("Default: $defaultModel") },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onTest,
                    enabled = apiKey.isNotBlank() && !isTesting,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (isTesting) "Testing…" else "Test", color = if (apiKey.isNotBlank() && !isTesting) Ink else Muted, fontWeight = FontWeight.Bold) }
                Button(
                    onClick = onSave,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
                ) { Text("Save", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable private fun Avatar(letter: String, color: Color) { Box(Modifier.size(54.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) { Text(letter, fontWeight = FontWeight.Black, color = Ink, style = MaterialTheme.typography.titleLarge) } }
@Composable private fun RowScope.DarkStat(value: String, label: String) { Column(Modifier.weight(1f)) { Text(value, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge); Text(label, color = Color.White.copy(.55f), style = MaterialTheme.typography.labelMedium) } }

@Composable
private fun ProgressBlock(title: String, values: List<Pair<String, Float>>, accent: Color) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(7.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(15.dp))
            values.forEach { (label, value) ->
                Row { Text(label, Modifier.weight(1f), color = Muted); Text("${(value * 100).toInt()}%", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(6.dp)); LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = accent, trackColor = Soft); Spacer(Modifier.height(13.dp))
            }
        }
    }
}

private fun currentGreeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = BeraTealDeep, contentColor = Color.White, disabledContainerColor = Soft, disabledContentColor = Muted)
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

