package com.beratalk.app.model

import java.util.UUID

enum class BankType(val label: String) { WORD("Words"), SENTENCE("Sentences"), CONVERSATION("Conversations"), STORY("Stories") }

enum class LessonTaskType { LISTEN, RECALL, SPEAK, CONVERSATION, ASK_PARTNER }

data class LanguageEntry(
    val id: String = UUID.randomUUID().toString(),
    val type: BankType = BankType.WORD,
    val language: String = "Esan",
    val nativeText: String = "",
    val meaning: String = "",
    val notes: String = "",
    val dialect: String = "",
    val audioPath: String? = null,
    val verified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class VoiceMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String = "me",
    val localAudioPath: String,
    val durationMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val correctionFor: String? = null
)

data class LessonTask(
    val id: String = UUID.randomUUID().toString(),
    val type: LessonTaskType,
    val title: String,
    val instruction: String,
    val entryId: String? = null,
    val durationSeconds: Int = 0
)

data class CoachChallenge(
    val title: String = "Keep the conversation moving",
    val instruction: String = "Use one verified phrase, then ask your partner a natural follow-up question.",
    val durationSeconds: Int = 60,
    val entryId: String? = null,
    val source: String = "local"
)

data class CoachNudge(
    val headline: String,
    val message: String,
    val source: String = "local"
)

data class Mission(
    val id: String,
    val title: String,
    val subtitle: String,
    val minutes: Int,
    val progress: Float = 0f,
    val steps: List<String> = emptyList(),
    val tasks: List<LessonTask> = emptyList(),
    val coachMessage: String = "",
    val source: String = "local"
) {
    val effectiveTasks: List<LessonTask>
        get() = if (tasks.isNotEmpty()) tasks else steps.mapIndexed { index, text ->
            LessonTask(
                id = "legacy-$index",
                type = if (index == steps.lastIndex) LessonTaskType.CONVERSATION else LessonTaskType.SPEAK,
                title = text,
                instruction = "Complete this step using real partner language."
            )
        }
}

data class LearningSession(
    val mission: Mission,
    val completedTaskIds: Set<String> = emptySet(),
    val reviewNotes: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val progress: Float
        get() = if (mission.effectiveTasks.isEmpty()) 0f else completedTaskIds.size.toFloat() / mission.effectiveTasks.size.toFloat()
}

data class AppProfile(
    val displayName: String = "",
    val speaks: String = "Esan",
    val learning: String = "Igala",
    val dialect: String = "",
    val dailyMinutes: Int = 10,
    val partnerName: String = "Partner",
    val pairId: String? = null
)
