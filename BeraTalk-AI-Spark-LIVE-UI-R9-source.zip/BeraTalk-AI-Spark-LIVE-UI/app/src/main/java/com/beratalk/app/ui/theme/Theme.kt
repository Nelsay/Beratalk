package com.beratalk.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * BeraTalk stays light and high-contrast by design. The app background and card
 * surfaces are true white; palette changes affect accent, progress, selected tabs,
 * hero panels and supporting tints rather than tinting the whole canvas.
 */
enum class BeraUiTheme(val key: String, val label: String) {
    VIOLET("violet", "Violet"),
    COBALT("cobalt", "Cobalt"),
    EMERALD("emerald", "Emerald"),
    TANGERINE("tangerine", "Tangerine");

    companion object {
        fun fromKey(key: String?): BeraUiTheme = entries.firstOrNull { it.key == key } ?: VIOLET
    }
}

data class BeraPalette(
    val accent: Color,
    val accentStrong: Color,
    val accentSoft: Color,
    val secondary: Color,
    val secondaryStrong: Color,
    val secondarySoft: Color,
    val tertiary: Color,
    val tertiaryStrong: Color,
    val tertiarySoft: Color
)

private fun palette(theme: BeraUiTheme): BeraPalette = when (theme) {
    BeraUiTheme.VIOLET -> BeraPalette(
        accent = Color(0xFF8B5CF6), accentStrong = Color(0xFF6D28D9), accentSoft = Color(0xFFF2EAFF),
        secondary = Color(0xFFEC4899), secondaryStrong = Color(0xFFBE185D), secondarySoft = Color(0xFFFCE7F3),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoft = Color(0xFFFFEAEC)
    )
    BeraUiTheme.COBALT -> BeraPalette(
        accent = Color(0xFF3B82F6), accentStrong = Color(0xFF1D4ED8), accentSoft = Color(0xFFE8F1FF),
        secondary = Color(0xFF06B6D4), secondaryStrong = Color(0xFF0E7490), secondarySoft = Color(0xFFCFFAFE),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoft = Color(0xFFFFEAEC)
    )
    BeraUiTheme.EMERALD -> BeraPalette(
        accent = Color(0xFF10B981), accentStrong = Color(0xFF047857), accentSoft = Color(0xFFDDF9EE),
        secondary = Color(0xFF8B5CF6), secondaryStrong = Color(0xFF6D28D9), secondarySoft = Color(0xFFF2EAFF),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoft = Color(0xFFFFEAEC)
    )
    BeraUiTheme.TANGERINE -> BeraPalette(
        accent = Color(0xFFF97316), accentStrong = Color(0xFFC2410C), accentSoft = Color(0xFFFFE9D8),
        secondary = Color(0xFF8B5CF6), secondaryStrong = Color(0xFF6D28D9), secondarySoft = Color(0xFFF2EAFF),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoft = Color(0xFFFFEAEC)
    )
}

private val LocalBeraPalette = staticCompositionLocalOf { palette(BeraUiTheme.VIOLET) }

// Semantic aliases retained across the app so the entire interface changes together.
val BeraTeal: Color @Composable get() = LocalBeraPalette.current.accent
val BeraTealDeep: Color @Composable get() = LocalBeraPalette.current.accentStrong
val BeraOrange: Color @Composable get() = LocalBeraPalette.current.secondary
val BeraOrangeDeep: Color @Composable get() = LocalBeraPalette.current.secondaryStrong
val BeraCoral: Color @Composable get() = LocalBeraPalette.current.tertiary
val BeraCoralDeep: Color @Composable get() = LocalBeraPalette.current.tertiaryStrong

val Ink = Color(0xFF0D0D0F)
val InkSoft = Color(0xFF242429)
val Muted = Color(0xFF6F6F78)
val Canvas = Color.White
val Soft = Color(0xFFF5F5F7)
val Border = Color(0xFFE9E9EE)
val White = Color.White
val TealTint: Color @Composable get() = LocalBeraPalette.current.accentSoft
val OrangeTint: Color @Composable get() = LocalBeraPalette.current.secondarySoft
val CoralTint: Color @Composable get() = LocalBeraPalette.current.tertiarySoft

private val family = FontFamily.SansSerif
private val typography = androidx.compose.material3.Typography(
    displaySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Black, fontSize = 35.sp, lineHeight = 40.sp, letterSpacing = (-1.0).sp),
    headlineLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp, lineHeight = 35.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 29.sp, letterSpacing = (-0.25).sp),
    titleLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 19.sp, letterSpacing = .06.sp),
    labelMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = .15.sp)
)

@Composable
fun BeraTalkTheme(theme: BeraUiTheme = BeraUiTheme.VIOLET, content: @Composable () -> Unit) {
    val p = palette(theme)
    val scheme = lightColorScheme(
        primary = p.accentStrong,
        secondary = p.secondaryStrong,
        tertiary = p.tertiaryStrong,
        background = Color.White,
        surface = Color.White,
        surfaceVariant = Soft,
        onPrimary = Color.White,
        onSecondary = Color.White,
        onTertiary = Color.White,
        onBackground = Ink,
        onSurface = Ink,
        onSurfaceVariant = InkSoft,
        outline = Border
    )
    CompositionLocalProvider(LocalBeraPalette provides p) {
        MaterialTheme(colorScheme = scheme, typography = typography, content = content)
    }
}
