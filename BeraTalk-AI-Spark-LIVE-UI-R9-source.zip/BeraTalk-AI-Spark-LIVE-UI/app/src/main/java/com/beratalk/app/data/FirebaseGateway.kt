package com.beratalk.app.data

import android.content.Context
import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.LearningSession
import com.beratalk.app.model.LessonTask
import com.beratalk.app.model.LessonTaskType
import com.beratalk.app.model.Mission
import com.beratalk.app.model.VoiceMessage
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.Blob
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class FirebaseGateway(private val context: Context) {
    companion object {
        private const val AUDIO_CHUNK_BYTES = 600 * 1024
        private const val MAX_AUDIO_BYTES = 12 * 1024 * 1024
        private const val FIRESTORE_AUDIO_PREFIX = "firestore://"
    }

    val configured: Boolean
        get() = FirebaseApp.getApps(context).isNotEmpty()

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    val currentUid: String? get() = if (configured) auth.currentUser?.uid else null
    val currentDisplayName: String
        get() = if (configured) {
            auth.currentUser?.displayName
                ?: auth.currentUser?.email?.substringBefore('@')
                ?: "You"
        } else "You"

    suspend fun signInEmail(email: String, password: String) {
        require(configured) { "Firebase is not configured yet. Add app/google-services.json." }
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun createEmailAccount(email: String, password: String) {
        require(configured) { "Firebase is not configured yet. Add app/google-services.json." }
        auth.createUserWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun signInGoogle(idToken: String) {
        require(configured) { "Firebase is not configured yet. Add app/google-services.json." }
        auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
    }

    fun signOut() {
        if (configured) auth.signOut()
    }

    suspend fun saveProfile(profile: AppProfile) {
        val uid = currentUid ?: return
        db.collection("users").document(uid).set(
            mapOf(
                "displayName" to profile.displayName,
                "speaks" to profile.speaks,
                "learning" to profile.learning,
                "dialect" to profile.dialect,
                "dailyMinutes" to profile.dailyMinutes,
                "pairId" to profile.pairId,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun loadProfile(): AppProfile? {
        val uid = currentUid ?: return null
        val doc = db.collection("users").document(uid).get().await()
        if (!doc.exists()) return null
        return AppProfile(
            displayName = doc.getString("displayName") ?: currentDisplayName,
            speaks = doc.getString("speaks") ?: "Esan",
            learning = doc.getString("learning") ?: "Igala",
            dialect = doc.getString("dialect") ?: "",
            dailyMinutes = (doc.getLong("dailyMinutes") ?: 10L).toInt(),
            pairId = doc.getString("pairId")
        )
    }

    suspend fun loadPartnerName(pairId: String): String {
        val uid = currentUid ?: return "Partner"
        val pair = db.collection("pairs").document(pairId).get().await()
        val members = (pair.get("members") as? List<*>)?.filterIsInstance<String>().orEmpty()
        val partnerUid = members.firstOrNull { it != uid } ?: return "Waiting for partner"
        val names = pair.get("memberNames") as? Map<*, *>
        return names?.get(partnerUid)?.toString()?.takeIf { it.isNotBlank() } ?: "Your partner"
    }

    suspend fun ensurePairMemberName(pairId: String) {
        val uid = currentUid ?: return
        db.collection("pairs").document(pairId).update("memberNames.$uid", currentDisplayName).await()
    }

    fun observePartnerName(pairId: String, onName: (String) -> Unit): ListenerRegistration? {
        if (!configured) return null
        val uid = currentUid ?: return null
        return db.collection("pairs").document(pairId).addSnapshotListener { snapshot, _ ->
            val members = (snapshot?.get("members") as? List<*>)?.filterIsInstance<String>().orEmpty()
            val partnerUid = members.firstOrNull { it != uid }
            if (partnerUid == null) {
                onName("Waiting for partner")
                return@addSnapshotListener
            }
            val names = snapshot?.get("memberNames") as? Map<*, *>
            onName(names?.get(partnerUid)?.toString()?.takeIf { it.isNotBlank() } ?: "Your partner")
        }
    }

    data class CreatedPair(val pairId: String, val inviteCode: String)

    suspend fun createPair(profile: AppProfile): CreatedPair {
        val uid = currentUid ?: error("Sign in first")
        val pairRef = db.collection("pairs").document()
        val code = pairRef.id.takeLast(6).uppercase()
        val batch = db.batch()
        batch.set(
            pairRef,
            mapOf(
                "members" to listOf(uid),
                "memberNames" to mapOf(uid to profile.displayName.ifBlank { currentDisplayName }),
                "ownerId" to uid,
                "inviteCode" to code,
                "createdAt" to FieldValue.serverTimestamp(),
                "languages" to listOf(profile.speaks, profile.learning)
            )
        )
        batch.set(
            db.collection("pairInvites").document(code),
            mapOf(
                "pairId" to pairRef.id,
                "ownerId" to uid,
                "active" to true,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(db.collection("users").document(uid), "pairId", pairRef.id)
        batch.commit().await()
        return CreatedPair(pairRef.id, code)
    }

    suspend fun joinPair(inviteCode: String): String {
        val uid = currentUid ?: error("Sign in first")
        val code = inviteCode.trim().uppercase()
        val invite = db.collection("pairInvites").document(code).get().await()
        require(invite.exists() && invite.getBoolean("active") == true) { "That invite code is not active." }
        val pairId = invite.getString("pairId") ?: error("Invite is incomplete")
        val pairRef = db.collection("pairs").document(pairId)
        val pair = pairRef.get().await()
        val members = (pair.get("members") as? List<*>)?.filterIsInstance<String>().orEmpty()
        require(members.size < 2 || uid in members) { "This language pair already has two people." }
        val batch = db.batch()
        batch.update(pairRef, mapOf(
            "members" to FieldValue.arrayUnion(uid),
            "memberNames.$uid" to currentDisplayName
        ))
        batch.update(db.collection("users").document(uid), "pairId", pairId)
        batch.update(db.collection("pairInvites").document(code), "active", false)
        batch.commit().await()
        return pairId
    }

    suspend fun addEntry(pairId: String, entry: LanguageEntry) {
        var audioMarker = entry.audioPath
        if (!audioMarker.isNullOrBlank()) {
            val local = File(audioMarker)
            if (local.exists()) {
                val audioId = storeAudio(pairId, local, purpose = "library")
                audioMarker = firestoreAudioMarker(pairId, audioId)
            }
        }
        db.collection("pairs").document(pairId).collection("languageEntries").document(entry.id)
            .set(
                mapOf(
                    "type" to entry.type.name,
                    "language" to entry.language,
                    "nativeText" to entry.nativeText,
                    "meaning" to entry.meaning,
                    "notes" to entry.notes,
                    "dialect" to entry.dialect,
                    "audioPath" to audioMarker,
                    "verified" to entry.verified,
                    "createdAt" to entry.createdAt
                )
            ).await()
    }

    suspend fun setEntryVerified(pairId: String, entryId: String, verified: Boolean) {
        db.collection("pairs").document(pairId).collection("languageEntries").document(entryId)
            .update("verified", verified).await()
    }

    fun observeEntries(pairId: String, onEntries: (List<LanguageEntry>) -> Unit): ListenerRegistration? {
        if (!configured) return null
        return db.collection("pairs").document(pairId).collection("languageEntries")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(500)
            .addSnapshotListener { snapshot, _ ->
                val entries = snapshot?.documents.orEmpty().mapNotNull { doc ->
                    val type = runCatching { com.beratalk.app.model.BankType.valueOf(doc.getString("type") ?: "WORD") }.getOrNull() ?: return@mapNotNull null
                    LanguageEntry(
                        id = doc.id,
                        type = type,
                        language = doc.getString("language") ?: "",
                        nativeText = doc.getString("nativeText") ?: "",
                        meaning = doc.getString("meaning") ?: "",
                        notes = doc.getString("notes") ?: "",
                        dialect = doc.getString("dialect") ?: "",
                        audioPath = doc.getString("audioPath"),
                        verified = doc.getBoolean("verified") ?: false,
                        createdAt = doc.getLong("createdAt") ?: 0L
                    )
                }
                onEntries(entries)
            }
    }

    private suspend fun storeAudio(pairId: String, localFile: File, purpose: String): String = withContext(Dispatchers.IO) {
        val uid = currentUid ?: error("Sign in first")
        require(localFile.exists()) { "Audio recording no longer exists." }
        require(localFile.length() in 1..MAX_AUDIO_BYTES.toLong()) {
            "That recording is too large for the Spark audio mode. Keep individual recordings below 12 MB."
        }

        val bytes = localFile.readBytes()
        val chunks = bytes.asList().chunked(AUDIO_CHUNK_BYTES).map { chunk -> chunk.toByteArray() }
        val audioId = UUID.randomUUID().toString()
        val assetRef = db.collection("pairs").document(pairId).collection("audioAssets").document(audioId)

        assetRef.set(
            mapOf(
                "ownerId" to uid,
                "purpose" to purpose,
                "contentType" to "audio/mp4",
                "sizeBytes" to bytes.size,
                "chunkCount" to chunks.size,
                "status" to "uploading",
                "createdAt" to System.currentTimeMillis()
            )
        ).await()

        chunks.chunked(450).forEachIndexed { batchIndex, chunkBatch ->
            val batch = db.batch()
            chunkBatch.forEachIndexed { offset, chunk ->
                val index = batchIndex * 450 + offset
                val chunkRef = assetRef.collection("chunks").document(index.toString().padStart(5, '0'))
                batch.set(
                    chunkRef,
                    mapOf(
                        "index" to index,
                        "data" to Blob.fromBytes(chunk),
                        "sizeBytes" to chunk.size
                    )
                )
            }
            batch.commit().await()
        }

        assetRef.update("status", "ready").await()
        audioId
    }

    suspend fun sendVoiceMessage(pairId: String, localFile: File, durationMs: Long, correctionFor: String? = null) {
        val uid = currentUid ?: error("Sign in first")
        val audioId = storeAudio(pairId, localFile, purpose = if (correctionFor == null) "voice" else "correction")
        val messageRef = db.collection("pairs").document(pairId).collection("messages").document()
        messageRef.set(
            mapOf(
                "senderId" to uid,
                "audioPath" to firestoreAudioMarker(pairId, audioId),
                "durationMs" to durationMs,
                "createdAt" to System.currentTimeMillis(),
                "correctionFor" to correctionFor
            )
        ).await()
    }

    fun observeMessages(pairId: String, onMessages: (List<VoiceMessage>) -> Unit): ListenerRegistration? {
        if (!configured) return null
        return db.collection("pairs").document(pairId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limitToLast(100)
            .addSnapshotListener { snapshot, _ ->
                val uid = currentUid.orEmpty()
                val messages = snapshot?.documents.orEmpty().mapNotNull { doc ->
                    val audio = doc.getString("audioPath") ?: doc.getString("audioUrl") ?: return@mapNotNull null
                    VoiceMessage(
                        id = doc.id,
                        senderId = doc.getString("senderId") ?: "",
                        localAudioPath = audio,
                        durationMs = doc.getLong("durationMs") ?: 0L,
                        createdAt = doc.getLong("createdAt") ?: 0L,
                        correctionFor = doc.getString("correctionFor")
                    )
                }
                onMessages(messages.map { if (it.senderId == uid) it.copy(senderId = "me") else it })
            }
    }

    suspend fun materializeAudioPath(path: String): String? = withContext(Dispatchers.IO) {
        if (path.isBlank()) return@withContext null
        if (!path.startsWith(FIRESTORE_AUDIO_PREFIX)) {
            return@withContext path
        }

        val ref = path.removePrefix(FIRESTORE_AUDIO_PREFIX)
        val slash = ref.indexOf('/')
        if (slash <= 0 || slash == ref.lastIndex) return@withContext null
        val pairId = ref.substring(0, slash)
        val audioId = ref.substring(slash + 1)
        val cacheDir = File(context.cacheDir, "firestore_audio/$pairId").apply { mkdirs() }
        val cached = File(cacheDir, "$audioId.m4a")
        if (cached.exists() && cached.length() > 0) return@withContext cached.absolutePath

        val assetRef = db.collection("pairs").document(pairId).collection("audioAssets").document(audioId)
        val asset = assetRef.get().await()
        if (!asset.exists() || asset.getString("status") != "ready") return@withContext null

        val chunks = assetRef.collection("chunks").orderBy("index", Query.Direction.ASCENDING).get().await()
        if (chunks.isEmpty) return@withContext null
        cached.outputStream().buffered().use { output ->
            chunks.documents.forEach { doc ->
                val blob = doc.getBlob("data") ?: return@forEach
                output.write(blob.toBytes())
            }
        }
        cached.takeIf { it.length() > 0 }?.absolutePath
    }


    suspend fun saveLearningSession(pairId: String, session: LearningSession) {
        val uid = currentUid ?: return
        val mission = session.mission
        val taskMaps = mission.effectiveTasks.map { task ->
            mapOf(
                "id" to task.id,
                "type" to task.type.name,
                "title" to task.title,
                "instruction" to task.instruction,
                "entryId" to task.entryId,
                "durationSeconds" to task.durationSeconds
            )
        }
        db.collection("pairs").document(pairId).collection("learningStates").document(uid).set(
            mapOf(
                "missionId" to mission.id,
                "title" to mission.title,
                "subtitle" to mission.subtitle,
                "minutes" to mission.minutes,
                "coachMessage" to mission.coachMessage,
                "source" to mission.source,
                "tasks" to taskMaps,
                "completedTaskIds" to session.completedTaskIds.toList(),
                "reviewNotes" to session.reviewNotes.takeLast(20),
                "updatedAt" to System.currentTimeMillis()
            )
        ).await()
    }

    suspend fun loadLearningSession(pairId: String): LearningSession? {
        val uid = currentUid ?: return null
        val doc = db.collection("pairs").document(pairId).collection("learningStates").document(uid).get().await()
        if (!doc.exists()) return null
        val taskMaps = (doc.get("tasks") as? List<*>)?.mapNotNull { it as? Map<*, *> }.orEmpty()
        val tasks = taskMaps.mapNotNull { map ->
            val type = runCatching { LessonTaskType.valueOf(map["type"]?.toString().orEmpty()) }.getOrNull() ?: return@mapNotNull null
            LessonTask(
                id = map["id"]?.toString().orEmpty().ifBlank { UUID.randomUUID().toString() },
                type = type,
                title = map["title"]?.toString().orEmpty(),
                instruction = map["instruction"]?.toString().orEmpty(),
                entryId = map["entryId"]?.toString()?.takeIf { it.isNotBlank() && it != "null" },
                durationSeconds = (map["durationSeconds"] as? Number)?.toInt() ?: 0
            )
        }
        if (tasks.isEmpty()) return null
        val mission = Mission(
            id = doc.getString("missionId") ?: "saved-${System.currentTimeMillis()}",
            title = doc.getString("title") ?: "Today's conversation",
            subtitle = doc.getString("subtitle") ?: "Continue where you left off.",
            minutes = (doc.getLong("minutes") ?: 10L).toInt(),
            steps = tasks.map { it.title },
            tasks = tasks,
            coachMessage = doc.getString("coachMessage") ?: "",
            source = doc.getString("source") ?: "saved"
        )
        val completed = (doc.get("completedTaskIds") as? List<*>)?.mapNotNull { it?.toString() }?.toSet().orEmpty()
        val reviewNotes = (doc.get("reviewNotes") as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
        return LearningSession(
            mission = mission,
            completedTaskIds = completed,
            reviewNotes = reviewNotes,
            updatedAt = doc.getLong("updatedAt") ?: 0L
        )
    }

    private fun firestoreAudioMarker(pairId: String, audioId: String): String = "$FIRESTORE_AUDIO_PREFIX$pairId/$audioId"
}
