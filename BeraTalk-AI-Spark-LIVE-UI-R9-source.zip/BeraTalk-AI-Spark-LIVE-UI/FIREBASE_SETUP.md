# BeraTalk Firebase setup

Firebase project: `beratalk-73895`
Android package: `com.beratalk.app`

The provided `google-services.json` is already installed at `app/google-services.json`.

## Release signing fingerprints
SHA-1
`AB:7F:24:1F:E4:6C:D1:5C:7F:D9:94:86:06:1F:F1:53:2D:0B:8B:96`

SHA-256
`D5:EF:96:F2:3D:62:11:3F:61:E7:A9:2D:69:D5:97:2D:A2:C7:43:15:BB:BD:22:C8:3C:1D:9F:48:BB:A8:6A:83`

The SHA-1 in the supplied Firebase Android OAuth client matches this release certificate.

## Firebase console switches required
1. Authentication → Sign-in method → enable **Email/Password**.
2. Authentication → Sign-in method → enable **Google**.
3. Firestore Database → create database, then deploy the **v1.1.0-live** `firebase/firestore.rules`. The updated rules include private learner `learningStates` and pair member-name updates used by the real partner UI.
4. No Cloud Storage setup is required on Spark for this build.

No other sign-in methods are required for this build.

## Spark plan note

Cloud Storage is NOT used by this build. Do not enable or deploy Firebase Storage rules. BeraTalk stores compressed voice audio as chunked Firestore byte documents during the private two-person phase.

## Firestore index exemption for audio chunks
Keep the single-field index exemption for collection group `chunks`, field `data`. No composite index is required for this.

## v1.1.0-live data additions
- `pairs/{pairId}.memberNames` stores display names for the two pair members.
- `pairs/{pairId}/learningStates/{uid}` stores only that learner's current mission, completion IDs and review notes.
- `pairs/{pairId}/languageEntries/{entryId}.verified` determines whether AI is allowed to use that entry. Draft (`verified=false`) material stays visible in Library but is not supplied to the AI lesson engine.
