package com.beratalk.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class BeraUiTheme(val key: String, val label: String) {
    VIOLET("violet", "Violet"),
    COBALT("cobalt", "Cobalt"),
    EMERALD("emerald", "Emerald"),
    TANGERINE("tangerine", "Tangerine");

    companion object {
        fun fromKey(key: String?): BeraUiTheme = entries.firstOrNull { it.key == key } ?: VIOLET
    }
}

data class BeraPalette(
    val accent: Color,
    val accentStrong: Color,
    val accentSoftLight: Color,
    val accentSoftDark: Color,
    val secondary: Color,
    val secondaryStrong: Color,
    val secondarySoftLight: Color,
    val secondarySoftDark: Color,
    val tertiary: Color,
    val tertiaryStrong: Color,
    val tertiarySoftLight: Color,
    val tertiarySoftDark: Color
)

private fun palette(theme: BeraUiTheme): BeraPalette = when (theme) {
    BeraUiTheme.VIOLET -> BeraPalette(
        accent = Color(0xFF8B5CF6), accentStrong = Color(0xFF6D28D9), accentSoftLight = Color(0xFFF2EAFF), accentSoftDark = Color(0xFF2A2039),
        secondary = Color(0xFFEC4899), secondaryStrong = Color(0xFFBE185D), secondarySoftLight = Color(0xFFFCE7F3), secondarySoftDark = Color(0xFF38202C),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoftLight = Color(0xFFFFEAEC), tertiarySoftDark = Color(0xFF3A2226)
    )
    BeraUiTheme.COBALT -> BeraPalette(
        accent = Color(0xFF3B82F6), accentStrong = Color(0xFF1D4ED8), accentSoftLight = Color(0xFFE8F1FF), accentSoftDark = Color(0xFF172A47),
        secondary = Color(0xFF06B6D4), secondaryStrong = Color(0xFF0E7490), secondarySoftLight = Color(0xFFCFFAFE), secondarySoftDark = Color(0xFF173138),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoftLight = Color(0xFFFFEAEC), tertiarySoftDark = Color(0xFF3A2226)
    )
    BeraUiTheme.EMERALD -> BeraPalette(
        accent = Color(0xFF10B981), accentStrong = Color(0xFF047857), accentSoftLight = Color(0xFFDDF9EE), accentSoftDark = Color(0xFF173129),
        secondary = Color(0xFF8B5CF6), secondaryStrong = Color(0xFF6D28D9), secondarySoftLight = Color(0xFFF2EAFF), secondarySoftDark = Color(0xFF2A2039),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoftLight = Color(0xFFFFEAEC), tertiarySoftDark = Color(0xFF3A2226)
    )
    BeraUiTheme.TANGERINE -> BeraPalette(
        accent = Color(0xFFF97316), accentStrong = Color(0xFFC2410C), accentSoftLight = Color(0xFFFFE9D8), accentSoftDark = Color(0xFF3B291B),
        secondary = Color(0xFF8B5CF6), secondaryStrong = Color(0xFF6D28D9), secondarySoftLight = Color(0xFFF2EAFF), secondarySoftDark = Color(0xFF2A2039),
        tertiary = Color(0xFFFF5A67), tertiaryStrong = Color(0xFFB42331), tertiarySoftLight = Color(0xFFFFEAEC), tertiarySoftDark = Color(0xFF3A2226)
    )
}

private val LocalBeraPalette = staticCompositionLocalOf { palette(BeraUiTheme.VIOLET) }
private val LocalBeraDarkMode = staticCompositionLocalOf { false }

val IsBeraDark: Boolean @Composable get() = LocalBeraDarkMode.current
val BeraTeal: Color @Composable get() = LocalBeraPalette.current.accent
val BeraTealDeep: Color @Composable get() = LocalBeraPalette.current.accentStrong
val BeraOrange: Color @Composable get() = LocalBeraPalette.current.secondary
val BeraOrangeDeep: Color @Composable get() = LocalBeraPalette.current.secondaryStrong
val BeraCoral: Color @Composable get() = LocalBeraPalette.current.tertiary
val BeraCoralDeep: Color @Composable get() = LocalBeraPalette.current.tertiaryStrong

val Ink: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFFF7F7F8) else Color(0xFF0D0D0F)
val InkSoft: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFFD4D4D8) else Color(0xFF242429)
val Muted: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFFA5A5AE) else Color(0xFF6F6F78)
val Canvas: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFF111112) else Color.White
val SurfaceTone: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFF1B1B1D) else Color.White
val Soft: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFF262629) else Color(0xFFF5F5F7)
val Border: Color @Composable get() = if (LocalBeraDarkMode.current) Color(0xFF343438) else Color(0xFFE9E9EE)
val White = Color.White
val ActionColor: Color @Composable get() = if (LocalBeraDarkMode.current) Color.White else Color.Black
val OnActionColor: Color @Composable get() = if (LocalBeraDarkMode.current) Color.Black else Color.White
val TealTint: Color @Composable get() = if (LocalBeraDarkMode.current) LocalBeraPalette.current.accentSoftDark else LocalBeraPalette.current.accentSoftLight
val OrangeTint: Color @Composable get() = if (LocalBeraDarkMode.current) LocalBeraPalette.current.secondarySoftDark else LocalBeraPalette.current.secondarySoftLight
val CoralTint: Color @Composable get() = if (LocalBeraDarkMode.current) LocalBeraPalette.current.tertiarySoftDark else LocalBeraPalette.current.tertiarySoftLight

private val family = FontFamily.SansSerif
private val typography = androidx.compose.material3.Typography(
    displaySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Black, fontSize = 35.sp, lineHeight = 40.sp, letterSpacing = (-1.0).sp),
    headlineLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp, lineHeight = 35.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 29.sp, letterSpacing = (-0.25).sp),
    titleLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 19.sp, letterSpacing = .06.sp),
    labelMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = .15.sp)
)

@Composable
fun BeraTalkTheme(theme: BeraUiTheme = BeraUiTheme.VIOLET, darkMode: Boolean = false, content: @Composable () -> Unit) {
    val p = palette(theme)
    val scheme = if (darkMode) {
        darkColorScheme(
            primary = p.accent,
            secondary = p.secondary,
            tertiary = p.tertiary,
            background = Color(0xFF111112),
            surface = Color(0xFF1B1B1D),
            surfaceVariant = Color(0xFF262629),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color(0xFFF7F7F8),
            onSurface = Color(0xFFF7F7F8),
            onSurfaceVariant = Color(0xFFD4D4D8),
            outline = Color(0xFF343438)
        )
    } else {
        lightColorScheme(
            primary = p.accentStrong,
            secondary = p.secondaryStrong,
            tertiary = p.tertiaryStrong,
            background = Color.White,
            surface = Color.White,
            surfaceVariant = Color(0xFFF5F5F7),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color(0xFF0D0D0F),
            onSurface = Color(0xFF0D0D0F),
            onSurfaceVariant = Color(0xFF242429),
            outline = Color(0xFFE9E9EE)
        )
    }
    CompositionLocalProvider(LocalBeraPalette provides p, LocalBeraDarkMode provides darkMode) {
        MaterialTheme(colorScheme = scheme, typography = typography, content = content)
    }
}
