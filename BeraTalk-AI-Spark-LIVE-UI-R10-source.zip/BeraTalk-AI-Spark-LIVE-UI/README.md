# BeraTalk Android — 1.3.0-chat-nav-dark

BeraTalk is a private two-person, voice-first language-learning app: **learn their language from them**. The native speaker supplies real language, pronunciation, dialect and context; AI structures that verified material into active practice and conversation.

## This build is runtime-driven, not demo-driven
- No `DemoData` boot content.
- No developer preview pair or fabricated partner activity.
- No fake waveform standing in for audio.
- No hard-coded relationship statistics.
- No empty Add action.
- Empty states remain genuinely empty until the couple adds language or sends voice notes.

## Runtime learning loop
1. Real partner language is saved in the Library as **Native confirmed** or **Draft**.
2. Only verified material can enter AI lessons/challenges.
3. Gemini/OpenAI receives a compact verified-bank representation and may select material only by `entry_id`.
4. BeraTalk renders task-specific interactions: Listen, Recall, Speak, Conversation or Ask Partner.
5. Completed tasks and “review again” notes are persisted.
6. Later AI missions receive those weaknesses and adapt the sequence.
7. Chat receives a fresh timed AI conversation challenge grounded in verified entries.

If AI is not configured or a request fails, the safety engine creates a useful mission from verified entries without inventing target-language wording. If the bank is empty, the task is to collect real language from the partner.

## Voice behavior
- Partner voice notes stay real audio; there is no forced transcription.
- Speech clips are AAC MPEG-4, 32 kbps / 32 kHz.
- Private Spark-stage audio uses Firestore chunking instead of Cloud Storage.
- Speaking practice records the learner, displays a live microphone-level animation from the recorder, and lets the learner compare against the partner's real clip.
- AI does **not** pretend it can certify minority-language pronunciation when no trustworthy model exists.

## Main navigation
Home · Chat · Learn

Library opens from the separate `+` action. **Us** opens from the profile image.

## AI settings
Open **Us → Settings** to choose the app color theme and add/test Gemini/OpenAI keys. Appearance changes apply immediately and persist on-device. Runtime keys are encrypted locally and excluded from backup. See `AI_SETUP.md`.

## Firebase setup
Deploy the updated `firebase/firestore.rules`. v1.1.0 adds private per-user `learningStates` inside the pair and pair `memberNames` for the real partner UI. See `FIREBASE_SETUP.md`.

## Signed build
Use the repository-root workflow `BeraTalk-build-R10-USE-THIS.yml` as `.github/workflows/beratalk-build-r10.yml`, or the copy included at `.github/workflows/build-signed-apk.yml` if the source itself is checked out directly. The workflow builds `BeraTalk-1.3.0-chat-nav-dark-signed.apk`.

## Signing
Keep `signing/beratalk-release.jks` private and unchanged. Future updates must use the same application ID and certificate.
