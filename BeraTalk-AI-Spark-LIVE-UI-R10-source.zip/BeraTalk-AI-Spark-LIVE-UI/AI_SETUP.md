# BeraTalk AI setup — private app

BeraTalk 1.3.0-chat-nav-dark supports Gemini and OpenAI as the runtime coaching engine for missions, adaptive task sequencing, coaching nudges and live conversation challenges.

## Add keys in the app
1. Sign in to BeraTalk.
2. Open **Us**.
3. Tap the **Settings** gear.
4. Under **AI settings**, paste your Gemini and/or OpenAI API key.
5. Leave the default model or type another model ID available to your account.
6. Tap **Save**.
7. Tap **Test** to make a real connection request.

## Provider modes
- **Auto**: Gemini first, OpenAI fallback.
- **Gemini**: Gemini only.
- **OpenAI**: OpenAI only.

Current editable defaults:
- Gemini: `gemini-3.7-flash`
- OpenAI: `gpt-5.6-luna`

## Key handling
- Keys are entered at runtime; they are not hard-coded in the source.
- Keys are encrypted with AES/GCM using an Android Keystore key.
- AI key preferences are excluded from Android backup.
- Keys are not stored in Firestore and are not included in language-pack exports.

This direct-key approach is intentionally for a private APK. Before BeraTalk is distributed publicly, move provider calls behind a secure backend/proxy and remove personal API keys from client devices.

## What the AI actually does
- Builds a structured mission from verified language-bank entries.
- Chooses Listen / Recall / Speak / Conversation / Ask Partner tasks.
- Generates a fresh timed Chat challenge.
- Gives the next coaching nudge after a task.
- Receives recent “review again” weaknesses so later missions can adapt.

If neither provider is configured or a provider request fails, BeraTalk uses a local safety engine that still uses only verified bank material. It does not substitute canned Esan/Igala phrases.

## Minority-language safety rule
AI plans lessons but is not treated as the source of truth for Esan, Igala, or future under-resourced languages. Target-language wording must come from verified language-bank entries or the learner's partner. If the verified bank is insufficient, the AI is instructed to ask the learner to obtain the missing phrase from the partner instead of inventing a translation.
