# BeraTalk UI/UX QA — v1.3.0-chat-nav-dark

## Interaction model
- Fixed bottom navigation; no swipe-driven main tabs.
- Progressive sign-in/setup with one decision at a time.
- Home has one dominant mission surface and real activity counts only.
- Learn exposes one current task, then transitions to the next.
- Chat is the real partner voice thread, not a simulated conversation.
- Library distinguishes Draft vs Native confirmed material.
- Us uses only real pair/activity/progress state.

## Real motion
- Setup step transitions use `AnimatedContent`.
- Main-tab content crossfades.
- Mission progress animates as persisted tasks complete.
- AI/building state has a continuously animated progress sweep and presence pulse.
- Learn tasks transition with `AnimatedContent`.
- AI coach response appears with animated visibility.
- Recording controls pulse and render live microphone amplitude.
- Voice playback animates its active state.
- Timed conversation challenges count down and refresh when complete.

These animations are tied to runtime state; they are not looping decorative GIFs or fixed fake waveforms.

## Visual system
- Pure white `#FFFFFF` page canvas and ordinary card surfaces.
- Near-black `#0D0D0F` primary text and readable `#6F6F78` secondary text.
- Default accent is violet with pink support; selectable Cobalt, Emerald and Tangerine themes are available in Settings.
- Accent is concentrated in selected navigation, primary buttons, progress and hero panels.
- Ordinary content cards remain white with subtle borders and 6–10dp elevation.
- The selected bottom-tab icon sits in a filled circular accent control with a white glyph.
- 20–24dp outer spacing, generous vertical rhythm and 22–30dp corner radii keep screens open and organized.
- The brand mark and BeraTalk wordmark are black; the launcher uses a bold abstract lowercase `bt` monogram on white.

## Placeholder regression checks
R10 fails before compilation if it finds `DemoData`, `FakeWave`, `PartnerVoiceBubble`, `preview-pair`, `BERA01`, or an empty `onClick = {}` in app runtime source.


## 1.3.0 chat / navigation / dark-mode refinement
- Pure white app canvas and white elevated cards; no off-white page background.
- Default Violet palette with user-selectable Violet, Cobalt, Emerald and Tangerine themes in Settings.
- Custom bottom navigation uses a colored circular selected icon with a white glyph, inspired by the supplied transit-app reference.
- Stronger 6–10dp card elevation, larger rounded corners, consistent 18–24dp screen spacing and clearer hierarchy.
- Home, Learn, Chat challenge and Us hero surfaces use controlled accent gradients; ordinary cards remain white.
- Black BeraTalk wordmark and bold abstract lowercase bt monogram replace the former multicolor speech-wave logo.
- Launcher icon is a black lowercase bt monogram on white.
- Theme changes persist locally and apply immediately to buttons, progress, selected tabs, hero panels and accent states.
- Existing real AI, Firestore, audio, verification and adaptive-learning behavior is preserved.


## R10 interaction checks

- Android Back returns Chat/Learn to Home; Library/Us return to the prior main tab; Settings closes before exiting.
- Bottom navigation exposes only Home, Chat and Learn.
- The separate + action opens a compact Library menu.
- Tapping the real profile avatar opens Us.
- Light and Dark modes persist locally.
- Light mode uses pure-white background/card surfaces and black neutral primary actions; accent colors are separate.
- Chat is a restrained bubble thread. Message controls are hidden until a bubble is tapped.
- Selected voice messages expose Play slower, Ask meaning and Add phrase; partner messages also expose the existing Correct action.
- Play slower is backed by MediaPlayer playback parameters, not a visual placeholder.
- Add phrase opens the real Library add-entry sheet.
- AI conversation challenge remains live but is collapsed by default.
