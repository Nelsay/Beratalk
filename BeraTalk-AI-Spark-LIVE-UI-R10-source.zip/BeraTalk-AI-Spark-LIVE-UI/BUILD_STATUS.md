# BeraTalk build status — v1.3.0-chat-nav-dark

- Package: `com.beratalk.app`
- Version: `1.3.0-chat-nav-dark` (`versionCode 7`)
- compileSdk: 37
- targetSdk: 36
- AGP: 9.4.0
- Gradle CI: 9.6.0
- JDK: 17
- Source QA: Kotlin parser-level scan, XML/JSON validation, placeholder regression scan and signing identity check are performed before CI.
- CI workflow: `BeraTalk Build R10 — CHAT NAV DARK`.
- Expected artifact: `BeraTalk-1.3.0-chat-nav-dark-signed.apk`.

A successful Android APK is only claimed after GitHub Actions completes the actual Android build.
