# BeraTalk build status — v1.2.0-ui

- Android package: `com.beratalk.app`
- Version: `1.2.0-ui` (`versionCode 6`)
- Firebase project wired through `app/google-services.json`
- Email/password auth: wired
- Google Sign-In: wired
- Pair create/join + real partner-name metadata: wired
- Firestore language bank and voice thread: wired
- Firebase Cloud Storage: **not used**
- Voice notes: AAC speech audio stored as private chunked Firestore byte documents
- Gemini + OpenAI: runtime keys in Settings, encrypted locally with Android Keystore
- AI runtime: mission creation, verified-entry task selection, conversation challenges and post-task coach nudges
- Adaptive state: completed task IDs and “review again” notes persist in Firestore per learner
- Language safety: draft entries are excluded from AI lessons; AI may only select verified bank entry IDs
- Real speaking practice: microphone recording + live `MediaRecorder.maxAmplitude` meter + playback comparison against partner audio
- Chat: real voice messages only; no fabricated partner message/waveform
- Release keystore: retained for update continuity

## Verification status
Static Kotlin syntax checks, JSON/XML checks and placeholder-code scans are performed before packaging. A full Android/Gradle compile still requires the Android SDK build runner. Use the included R7 GitHub Actions workflow for the real signed APK build; do not treat static QA as a successful APK compile.
