# BeraTalk UI/UX QA — v1.0.3-ux

## Lessons carried over from Prepwise/Bera-style builds
- Do not use a giant onboarding form: BeraTalk now reveals one setup decision at a time.
- Do not expose the entire learning path as a wall of cards: Learn shows only the current task and progress.
- Keep fixed bottom navigation; no swipe-driven main navigation.
- Maintain generous top safe-area spacing and 20–24dp horizontal screen padding.
- Do not make every information unit its own card: Home actions and shared progress are consolidated.
- Avoid placeholder/gimmicky branding: the chat header uses the BeraTalk mark, not an emoji.
- Optional contribution metadata is hidden until requested so adding a word/sentence stays quick.

## Contrast system
- Main text: #111315 on light surfaces.
- Secondary text: #626970 on white/light surfaces.
- Bright teal/orange/coral are accent fills; dark foreground is used on bright fills.
- Deep teal/orange/coral variants are used for colored text/icons on white.
- Dark mission/profile surfaces use white or high-opacity light text.

## Spacing / hierarchy
- Main screens: 20dp horizontal padding; sign-in: 24dp.
- Primary vertical rhythm: 16–18dp.
- Primary action height: 58dp.
- Main cards: 22–28dp radius; restrained 1–3dp support elevation.
- Strong elevation is reserved for primary mission focus, not every card.

## Motion
- Auth logo has subtle breathing motion.
- Setup changes use AnimatedContent.
- Bottom tabs crossfade.
- Current lesson task transitions with AnimatedContent.
- Mission card has press-scale feedback.
- Recording has pulse + live duration.
- AI status uses animated visibility.

## Build pipeline correction
- The workflow never assumes the repository root is the Android root.
- It validates package `com.beratalk.app`, finds `settings.gradle(.kts)` or extracts a BeraTalk source ZIP, then builds with `gradle -p "$PROJECT_DIR"`.
