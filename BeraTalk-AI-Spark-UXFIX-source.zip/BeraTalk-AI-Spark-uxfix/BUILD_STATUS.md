# BeraTalk build status

Current source: **1.0.6-api36fix** (`versionCode 7`).

Build compatibility matrix:
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.3.21 (AGP built-in Kotlin)
- JDK 17
- compileSdk 36 / targetSdk 36 / minSdk 26
- Compose BOM 2026.06.00
- Activity Compose 1.11.0 (API-36 compiled)
- AndroidX Core KTX 1.17.0 (API-36 compatible)
- Lifecycle Runtime KTX 2.10.0 (pre-API-37 release)

The API-37-only AndroidX versions that blocked R5 (`core 1.19.0` and Lifecycle `2.11.0`) were removed. Unused lifecycle Compose/ViewModel Compose dependencies were also removed to reduce AAR metadata and compile surface.

Firebase identity and the existing test signing configuration are unchanged.
