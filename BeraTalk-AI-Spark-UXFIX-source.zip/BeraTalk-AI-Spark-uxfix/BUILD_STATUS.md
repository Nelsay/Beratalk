# BeraTalk build status — Spark + dual AI edition

- Firebase project wired through `app/google-services.json`
- Android package: `com.beratalk.app`
- Version: `1.0.3-ux` (`versionCode 4`)
- Email/password auth: wired
- Google Sign-In: wired
- Firestore: wired
- Firebase Cloud Storage: **not used**
- Voice notes: compressed speech audio stored as private chunked Firestore byte documents
- Gemini API: direct private-app integration via runtime Settings key
- OpenAI Responses API: direct private-app integration via runtime Settings key
- AI modes: Auto / Gemini / OpenAI
- AI key storage: encrypted locally with Android Keystore; excluded from backup
- AI connection testing: wired in Settings
- AI lesson engine: live provider call with safe local fallback
- Minority-language rule: AI may organize verified content but may not invent target-language translations
- Release keystore: retained for update continuity

The source is build-ready. The GitHub workflow now detects the actual Android project directory (including when the source is nested inside the ZIP) and builds with `gradle -p "$PROJECT_DIR"`, avoiding the repository-root failure seen in the previous run.
