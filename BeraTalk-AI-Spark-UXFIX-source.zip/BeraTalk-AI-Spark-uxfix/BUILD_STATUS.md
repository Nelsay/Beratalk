# BeraTalk build status

Current source: **1.0.5-fullfix** (`versionCode 6`).

Build compatibility sweep:
- AGP 9.4.0 / Gradle 9.6 / JDK 17
- AGP built-in Kotlin enabled; legacy Kotlin Android plugin is declared `apply false` only for R5 verifier compatibility and is NOT applied to the app module
- Compose BOM pinned to 2026.06.00 to stay compatible with compileSdk 36 and the existing R5 workflow
- targetSdk 36 / minSdk 26
- Firebase BoM 34.18.0
- Credential Manager 1.6.0 + Google ID 1.2.0
- kotlinx-coroutines-android 1.11.0 explicitly included
- release signing identity preserved

The source is intended to be built by **BeraTalk Build R5 — WORKSPACE SAFE**.
