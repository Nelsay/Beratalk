plugins {
    id("com.android.application") version "9.4.0" apply false
    // R5 verifier compatibility marker only; DO NOT apply the legacy plugin: org.jetbrains.kotlin.android") version "2.3.21"
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
    id("com.google.gms.google-services") version "4.5.0" apply false
}
