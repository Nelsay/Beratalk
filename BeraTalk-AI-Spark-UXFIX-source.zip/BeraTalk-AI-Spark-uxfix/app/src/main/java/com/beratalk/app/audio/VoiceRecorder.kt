package com.beratalk.app.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var startedAt = 0L
    var currentFile: File? = null
        private set

    fun start(): File {
        stopSilently()
        val dir = File(context.filesDir, "voice").apply { mkdirs() }
        val file = File(dir, "voice_${System.currentTimeMillis()}.m4a")
        val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
        mediaRecorder.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(32_000)
            setAudioSamplingRate(32_000)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = mediaRecorder
        currentFile = file
        startedAt = System.currentTimeMillis()
        return file
    }

    fun stop(): Pair<File?, Long> {
        val elapsed = (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        return currentFile to elapsed
    }

    fun cancel() {
        val file = stop().first
        file?.delete()
        currentFile = null
    }

    private fun stopSilently() {
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
    }
}

class VoicePlayer {
    private var player: MediaPlayer? = null

    fun play(path: String, speed: Float = 1f, onDone: () -> Unit = {}) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(path)
            setOnPreparedListener { prepared ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    runCatching { prepared.playbackParams = prepared.playbackParams.setSpeed(speed.coerceIn(.5f, 1.5f)) }
                }
                prepared.start()
            }
            setOnCompletionListener { onDone(); stop() }
            setOnErrorListener { _, _, _ -> stop(); true }
            prepareAsync()
        }
    }

    fun stop() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }
}
