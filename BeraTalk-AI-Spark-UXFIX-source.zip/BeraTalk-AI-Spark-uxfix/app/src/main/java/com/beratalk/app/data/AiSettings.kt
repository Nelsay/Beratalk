package com.beratalk.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class AiProvider { AUTO, GEMINI, OPENAI }

data class AiSettingsSnapshot(
    val preferredProvider: AiProvider = AiProvider.AUTO,
    val geminiApiKey: String = "",
    val openAiApiKey: String = "",
    val geminiModel: String = "gemini-3.5-flash",
    val openAiModel: String = "gpt-5.6-luna"
)

/**
 * Stores AI credentials only on this Android device.
 * API keys are encrypted using an AES/GCM key generated in Android Keystore.
 * Keys are never written to Firestore, exported language packs, logs, or source code.
 */
class SecureAiSettings(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("beratalk_ai_settings", Context.MODE_PRIVATE)
    private val keyAlias = "beratalk_ai_settings_key_v1"

    fun snapshot(): AiSettingsSnapshot = AiSettingsSnapshot(
        preferredProvider = runCatching {
            AiProvider.valueOf(prefs.getString("provider", AiProvider.AUTO.name) ?: AiProvider.AUTO.name)
        }.getOrDefault(AiProvider.AUTO),
        geminiApiKey = decrypt(prefs.getString("gemini_key", null)).orEmpty(),
        openAiApiKey = decrypt(prefs.getString("openai_key", null)).orEmpty(),
        geminiModel = prefs.getString("gemini_model", "gemini-3.5-flash").orEmpty().ifBlank { "gemini-3.5-flash" },
        openAiModel = prefs.getString("openai_model", "gpt-5.6-luna").orEmpty().ifBlank { "gpt-5.6-luna" }
    )

    fun setPreferredProvider(provider: AiProvider) {
        prefs.edit().putString("provider", provider.name).apply()
    }

    fun setGemini(apiKey: String, model: String) {
        val edit = prefs.edit().putString("gemini_model", model.trim().ifBlank { "gemini-3.5-flash" })
        if (apiKey.isBlank()) edit.remove("gemini_key") else edit.putString("gemini_key", encrypt(apiKey.trim()))
        edit.apply()
    }

    fun setOpenAi(apiKey: String, model: String) {
        val edit = prefs.edit().putString("openai_model", model.trim().ifBlank { "gpt-5.6-luna" })
        if (apiKey.isBlank()) edit.remove("openai_key") else edit.putString("openai_key", encrypt(apiKey.trim()))
        edit.apply()
    }

    fun clearGemini() = prefs.edit().remove("gemini_key").apply()
    fun clearOpenAi() = prefs.edit().remove("openai_key").apply()

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(keyAlias, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val body = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        return "$iv:$body"
    }

    private fun decrypt(value: String?): String? {
        if (value.isNullOrBlank()) return null
        return runCatching {
            val pieces = value.split(':', limit = 2)
            require(pieces.size == 2)
            val iv = Base64.decode(pieces[0], Base64.NO_WRAP)
            val body = Base64.decode(pieces[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            cipher.doFinal(body).toString(Charsets.UTF_8)
        }.getOrNull()
    }
}
