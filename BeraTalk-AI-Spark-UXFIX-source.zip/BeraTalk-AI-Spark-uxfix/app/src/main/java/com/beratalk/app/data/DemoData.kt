package com.beratalk.app.data

import com.beratalk.app.model.BankType
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.Mission

object DemoData {
    val mission = Mission(
        id = "day-1",
        title = "Talking about your day",
        subtitle = "Listen, answer, and keep the conversation moving.",
        minutes = 12,
        progress = .35f,
        steps = listOf(
            "Listen to 3 partner recordings",
            "Practice 5 useful expressions",
            "Send 4 voice replies",
            "Complete a 3-minute conversation"
        )
    )

    val entries = listOf(
        LanguageEntry(type = BankType.WORD, language = "Igala", nativeText = "Add your first Igala word", meaning = "Start your shared word bank", verified = false),
        LanguageEntry(type = BankType.SENTENCE, language = "Esan", nativeText = "Add a sentence you actually use", meaning = "Natural speech beats textbook speech", verified = false),
        LanguageEntry(type = BankType.CONVERSATION, language = "Igala", nativeText = "Greeting an elder", meaning = "Record both sides together", verified = false),
        LanguageEntry(type = BankType.STORY, language = "Esan", nativeText = "A family story", meaning = "Preserve real voices and memories", verified = false)
    )
}
