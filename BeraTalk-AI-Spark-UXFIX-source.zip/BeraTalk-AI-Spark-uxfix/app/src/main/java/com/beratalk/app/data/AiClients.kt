package com.beratalk.app.data

import android.content.Context
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.Mission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val SYSTEM_RULES = """
You are BeraTalk's language-learning coach. You organize practice between two real people.
CRITICAL RULE: Never invent, translate, normalize, or correct minority-language words yourself.
Any target-language wording you reference must come only from the VERIFIED BANK supplied in the request.
If the verified bank is insufficient, tell the learner to ask their partner to teach or record the missing language.
Focus on listening, speaking, recall, partner correction, everyday communication, and gradual difficulty.
Return only valid JSON with keys: title, subtitle, minutes, steps. steps must be an array of 4 short strings.
"""

class AiClientRouter(context: Context) {
    private val settings = SecureAiSettings(context)

    suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission? {
        val cfg = settings.snapshot()
        val prompt = missionPrompt(learningLanguage, verifiedEntries, recentWeaknesses)
        val order = when (cfg.preferredProvider) {
            AiProvider.GEMINI -> listOf(AiProvider.GEMINI)
            AiProvider.OPENAI -> listOf(AiProvider.OPENAI)
            AiProvider.AUTO -> listOf(AiProvider.GEMINI, AiProvider.OPENAI)
        }
        for (provider in order) {
            val response = runCatching {
                when (provider) {
                    AiProvider.GEMINI -> if (cfg.geminiApiKey.isNotBlank()) gemini(cfg.geminiApiKey, cfg.geminiModel, prompt) else null
                    AiProvider.OPENAI -> if (cfg.openAiApiKey.isNotBlank()) openAi(cfg.openAiApiKey, cfg.openAiModel, prompt) else null
                    AiProvider.AUTO -> null
                }
            }.getOrNull()
            response?.let { parseMission(it)?.let { mission -> return mission } }
        }
        return null
    }

    suspend fun test(provider: AiProvider): Result<String> {
        val cfg = settings.snapshot()
        return runCatching {
            val result = when (provider) {
                AiProvider.GEMINI -> {
                    require(cfg.geminiApiKey.isNotBlank()) { "Add your Gemini API key first." }
                    gemini(cfg.geminiApiKey, cfg.geminiModel, "Connection test", "Reply exactly with: BeraTalk connected")
                }
                AiProvider.OPENAI -> {
                    require(cfg.openAiApiKey.isNotBlank()) { "Add your OpenAI API key first." }
                    openAi(cfg.openAiApiKey, cfg.openAiModel, "Connection test", "Reply exactly with: BeraTalk connected")
                }
                AiProvider.AUTO -> error("Choose Gemini or OpenAI to test a connection.")
            }
            require(!result.isNullOrBlank()) { "The provider returned an empty response." }
            result.trim().take(180)
        }
    }

    private fun missionPrompt(language: String, entries: List<LanguageEntry>, weaknesses: List<String>): String {
        val bank = JSONArray()
        entries.filter { it.verified && it.language.equals(language, ignoreCase = true) }
            .take(24)
            .forEach { entry ->
                bank.put(JSONObject().apply {
                    put("type", entry.type.label)
                    put("native", entry.nativeText)
                    put("meaning", entry.meaning)
                    put("dialect", entry.dialect)
                    put("notes", entry.notes)
                })
            }
        return buildString {
            append("Create one 8-15 minute speaking mission for a beginner learning ")
            append(language)
            append(" from their real partner. VERIFIED BANK: ")
            append(bank.toString())
            append(". RECENT WEAKNESSES: ")
            append(JSONArray(weaknesses).toString())
            append(". If VERIFIED BANK is empty or too small, make the mission about asking the partner to teach/record needed phrases rather than supplying translations yourself.")
        }
    }

    private suspend fun gemini(apiKey: String, model: String, prompt: String, system: String = SYSTEM_RULES): String? = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/${urlSegment(model)}:generateContent"
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system.trimIndent()))))
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.35)
                put("maxOutputTokens", 700)
                put("responseMimeType", if (system == SYSTEM_RULES) "application/json" else "text/plain")
            })
        }
        val json = postJson(endpoint, body, mapOf("x-goog-api-key" to apiKey))
        val candidates = json.optJSONArray("candidates") ?: return@withContext null
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return@withContext null
        buildString {
            for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
        }.takeIf { it.isNotBlank() }
    }

    private suspend fun openAi(apiKey: String, model: String, prompt: String, system: String = SYSTEM_RULES): String? = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", model)
            put("instructions", system.trimIndent())
            put("input", prompt)
            put("max_output_tokens", 700)
        }
        val json = postJson(
            "https://api.openai.com/v1/responses",
            body,
            mapOf("Authorization" to "Bearer $apiKey")
        )
        json.optString("output_text").takeIf { it.isNotBlank() } ?: extractOpenAiText(json)
    }

    private fun extractOpenAiText(json: JSONObject): String? {
        val output = json.optJSONArray("output") ?: return null
        val text = StringBuilder()
        for (i in 0 until output.length()) {
            val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val item = content.optJSONObject(j) ?: continue
                val value = item.optString("text")
                if (value.isNotBlank()) text.append(value)
            }
        }
        return text.toString().takeIf { it.isNotBlank() }
    }

    private fun parseMission(raw: String): Mission? = runCatching {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        require(start >= 0 && end > start)
        val obj = JSONObject(raw.substring(start, end + 1))
        val stepsJson = obj.getJSONArray("steps")
        val steps = buildList {
            for (i in 0 until minOf(stepsJson.length(), 6)) {
                stepsJson.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
        require(steps.size >= 3)
        Mission(
            id = "ai-${System.currentTimeMillis()}",
            title = obj.optString("title").ifBlank { "Today's conversation" },
            subtitle = obj.optString("subtitle").ifBlank { "Practice with your partner's verified language." },
            minutes = obj.optInt("minutes", 12).coerceIn(5, 25),
            progress = 0f,
            steps = steps
        )
    }.getOrNull()

    private fun postJson(endpoint: String, body: JSONObject, headers: Map<String, String>): JSONObject {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 35_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            headers.forEach { (key, value) -> setRequestProperty(key, value) }
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                error(message?.takeIf { it.isNotBlank() } ?: "HTTP $code from AI provider")
            }
            return JSONObject(response)
        } finally {
            connection.disconnect()
        }
    }

    private fun urlSegment(model: String): String = java.net.URLEncoder.encode(model.trim(), "UTF-8")
}
