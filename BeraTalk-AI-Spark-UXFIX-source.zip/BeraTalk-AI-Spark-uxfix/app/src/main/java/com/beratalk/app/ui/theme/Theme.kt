package com.beratalk.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Bright brand colours are reserved for fills, progress, and emphasis.
// Deeper variants are used for text/icons on light surfaces to preserve contrast.
val BeraTeal = Color(0xFF05D6B4)
val BeraTealDeep = Color(0xFF00695C)
val BeraOrange = Color(0xFFFF8A00)
val BeraOrangeDeep = Color(0xFFA84600)
val BeraCoral = Color(0xFFFF5547)
val BeraCoralDeep = Color(0xFFA92E25)

val Ink = Color(0xFF111315)
val InkSoft = Color(0xFF262A2E)
val Muted = Color(0xFF626970)
val Canvas = Color(0xFFF8F9FB)
val Soft = Color(0xFFF0F2F4)
val Border = Color(0xFFE3E6E9)
val TealTint = Color(0xFFE5FBF6)
val OrangeTint = Color(0xFFFFF1DF)
val CoralTint = Color(0xFFFFECE9)
val White = Color.White

private val scheme = lightColorScheme(
    primary = BeraTealDeep,
    secondary = BeraOrangeDeep,
    tertiary = BeraCoralDeep,
    background = Canvas,
    surface = White,
    surfaceVariant = Soft,
    onPrimary = White,
    onSecondary = White,
    onTertiary = White,
    onBackground = Ink,
    onSurface = Ink,
    onSurfaceVariant = InkSoft,
    outline = Border
)

private val family = FontFamily.SansSerif
private val typography = androidx.compose.material3.Typography(
    displaySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Black, fontSize = 34.sp, lineHeight = 39.sp, letterSpacing = (-1.0).sp),
    headlineLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.55).sp),
    headlineMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 19.sp, letterSpacing = .08.sp),
    labelMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = .18.sp)
)

@Composable
fun BeraTalkTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
