package com.beratalk.app.data

import android.content.Context
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.Mission

/**
 * BeraTalk's teaching boundary.
 *
 * AI may organize, sequence and explain lessons, but it must not invent minority-language
 * translations. Native-language phrases must come from verified language-bank entries.
 */
interface LessonEngine {
    suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String> = emptyList()
    ): Mission
}

class HybridAiLessonEngine(context: Context) : LessonEngine {
    private val router = AiClientRouter(context)
    private val fallback = SafeLocalLessonEngine()

    override suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission {
        return router.buildMission(learningLanguage, verifiedEntries, recentWeaknesses)
            ?: fallback.buildMission(learningLanguage, verifiedEntries, recentWeaknesses)
    }
}

class SafeLocalLessonEngine : LessonEngine {
    override suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission {
        val usable = verifiedEntries.filter { it.verified && it.language.equals(learningLanguage, true) }
        val focus = usable.take(5)
        val focusLabel = when {
            recentWeaknesses.isNotEmpty() -> "Review what was difficult last time"
            focus.isNotEmpty() -> "Use ${focus.size} phrases from your verified bank"
            else -> "Ask your partner to teach 3 natural phrases"
        }
        return Mission(
            id = "local-${System.currentTimeMillis()}",
            title = "A real conversation in $learningLanguage",
            subtitle = "BeraTalk guides the practice; your partner supplies the real language.",
            minutes = 12,
            progress = 0f,
            steps = listOf(
                focusLabel,
                "Listen before looking for help",
                "Send 4 original voice replies",
                "Finish with a 3-minute no-English conversation"
            )
        )
    }
}
