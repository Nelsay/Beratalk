package com.beratalk.app

import android.app.Application
import com.google.firebase.FirebaseApp

class BeraTalkApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching { FirebaseApp.initializeApp(this) }
    }
}
