package com.beratalk.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.beratalk.app.audio.VoicePlayer
import com.beratalk.app.audio.VoiceRecorder
import com.beratalk.app.data.DemoData
import com.beratalk.app.data.FirebaseGateway
import com.beratalk.app.data.AiClientRouter
import com.beratalk.app.data.AiProvider
import com.beratalk.app.data.HybridAiLessonEngine
import com.beratalk.app.data.SecureAiSettings
import com.beratalk.app.export.LanguagePackExporter
import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.BankType
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.Mission
import com.beratalk.app.model.VoiceMessage
import com.beratalk.app.ui.theme.BeraCoral
import com.beratalk.app.ui.theme.BeraCoralDeep
import com.beratalk.app.ui.theme.BeraOrange
import com.beratalk.app.ui.theme.BeraOrangeDeep
import com.beratalk.app.ui.theme.BeraTalkTheme
import com.beratalk.app.ui.theme.BeraTeal
import com.beratalk.app.ui.theme.BeraTealDeep
import com.beratalk.app.ui.theme.Canvas
import com.beratalk.app.ui.theme.Border
import com.beratalk.app.ui.theme.CoralTint
import com.beratalk.app.ui.theme.OrangeTint
import com.beratalk.app.ui.theme.TealTint
import com.beratalk.app.ui.theme.Ink
import com.beratalk.app.ui.theme.Muted
import com.beratalk.app.ui.theme.Soft
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BeraTalkTheme { BeraTalkRoot() } }
    }
}

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    LEARN("Learn", Icons.Default.AutoAwesome),
    CHAT("Chat", Icons.Default.ChatBubble),
    LIBRARY("Library", Icons.Default.LibraryBooks),
    US("Us", Icons.Default.People)
}

@Composable
fun BeraTalkRoot() {
    val context = LocalContext.current
    val gateway = remember { FirebaseGateway(context) }
    var signedIn by remember { mutableStateOf(gateway.currentUid != null) }
    var previewMode by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf<AppProfile?>(null) }
    var checkingProfile by remember { mutableStateOf(false) }

    LaunchedEffect(signedIn, previewMode) {
        if (signedIn && gateway.configured) {
            checkingProfile = true
            profile = runCatching { gateway.loadProfile() }.getOrNull()?.takeIf { !it.pairId.isNullOrBlank() }
            checkingProfile = false
        } else if (previewMode && profile == null) {
            profile = null
        }
    }

    AnimatedContent(targetState = signedIn || previewMode, label = "auth") { active ->
        if (!active) {
            AuthScreen(
                gateway = gateway,
                onSignedIn = { signedIn = true },
                onPreview = { previewMode = true }
            )
        } else if (checkingProfile) {
            LoadingScreen()
        } else if (profile == null) {
            SetupScreen(gateway = gateway, previewMode = previewMode) { completed ->
                profile = completed
            }
        } else {
            MainShell(profile = profile!!, gateway = gateway, onSignOut = {
                gateway.signOut()
                previewMode = false
                signedIn = false
                profile = null
            })
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Color.White), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.beratalk_horizontal), "BeraTalk", Modifier.width(220.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(18.dp))
            Text("Loading your language pair…", color = Muted)
        }
    }
}

@Composable
private fun SetupScreen(gateway: FirebaseGateway, previewMode: Boolean, onComplete: (AppProfile) -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf(0) }
    var speaks by remember { mutableStateOf("Esan") }
    var learning by remember { mutableStateOf("Igala") }
    var dialect by remember { mutableStateOf("") }
    var dailyMinutes by remember { mutableStateOf(10) }
    var joinMode by remember { mutableStateOf(false) }
    var inviteCode by remember { mutableStateOf("") }
    var createdCode by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val totalSteps = 4

    Surface(color = Canvas, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (step > 0 && createdCode == null) {
                        IconButton(onClick = { step--; error = null }) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Image(
                        painter = painterResource(R.drawable.beratalk_horizontal),
                        contentDescription = "BeraTalk",
                        modifier = Modifier.width(156.dp).height(48.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.size(48.dp))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    repeat(totalSteps) { index ->
                        val active = index <= step
                        Box(
                            Modifier.weight(1f).height(5.dp).clip(CircleShape)
                                .background(if (active) BeraTealDeep else Border)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("STEP ${step + 1} OF $totalSteps", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
            }
            item {
                AnimatedContent(targetState = step, label = "setupStep") { current ->
                    SetupStepCard {
                        when (current) {
                            0 -> {
                                Text("What do you naturally speak?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Start with the language you can genuinely teach from everyday life.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(24.dp))
                                LanguageChoice(selected = speaks, onSelected = { chosen ->
                                    speaks = chosen
                                    if (learning == chosen) learning = if (chosen == "Esan") "Igala" else "Esan"
                                })
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 1 }
                            }
                            1 -> {
                                Text("What do you want to learn?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Your partner will be the real language source. BeraTalk will organize the practice.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(24.dp))
                                LanguageChoice(selected = learning, onSelected = { chosen ->
                                    learning = chosen
                                    if (speaks == chosen) speaks = if (chosen == "Esan") "Igala" else "Esan"
                                })
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 2 }
                            }
                            2 -> {
                                Text("Make the learning fit your life", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Keep this lightweight. You can change the details later.", color = Muted, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(22.dp))
                                OutlinedTextField(
                                    value = dialect,
                                    onValueChange = { dialect = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Dialect / local variant (optional)") },
                                    supportingText = { Text("Example: the Esan or Igala variety you actually speak at home.") },
                                    shape = RoundedCornerShape(18.dp)
                                )
                                Spacer(Modifier.height(20.dp))
                                Text("Daily practice", style = MaterialTheme.typography.titleMedium, color = Ink)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(5, 10, 20, 30).forEach { minutes ->
                                        val active = dailyMinutes == minutes
                                        Surface(
                                            modifier = Modifier.weight(1f).clickable { dailyMinutes = minutes },
                                            color = if (active) BeraOrange else Soft,
                                            shape = RoundedCornerShape(15.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (active) BeraOrangeDeep.copy(alpha = .24f) else Border)
                                        ) {
                                            Text("$minutes min", Modifier.padding(vertical = 12.dp), color = Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 3 }
                            }
                            else -> {
                                Text(if (createdCode == null) "Connect with your partner" else "Your pair is ready", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (createdCode == null) "Create the pair on one phone, then use the six-character code on the other." else "Send this code to your partner. You can enter BeraTalk now and they can join from their phone.",
                                    color = Muted,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Spacer(Modifier.height(22.dp))
                                if (createdCode == null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        PairModeChip("Create pair", !joinMode) { joinMode = false; error = null }
                                        PairModeChip("Join partner", joinMode) { joinMode = true; error = null }
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    if (joinMode) {
                                        OutlinedTextField(
                                            value = inviteCode,
                                            onValueChange = { inviteCode = it.uppercase().filter { it.isLetterOrDigit() }.take(6) },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("Partner code") },
                                            supportingText = { Text("Enter the six-character code from your partner's phone.") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(18.dp)
                                        )
                                    } else {
                                        Surface(color = TealTint, shape = RoundedCornerShape(18.dp)) {
                                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.People, null, tint = BeraTealDeep)
                                                Spacer(Modifier.width(11.dp))
                                                Text("You'll get a private code after creating the pair.", color = Ink, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                } else {
                                    Surface(color = Ink, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("YOUR PRIVATE PAIR CODE", color = Color.White.copy(.72f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.height(8.dp))
                                            Text(createdCode.orEmpty(), style = MaterialTheme.typography.displaySmall, color = Color.White, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                                error?.let {
                                    Spacer(Modifier.height(14.dp))
                                    Surface(color = CoralTint, shape = RoundedCornerShape(16.dp)) { Text(it, Modifier.fillMaxWidth().padding(13.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium) }
                                }
                                Spacer(Modifier.height(22.dp))
                                val label = when {
                                    busy -> "Setting things up…"
                                    createdCode != null -> "Enter BeraTalk"
                                    joinMode -> "Join language pair"
                                    else -> "Create language pair"
                                }
                                PrimaryButton(label, enabled = !busy && (createdCode != null || !joinMode || inviteCode.length == 6)) {
                                    val base = AppProfile(
                                        displayName = gateway.currentDisplayName,
                                        speaks = speaks,
                                        learning = learning,
                                        dialect = dialect.trim(),
                                        dailyMinutes = dailyMinutes
                                    )
                                    if (createdCode != null) {
                                        scope.launch {
                                            val stored = if (gateway.configured && !previewMode) gateway.loadProfile() else base.copy(pairId = "preview-pair")
                                            onComplete(stored ?: base.copy(pairId = "preview-pair"))
                                        }
                                        return@PrimaryButton
                                    }
                                    scope.launch {
                                        busy = true
                                        error = null
                                        if (previewMode || !gateway.configured) {
                                            if (joinMode) onComplete(base.copy(pairId = "preview-pair")) else createdCode = "BERA01"
                                        } else {
                                            runCatching {
                                                gateway.saveProfile(base)
                                                if (joinMode) {
                                                    val pairId = gateway.joinPair(inviteCode)
                                                    val final = base.copy(pairId = pairId)
                                                    gateway.saveProfile(final)
                                                    onComplete(final)
                                                } else {
                                                    val created = gateway.createPair(base)
                                                    gateway.saveProfile(base.copy(pairId = created.pairId))
                                                    createdCode = created.inviteCode
                                                }
                                            }.onFailure { error = it.message ?: "Could not connect the pair." }
                                        }
                                        busy = false
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupStepCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) { content() }
    }
}

@Composable
private fun LanguageChoice(selected: String, onSelected: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Esan", "Igala").forEach { language ->
            val active = selected == language
            Surface(
                modifier = Modifier.weight(1f).clickable { onSelected(language) },
                color = if (active) Ink else Soft, shape = RoundedCornerShape(16.dp)
            ) {
                Text(language, Modifier.padding(vertical = 14.dp), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PairModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) BeraTeal else Color.White, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = Ink, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AuthScreen(gateway: FirebaseGateway, onSignedIn: () -> Unit, onPreview: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var signUp by remember { mutableStateOf(false) }

    val infinite = rememberInfiniteTransition(label = "logoFloat")
    val logoScale by infinite.animateFloat(
        initialValue = .99f, targetValue = 1.015f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale"
    )

    Surface(color = Color.White, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(8.dp))
                    Image(
                        painter = painterResource(R.drawable.beratalk_horizontal),
                        contentDescription = "BeraTalk",
                        modifier = Modifier.width(190.dp).height(64.dp).scale(logoScale),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.height(26.dp))
                    Text(
                        "Learn their language from them.",
                        style = MaterialTheme.typography.displaySmall,
                        color = Ink,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Real voices, real corrections, and AI-guided conversations built around the person you care about.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Muted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
            item {
                OutlinedTextField(
                    value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email") }, leadingIcon = { Icon(Icons.Outlined.Mail, null, tint = Ink) },
                    singleLine = true, shape = RoundedCornerShape(18.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }
            item {
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null, tint = Ink) },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true, shape = RoundedCornerShape(18.dp)
                )
            }
            item {
                PrimaryButton(
                    text = if (busy) "Please wait…" else if (signUp) "Create account" else "Continue",
                    enabled = !busy && email.isNotBlank() && password.length >= 6
                ) {
                    scope.launch {
                        busy = true; error = null
                        runCatching {
                            if (signUp) gateway.createEmailAccount(email, password) else gateway.signInEmail(email, password)
                        }.onSuccess { onSignedIn() }.onFailure { error = it.message }
                        busy = false
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                    Text("  or  ", color = Muted, style = MaterialTheme.typography.labelMedium)
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                }
            }
            item {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            error = null
                            if (!gateway.configured) {
                                error = "Add your Firebase google-services.json first to enable Google sign-in."
                                return@launch
                            }
                            runCatching { googleSignIn(context, gateway) }
                                .onSuccess { onSignedIn() }
                                .onFailure { error = it.message ?: "Google sign-in failed" }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border)
                ) {
                    Text("G", fontWeight = FontWeight.Black, color = Color(0xFF1A73E8))
                    Spacer(Modifier.width(12.dp))
                    Text("Continue with Google", color = Ink, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (signUp) "Already have an account?" else "New to BeraTalk?", color = Muted)
                    TextButton(onClick = { signUp = !signUp }) { Text(if (signUp) "Sign in" else "Create account", color = BeraTealDeep, fontWeight = FontWeight.Bold) }
                }
            }
            error?.let { message ->
                item {
                    Surface(color = CoralTint, shape = RoundedCornerShape(18.dp)) {
                        Text(message, modifier = Modifier.fillMaxWidth().padding(15.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (!gateway.configured) {
                item {
                    Surface(color = TealTint, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BeraTealDeep.copy(alpha = .12f))) {
                        Column(Modifier.padding(17.dp)) {
                            Text("Firebase-ready build", style = MaterialTheme.typography.titleMedium, color = Ink)
                            Spacer(Modifier.height(5.dp))
                            Text("Authentication activates after app/google-services.json is added.", color = Muted)
                            Spacer(Modifier.height(8.dp))
                            TextButton(onClick = onPreview, contentPadding = PaddingValues(0.dp)) { Text("Preview app →", color = BeraTealDeep, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun googleSignIn(context: Context, gateway: FirebaseGateway) {
    val clientIdRes = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    require(clientIdRes != 0) { "Google web client ID not found. Re-download google-services.json after enabling Google sign-in in Firebase." }
    val webClientId = context.getString(clientIdRes)
    val googleOption = GetGoogleIdOption.Builder()
        .setServerClientId(webClientId)
        .setFilterByAuthorizedAccounts(false)
        .setAutoSelectEnabled(false)
        .build()
    val request = GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
    val result = CredentialManager.create(context).getCredential(context, request)
    val credential = GoogleIdTokenCredential.createFrom(result.credential.data)
    gateway.signInGoogle(credential.idToken)
}

@Composable
private fun MainShell(profile: AppProfile, gateway: FirebaseGateway, onSignOut: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var showSettings by remember { mutableStateOf(false) }
    var aiSettingsRevision by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val entries = remember { mutableStateListOf<LanguageEntry>().apply { addAll(DemoData.entries) } }
    val messages = remember { mutableStateListOf<VoiceMessage>() }
    val lessonEngine = remember { HybridAiLessonEngine(context) }
    var mission by remember { mutableStateOf(DemoData.mission) }

    LaunchedEffect(profile.learning, entries.size, aiSettingsRevision) {
        mission = lessonEngine.buildMission(profile.learning, entries.toList())
    }

    DisposableEffect(profile.pairId, gateway.configured) {
        val pairId = profile.pairId?.takeIf { gateway.configured && it != "preview-pair" }
        val messageRegistration = pairId?.let { id ->
            gateway.observeMessages(id) { incoming -> messages.clear(); messages.addAll(incoming) }
        }
        val entryRegistration = pairId?.let { id ->
            gateway.observeEntries(id) { incoming ->
                entries.clear(); entries.addAll(incoming)
            }
        }
        onDispose { messageRegistration?.remove(); entryRegistration?.remove() }
    }

    if (showSettings) {
        AiSettingsScreen(
            onBack = { showSettings = false },
            onSettingsChanged = { aiSettingsRevision++ }
        )
        return
    }

    Scaffold(
        containerColor = Canvas,
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 10.dp, modifier = Modifier.navigationBarsPadding()) {
                Tab.entries.forEach { item ->
                    val selected = tab == item
                    NavigationBarItem(
                        selected = selected, onClick = { tab = item },
                        icon = { Icon(item.icon, null) }, label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Ink, selectedTextColor = Ink, indicatorColor = TealTint, unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { insets ->
        Crossfade(targetState = tab, modifier = Modifier.padding(insets), label = "tabs") { current ->
            when (current) {
                Tab.HOME -> HomeScreen(profile, mission, onStartMission = { tab = Tab.LEARN }, onChat = { tab = Tab.CHAT })
                Tab.LEARN -> LearnScreen(mission, onChat = { tab = Tab.CHAT })
                Tab.CHAT -> ChatScreen(
                    profile = profile,
                    messages = messages,
                    resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                    onRecorded = { file, duration, correctionFor ->
                        val pairId = profile.pairId
                        if (gateway.configured && pairId != null && pairId != "preview-pair") {
                            val local = VoiceMessage(localAudioPath = file.absolutePath, durationMs = duration, correctionFor = correctionFor)
                            messages.add(local)
                            scope.launch { runCatching { gateway.sendVoiceMessage(pairId, file, duration, correctionFor) } }
                        } else {
                            messages.add(VoiceMessage(localAudioPath = file.absolutePath, durationMs = duration, correctionFor = correctionFor))
                        }
                    }
                )
                Tab.LIBRARY -> LibraryScreen(
                    entries = entries,
                    profile = profile,
                    resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                    onAddEntry = { entry ->
                        entries.add(0, entry)
                        val pairId = profile.pairId
                        if (gateway.configured && pairId != null && pairId != "preview-pair") {
                            scope.launch { runCatching { gateway.addEntry(pairId, entry) } }
                        }
                    }
                )
                Tab.US -> UsScreen(profile, onSignOut = onSignOut, onSettings = { showSettings = true })
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineLarge, color = Ink)
            subtitle?.let { Spacer(Modifier.height(5.dp)); Text(it, style = MaterialTheme.typography.bodyMedium, color = Muted) }
        }
        action?.invoke()
    }
}

@Composable
private fun HomeScreen(profile: AppProfile, mission: Mission, onStartMission: () -> Unit, onChat: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            ScreenHeader("${currentGreeting()}, ${profile.displayName.ifBlank { "there" }}", "You’re building ${profile.learning} one real conversation at a time.") {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                    Text(profile.displayName.firstOrNull()?.uppercase() ?: "N", color = Color.White, fontWeight = FontWeight.Black)
                }
            }
        }
        item {
            GradientMissionCard(mission, onStartMission)
        }
        item {
            Text("Together", style = MaterialTheme.typography.titleLarge, color = Ink)
            Spacer(Modifier.height(10.dp))
            SharedStatsStrip()
        }
        item {
            NextUpPanel(profile.learning, onChat)
        }
    }
}

@Composable
private fun GradientMissionCard(mission: Mission, onClick: () -> Unit) {
    val press = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .985f else 1f, label = "missionPress")
    Card(
        modifier = Modifier.fillMaxWidth().scale(scale).clickable(interactionSource = press, indication = null, onClick = onClick),
        shape = RoundedCornerShape(28.dp), elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(
            Modifier.background(Brush.linearGradient(listOf(Color(0xFF0E1516), Color(0xFF102F2A)))).padding(22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = BeraTeal, shape = RoundedCornerShape(999.dp)) { Text("TODAY'S CONVERSATION", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black) }
                Spacer(Modifier.weight(1f))
                Text("12 min", color = Color.White.copy(.74f), style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(24.dp))
            Text(mission.title, style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text(mission.subtitle, color = Color.White.copy(.72f), style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(24.dp))
            LinearProgressIndicator(
                progress = { mission.progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = BeraOrange, trackColor = Color.White.copy(.15f)
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Continue mission", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null, tint = BeraOrange, modifier = Modifier.size(19.dp))
            }
        }
    }
}

@Composable
private fun SharedStatsStrip() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shape = RoundedCornerShape(22.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 1.dp
    ) {
        Row(Modifier.padding(vertical = 17.dp)) {
            SharedStat("6", "day streak", BeraOrange)
            Box(Modifier.width(1.dp).height(44.dp).background(Border))
            SharedStat("74", "phrases taught", BeraTeal)
            Box(Modifier.width(1.dp).height(44.dp).background(Border))
            SharedStat("18", "conversations", BeraCoral)
        }
    }
}

@Composable
private fun RowScope.SharedStat(value: String, label: String, accent: Color) {
    Column(Modifier.weight(1f).padding(horizontal = 12.dp), horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(7.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = Muted, maxLines = 2)
    }
}

@Composable
private fun NextUpPanel(learningLanguage: String, onChat: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shape = RoundedCornerShape(22.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 1.dp
    ) {
        Column {
            Text("Next up", Modifier.padding(start = 17.dp, top = 16.dp, end = 17.dp, bottom = 8.dp), style = MaterialTheme.typography.titleMedium, color = Ink, fontWeight = FontWeight.Bold)
            NextUpRow(Icons.Default.GraphicEq, "Pronunciation correction", "Listen again and send your retry.", BeraTealDeep, onChat)
            HorizontalDivider(color = Border, modifier = Modifier.padding(horizontal = 17.dp))
            NextUpRow(Icons.Default.Timer, "60-second $learningLanguage challenge", "Speak without switching to English.", BeraOrangeDeep, onChat)
        }
    }
}

@Composable
private fun NextUpRow(icon: ImageVector, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 17.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Soft), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent) }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Muted)
        }
        Icon(Icons.Default.ArrowForward, null, tint = Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun CardButton(icon: ImageVector, title: String, subtitle: String, chip: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border)
    ) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Soft), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Ink) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
                Spacer(Modifier.height(4.dp)); Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
            Surface(color = TealTint, shape = RoundedCornerShape(999.dp)) { Text(chip, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium, color = BeraTealDeep) }
        }
    }
}

@Composable
private fun LearnScreen(mission: Mission, onChat: () -> Unit) {
    var completed by remember(mission.id) { mutableStateOf(0) }
    val stepCount = mission.steps.size.coerceAtLeast(1)
    val finished = completed >= mission.steps.size
    val progress = if (mission.steps.isEmpty()) 1f else completed.toFloat() / mission.steps.size.toFloat()

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { ScreenHeader("Learn", "Only the current task is shown. Finish it, then move forward.") }
        item {
            Surface(color = Ink, shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TODAY'S MISSION", color = BeraTeal, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
                        Spacer(Modifier.weight(1f))
                        Text("${mission.minutes} min", color = Color.White.copy(.76f), style = MaterialTheme.typography.labelLarge)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(mission.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(7.dp))
                    Text(mission.subtitle, color = Color.White.copy(.74f), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(18.dp))
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = BeraOrange,
                        trackColor = Color.White.copy(.16f)
                    )
                }
            }
        }
        item {
            if (!finished) {
                AnimatedContent(targetState = completed.coerceAtMost(stepCount - 1), label = "currentLessonStep") { index ->
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(24.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).clip(CircleShape).background(BeraOrange), contentAlignment = Alignment.Center) {
                                    Text("${index + 1}", color = Ink, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.width(11.dp))
                                Column {
                                    Text("CURRENT TASK", color = BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                                    Text("${index + 1} of ${mission.steps.size}", color = Muted, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text(mission.steps[index], style = MaterialTheme.typography.headlineMedium, color = Ink)
                            Spacer(Modifier.height(8.dp))
                            Text("Do this with your real voice or your partner's voice. BeraTalk will not replace the language with invented text.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(22.dp))
                            PrimaryButton(if (index == mission.steps.lastIndex) "Complete lesson" else "Done — next task") {
                                completed = (completed + 1).coerceAtMost(mission.steps.size)
                            }
                        }
                    }
                }
            } else {
                AnimatedVisibility(visible = true, enter = fadeIn() + scaleIn()) {
                    Surface(color = OrangeTint, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Icon(Icons.Default.CheckCircle, null, tint = BeraOrangeDeep, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Ready for the real thing?", style = MaterialTheme.typography.headlineMedium, color = Ink)
                            Spacer(Modifier.height(6.dp))
                            Text("Keep English out for three minutes. The AI guide gives you the mission; your partner gives you the real language.", color = Muted)
                            Spacer(Modifier.height(18.dp))
                            PrimaryButton("Start conversation", onClick = onChat)
                        }
                    }
                }
            }
        }
        if (!finished && completed > 0) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = BeraTealDeep, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("$completed task${if (completed == 1) "" else "s"} completed", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun ChatScreen(profile: AppProfile, messages: MutableList<VoiceMessage>, resolveAudio: suspend (String) -> String?, onRecorded: (File, Long, String?) -> Unit) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    val player = remember { VoicePlayer() }
    val playbackScope = rememberCoroutineScope()
    fun playAudio(path: String, speed: Float = 1f) {
        playbackScope.launch {
            resolveAudio(path)?.let { player.play(it, speed) }
        }
    }
    var recording by remember { mutableStateOf(false) }
    var currentDuration by remember { mutableStateOf(0L) }
    var tick by remember { mutableStateOf(0L) }
    var helpVisible by remember { mutableStateOf(false) }
    var helpNote by remember { mutableStateOf<String?>(null) }
    var correctionFor by remember { mutableStateOf<String?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true; tick = System.currentTimeMillis() }
    }
    LaunchedEffect(recording) {
        while (recording) {
            currentDuration = System.currentTimeMillis() - tick
            kotlinx.coroutines.delay(100)
        }
    }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel(); player.stop() } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.beratalk_app_icon_reference),
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.partnerName.ifBlank { "Your language partner" }, style = MaterialTheme.typography.titleMedium, color = Ink)
                Text("${profile.learning} ↔ ${profile.speaks} · Today's mission", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = { helpVisible = !helpVisible }) { Icon(Icons.Default.MoreHoriz, "Conversation help", tint = Ink) }
        }
        AnimatedVisibility(helpVisible) {
            Column(Modifier.fillMaxWidth().background(OrangeTint).padding(horizontal = 20.dp, vertical = 12.dp)) {
                val lastPartner = messages.lastOrNull { it.senderId != "me" }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Assist("Play slower") { lastPartner?.let { playAudio(it.localAudioPath, .75f) } }
                    Assist("Ask meaning") { helpNote = "Record a voice note asking which word or phrase was unclear." }
                    Assist("Repeat") { lastPartner?.let { playAudio(it.localAudioPath) } }
                }
                helpNote?.let { note -> Spacer(Modifier.height(8.dp)); Text(note, color = Ink, style = MaterialTheme.typography.bodyMedium) }
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(color = TealTint, shape = RoundedCornerShape(16.dp)) {
                    Text("AI challenge · Ask one follow-up question without English.", Modifier.padding(12.dp), color = Color(0xFF006B5D), style = MaterialTheme.typography.labelLarge)
                }
            }
            if (messages.isEmpty()) { item { PartnerVoiceBubble(onPlay = {}) } }
            items(messages) { msg ->
                VoiceBubble(
                    mine = msg.senderId == "me",
                    seconds = (msg.durationMs / 1000).coerceAtLeast(1).toInt(),
                    correction = msg.correctionFor != null,
                    onPlay = { playAudio(msg.localAudioPath) },
                    onCorrect = if (msg.senderId != "me") ({ correctionFor = msg.id }) else null
                )
            }
        }
        Column(Modifier.fillMaxWidth().background(Color.White).padding(14.dp).navigationBarsPadding()) {
            if (recording) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RecordingPulse(); Spacer(Modifier.width(10.dp)); Text(formatMs(currentDuration), fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("Recording…", color = Muted)
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {}) { Icon(Icons.Default.Add, null, tint = Ink) }
                Surface(modifier = Modifier.weight(1f), color = Soft, shape = RoundedCornerShape(22.dp)) {
                    Text(when {
                        recording && correctionFor != null -> "Recording a pronunciation correction"
                        recording -> "Release your thought as voice"
                        correctionFor != null -> "Correction ready · tap mic to record"
                        else -> "Voice-first conversation"
                    }, Modifier.padding(horizontal = 16.dp, vertical = 14.dp), color = Muted)
                }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier.size(54.dp).clip(CircleShape).background(if (recording) BeraCoral else Ink).clickable {
                        if (recording) {
                            val (file, duration) = recorder.stop(); recording = false
                            file?.let { onRecorded(it, duration, correctionFor) }; correctionFor = null
                        } else {
                            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                recorder.start(); recording = true; tick = System.currentTimeMillis()
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }, contentAlignment = Alignment.Center
                ) { Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) Ink else Color.White) }
            }
        }
    }
}

@Composable
private fun RecordingPulse() {
    val infinite = rememberInfiniteTransition(label = "recording")
    val scale by infinite.animateFloat(1f, 1.6f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.size(10.dp).scale(scale).clip(CircleShape).background(BeraCoral))
}

@Composable
private fun PartnerVoiceBubble(onPlay: () -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
        Text("Partner", color = Muted, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(5.dp))
        Card(shape = RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                PlayCircle(onPlay); Spacer(Modifier.width(10.dp)); FakeWave(Modifier.width(160.dp), BeraTealDeep); Spacer(Modifier.width(8.dp)); Text("0:07", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
        }
        Spacer(Modifier.height(5.dp)); Text("Need help? Tap ··· above", color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun VoiceBubble(mine: Boolean, seconds: Int, correction: Boolean, onPlay: () -> Unit, onCorrect: (() -> Unit)?) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        if (correction) {
            Text("Pronunciation correction", color = BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
        }
        Card(
            shape = if (mine) RoundedCornerShape(22.dp, 6.dp, 22.dp, 22.dp) else RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp),
            colors = CardDefaults.cardColors(containerColor = if (mine) Ink else Color.White), elevation = CardDefaults.cardElevation(1.dp)
        ) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                PlayCircle(onPlay, dark = mine)
                Spacer(Modifier.width(10.dp))
                FakeWave(Modifier.width(150.dp), if (mine) BeraOrange else BeraTealDeep)
                Spacer(Modifier.width(8.dp))
                Text("0:${seconds.toString().padStart(2, '0')}", color = if (mine) Color.White.copy(.72f) else Muted, style = MaterialTheme.typography.labelMedium)
            }
        }
        if (onCorrect != null) {
            TextButton(onClick = onCorrect, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                Text("Correct pronunciation", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PlayCircle(onClick: () -> Unit, dark: Boolean = false) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(if (dark) Color.White.copy(.14f) else Soft).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.PlayArrow, null, tint = if (dark) Color.White else Ink)
    }
}

@Composable
private fun FakeWave(modifier: Modifier, color: Color) {
    Row(modifier.height(32.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        val bars = listOf(8, 17, 25, 13, 29, 19, 9, 23, 14, 7, 18, 11)
        bars.forEach { h -> Box(Modifier.width(3.dp).height(h.dp).clip(CircleShape).background(color.copy(.88f))) }
    }
}

@Composable private fun Assist(text: String, onClick: () -> Unit) { Surface(color = Color.White, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.clickable(onClick = onClick)) { Text(text, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Ink, style = MaterialTheme.typography.labelMedium) } }
private fun formatMs(ms: Long): String = "%02d:%02d".format((ms / 60000), (ms / 1000) % 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryScreen(entries: MutableList<LanguageEntry>, profile: AppProfile, resolveAudio: suspend (String) -> String?, onAddEntry: (LanguageEntry) -> Unit) {
    val context = LocalContext.current
    val exporter = remember { LanguagePackExporter(context) }
    val exportScope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(BankType.WORD) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var exportLanguage by remember { mutableStateOf(profile.speaks) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            exportScope.launch {
                runCatching {
                    val hydratedEntries = entries.map { entry ->
                        val resolved = entry.audioPath?.let { resolveAudio(it) }
                        if (resolved != null) entry.copy(audioPath = resolved) else entry.copy(audioPath = null)
                    }
                    val file = exporter.export(exportLanguage, hydratedEntries)
                    context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                }
            }
        }
    }
    val filtered = entries.filter { it.type == selected && (search.isBlank() || it.nativeText.contains(search, true) || it.meaning.contains(search, true)) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        LazyColumn(
            modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ScreenHeader("Your language library", "Everything you teach each other becomes reusable learning material.") {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Ink).clickable { showAdd = true }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, null, tint = Color.White) }
                }
            }
            item {
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search words, meanings, stories…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp)
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(BankType.entries) { type ->
                        val active = selected == type
                        Surface(
                            color = if (active) Ink else Color.White, shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { selected = type }
                        ) {
                            Text(type.label, Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (filtered.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Book, null, tint = BeraTealDeep, modifier = Modifier.size(40.dp)); Spacer(Modifier.height(12.dp)); Text("Nothing here yet", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(6.dp)); Text("Add something you naturally say. Your bank grows while you live your life.", color = Muted)
                        }
                    }
                }
            }
            items(filtered, key = { it.id }) { entry -> EntryCard(entry, resolveAudio) }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Own your language data", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(5.dp)); Text("Export a portable ZIP with the language entries and any locally saved recordings.", color = Muted)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(profile.speaks, profile.learning).distinct().forEach { language ->
                                OutlinedButton(onClick = { exportLanguage = language; exportLauncher.launch("${language.lowercase()}-language-pack.zip") }, shape = RoundedCornerShape(14.dp)) {
                                    Text("Export $language", color = Ink, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddEntrySheet(initialType = selected, onDismiss = { showAdd = false }, onSave = { onAddEntry(it); showAdd = false })
    }
}

@Composable
private fun EntryCard(entry: LanguageEntry, resolveAudio: suspend (String) -> String?) {
    val player = remember { VoicePlayer() }
    val playbackScope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { player.stop() } }
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(if (entry.language == "Igala") TealTint else OrangeTint), contentAlignment = Alignment.Center) {
                Icon(if (entry.type == BankType.STORY) Icons.Default.Book else Icons.Default.GraphicEq, null, tint = if (entry.language == "Igala") BeraTealDeep else BeraOrangeDeep)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(entry.nativeText, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (entry.verified) { Spacer(Modifier.width(6.dp)); Icon(Icons.Outlined.Verified, null, tint = BeraTealDeep, modifier = Modifier.size(16.dp)) }
                }
                Spacer(Modifier.height(3.dp)); Text(entry.meaning, color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(5.dp)); Text("${entry.language}${if (entry.dialect.isNotBlank()) " · ${entry.dialect}" else ""}", color = if (entry.language == "Igala") BeraTealDeep else BeraOrangeDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
            IconButton(enabled = !entry.audioPath.isNullOrBlank(), onClick = {
                entry.audioPath?.let { path -> playbackScope.launch { resolveAudio(path)?.let { player.play(it) } } }
            }) { Icon(Icons.Default.PlayArrow, null, tint = if (entry.audioPath.isNullOrBlank()) Muted.copy(.45f) else Ink) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEntrySheet(initialType: BankType, onDismiss: () -> Unit, onSave: (LanguageEntry) -> Unit) {
    var type by remember { mutableStateOf(initialType) }
    var language by remember { mutableStateOf("Esan") }
    var nativeText by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    var notes by remember { mutableStateOf("") }
    var dialect by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var audioPath by remember { mutableStateOf<String?>(null) }
    var audioDuration by remember { mutableStateOf(0L) }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true }
    }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel() } }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Color.White) {
        LazyColumn(contentPadding = PaddingValues(20.dp, 6.dp, 20.dp, 34.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            item { Text("Add to ${type.label}", style = MaterialTheme.typography.headlineMedium) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(BankType.entries) { b -> Surface(color = if (b == type) Ink else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { type = b }) { Text(b.label, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = if (b == type) Color.White else Ink, fontWeight = FontWeight.Bold) } } }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Esan", "Igala").forEach { lang -> Surface(color = if (language == lang) TealTint else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { language = lang }) { Text(lang, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = Ink, fontWeight = FontWeight.Bold) } }
                }
            }
            item { OutlinedTextField(nativeText, { nativeText = it }, Modifier.fillMaxWidth(), label = { Text(if (type == BankType.STORY) "Title / language text" else "How you actually say it") }, shape = RoundedCornerShape(18.dp), minLines = if (type == BankType.STORY) 3 else 1) }
            item { OutlinedTextField(meaning, { meaning = it }, Modifier.fillMaxWidth(), label = { Text("Meaning / natural translation") }, shape = RoundedCornerShape(18.dp), minLines = 2) }
            item {
                TextButton(onClick = { showAdvanced = !showAdvanced }, contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)) {
                    Text(if (showAdvanced) "Hide extra details" else "Add dialect or cultural context", color = BeraTealDeep, fontWeight = FontWeight.Bold)
                }
            }
            if (showAdvanced) {
                item { OutlinedTextField(dialect, { dialect = it }, Modifier.fillMaxWidth(), label = { Text("Dialect / variant (optional)") }, shape = RoundedCornerShape(18.dp)) }
                item { OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("Context or cultural note (optional)") }, shape = RoundedCornerShape(18.dp), minLines = 2) }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = if (audioPath != null) TealTint else Color(0xFFF3F5F7)), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) BeraCoralDeep else BeraTealDeep)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (recording) "Recording…" else if (audioPath != null) "Pronunciation saved" else "Record pronunciation", fontWeight = FontWeight.Bold)
                            Text(if (audioPath != null) "${(audioDuration / 1000).coerceAtLeast(1)} sec · original voice kept" else "Add the real native pronunciation. No transcription required.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                        }
                        TextButton(onClick = {
                            if (recording) {
                                val (file, duration) = recorder.stop(); recording = false; audioPath = file?.absolutePath; audioDuration = duration
                            } else {
                                if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true }
                                else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }) { Text(if (recording) "Stop" else if (audioPath != null) "Redo" else "Record") }
                    }
                }
            }
            item { PrimaryButton("Save to bank", enabled = nativeText.isNotBlank() && meaning.isNotBlank()) { onSave(LanguageEntry(type = type, language = language, nativeText = nativeText.trim(), meaning = meaning.trim(), notes = notes.trim(), dialect = dialect.trim(), audioPath = audioPath)) } }
        }
    }
}

@Composable
private fun UsScreen(profile: AppProfile, onSignOut: () -> Unit, onSettings: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 22.dp, 20.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("Us", "Your shared language journey.") { IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Ink) } } }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Ink)) {
                Column(Modifier.padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(profile.displayName.firstOrNull()?.uppercase() ?: "N", BeraTeal)
                        Spacer(Modifier.width(10.dp))
                        Icon(Icons.Default.Favorite, null, tint = BeraCoral, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Avatar(profile.partnerName.firstOrNull()?.uppercase() ?: "P", BeraOrange)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Learning together", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("${profile.speaks} ↔ ${profile.learning}", color = Color.White.copy(.72f))
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DarkStat("47", "days")
                        DarkStat("392", "voice notes")
                        DarkStat("06:41", "longest talk")
                    }
                }
            }
        }
        item { SharedProgressCard(profile) }
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Border)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(TealTint), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.CheckCircle, null, tint = BeraTealDeep)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text("First complete conversation", style = MaterialTheme.typography.titleMedium, color = Ink)
                        Text("A milestone worth remembering.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text("MEMORY", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                }
            }
        }
        item {
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                Text("Sign out", color = Ink, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SharedProgressCard(profile: AppProfile) {
    var partnerView by remember { mutableStateOf(false) }
    val values = if (partnerView) {
        listOf("Listening" to .55f, "Speaking" to .51f, "Vocabulary" to .64f, "Conversation" to .39f)
    } else {
        listOf("Listening" to .62f, "Speaking" to .48f, "Vocabulary" to .71f, "Conversation" to .43f)
    }
    val accent = if (partnerView) BeraOrange else BeraTeal

    Surface(
        color = Color.White,
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Progress", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AiProviderButton("You", !partnerView, onClick = { partnerView = false })
                    AiProviderButton("Partner", partnerView, onClick = { partnerView = true })
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(if (partnerView) "Partner's ${profile.speaks}" else "Your ${profile.learning}", color = Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(18.dp))
            values.forEachIndexed { index, (label, value) ->
                Row { Text(label, Modifier.weight(1f), color = Ink); Text("${(value * 100).toInt()}%", color = Muted, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(7.dp))
                LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = accent, trackColor = Soft)
                if (index != values.lastIndex) Spacer(Modifier.height(15.dp))
            }
        }
    }
}

@Composable
private fun AiSettingsScreen(onBack: () -> Unit, onSettingsChanged: () -> Unit) {
    val context = LocalContext.current
    val secureSettings = remember { SecureAiSettings(context) }
    val router = remember { AiClientRouter(context) }
    val initial = remember { secureSettings.snapshot() }
    val scope = rememberCoroutineScope()

    var preferred by remember { mutableStateOf(initial.preferredProvider) }
    var geminiKey by remember { mutableStateOf(initial.geminiApiKey) }
    var openAiKey by remember { mutableStateOf(initial.openAiApiKey) }
    var geminiModel by remember { mutableStateOf(initial.geminiModel) }
    var openAiModel by remember { mutableStateOf(initial.openAiModel) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showOpenAiKey by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf<AiProvider?>(null) }

    fun persistProvider(provider: AiProvider) {
        preferred = provider
        secureSettings.setPreferredProvider(provider)
        onSettingsChanged()
        status = when (provider) {
            AiProvider.AUTO -> "Auto mode: Gemini first, OpenAI fallback."
            AiProvider.GEMINI -> "Gemini is now the preferred AI provider."
            AiProvider.OPENAI -> "OpenAI is now the preferred AI provider."
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 14.dp, 20.dp, 34.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                Spacer(Modifier.width(4.dp))
                Column {
                    Text("AI settings", style = MaterialTheme.typography.headlineLarge, color = Ink)
                    Text("Private keys stay on this device.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Surface(
                color = TealTint,
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BeraTeal.copy(alpha = .25f))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("How BeraTalk uses AI", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "AI plans lessons, questions and practice. It is never allowed to invent Esan, Igala or another minority-language translation. Target-language wording must come from your verified bank or your partner.",
                        color = Ink.copy(alpha = .82f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        item {
            Text("Preferred provider", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AiProviderButton("Auto", preferred == AiProvider.AUTO, Modifier.weight(1f)) { persistProvider(AiProvider.AUTO) }
                AiProviderButton("Gemini", preferred == AiProvider.GEMINI, Modifier.weight(1f)) { persistProvider(AiProvider.GEMINI) }
                AiProviderButton("OpenAI", preferred == AiProvider.OPENAI, Modifier.weight(1f)) { persistProvider(AiProvider.OPENAI) }
            }
            Spacer(Modifier.height(8.dp))
            Text("Auto uses Gemini first and OpenAI as fallback when both keys are available.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        item {
            AiProviderSettingsBlock(
                title = "Gemini",
                description = "Used for lesson planning and guided conversation missions.",
                apiKey = geminiKey,
                onApiKeyChange = { geminiKey = it },
                model = geminiModel,
                onModelChange = { geminiModel = it },
                revealKey = showGeminiKey,
                onRevealChange = { showGeminiKey = !showGeminiKey },
                defaultModel = "gemini-3.5-flash",
                isTesting = testing == AiProvider.GEMINI,
                onSave = {
                    secureSettings.setGemini(geminiKey, geminiModel)
                    onSettingsChanged()
                    status = if (geminiKey.isBlank()) "Gemini key removed from this device." else "Gemini settings saved on this device."
                },
                onTest = {
                    secureSettings.setGemini(geminiKey, geminiModel)
                    onSettingsChanged()
                    testing = AiProvider.GEMINI
                    scope.launch {
                        val result = router.test(AiProvider.GEMINI)
                        status = result.fold(
                            onSuccess = { "Gemini connected successfully." },
                            onFailure = { "Gemini test failed: ${it.message ?: "Unknown error"}" }
                        )
                        testing = null
                    }
                }
            )
        }
        item {
            AiProviderSettingsBlock(
                title = "OpenAI",
                description = "Available as your second provider or Auto fallback.",
                apiKey = openAiKey,
                onApiKeyChange = { openAiKey = it },
                model = openAiModel,
                onModelChange = { openAiModel = it },
                revealKey = showOpenAiKey,
                onRevealChange = { showOpenAiKey = !showOpenAiKey },
                defaultModel = "gpt-5.6-luna",
                isTesting = testing == AiProvider.OPENAI,
                onSave = {
                    secureSettings.setOpenAi(openAiKey, openAiModel)
                    onSettingsChanged()
                    status = if (openAiKey.isBlank()) "OpenAI key removed from this device." else "OpenAI settings saved on this device."
                },
                onTest = {
                    secureSettings.setOpenAi(openAiKey, openAiModel)
                    onSettingsChanged()
                    testing = AiProvider.OPENAI
                    scope.launch {
                        val result = router.test(AiProvider.OPENAI)
                        status = result.fold(
                            onSuccess = { "OpenAI connected successfully." },
                            onFailure = { "OpenAI test failed: ${it.message ?: "Unknown error"}" }
                        )
                        testing = null
                    }
                }
            )
        }
        status?.let { message ->
            item {
                AnimatedVisibility(visible = true, enter = fadeIn(), exit = fadeOut()) {
                    Surface(
                        color = if (message.contains("failed", ignoreCase = true)) CoralTint else Soft,
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text(message, Modifier.fillMaxWidth().padding(14.dp), color = Ink, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Text(
                "Security note: direct API keys are appropriate only for this private build. Do not distribute this APK publicly with personal provider keys saved in it.",
                color = Muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AiProviderButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val background by animateColorAsState(if (selected) Ink else Color.White, label = "providerBackground")
    val foreground by animateColorAsState(if (selected) Color.White else Ink, label = "providerForeground")
    Surface(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        color = background,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Ink else Border)
    ) {
        Box(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), contentAlignment = Alignment.Center) {
            Text(label, color = foreground, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun AiProviderSettingsBlock(
    title: String,
    description: String,
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    model: String,
    onModelChange: (String) -> Unit,
    revealKey: Boolean,
    onRevealChange: () -> Unit,
    defaultModel: String,
    isTesting: Boolean,
    onSave: () -> Unit,
    onTest: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(description, color = Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = apiKey,
                onValueChange = onApiKeyChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("API key") },
                visualTransformation = if (revealKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = onRevealChange) {
                        Icon(if (revealKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (revealKey) "Hide key" else "Show key", tint = Muted)
                    }
                },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = model,
                onValueChange = onModelChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Model") },
                supportingText = { Text("Default: $defaultModel") },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onTest,
                    enabled = apiKey.isNotBlank() && !isTesting,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (isTesting) "Testing…" else "Test", color = if (apiKey.isNotBlank() && !isTesting) Ink else Muted, fontWeight = FontWeight.Bold) }
                Button(
                    onClick = onSave,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
                ) { Text("Save", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable private fun Avatar(letter: String, color: Color) { Box(Modifier.size(54.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) { Text(letter, fontWeight = FontWeight.Black, color = Ink, style = MaterialTheme.typography.titleLarge) } }
@Composable private fun RowScope.DarkStat(value: String, label: String) { Column(Modifier.weight(1f)) { Text(value, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge); Text(label, color = Color.White.copy(.55f), style = MaterialTheme.typography.labelMedium) } }

@Composable
private fun ProgressBlock(title: String, values: List<Pair<String, Float>>, accent: Color) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(15.dp))
            values.forEach { (label, value) ->
                Row { Text(label, Modifier.weight(1f), color = Muted); Text("${(value * 100).toInt()}%", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(6.dp)); LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = accent, trackColor = Soft); Spacer(Modifier.height(13.dp))
            }
        }
    }
}

private fun currentGreeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White, disabledContainerColor = Soft, disabledContentColor = Muted)
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

