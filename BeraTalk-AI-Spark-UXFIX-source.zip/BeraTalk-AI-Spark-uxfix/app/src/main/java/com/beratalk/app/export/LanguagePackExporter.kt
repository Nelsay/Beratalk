package com.beratalk.app.export

import android.content.Context
import com.beratalk.app.model.LanguageEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class LanguagePackExporter(private val context: Context) {
    suspend fun export(language: String, entries: List<LanguageEntry>): File = withContext(Dispatchers.IO) {
        val out = File(context.cacheDir, "${language.lowercase()}-language-pack.zip")
        ZipOutputStream(out.outputStream().buffered()).use { zip ->
            val manifest = JSONObject().apply {
                put("format", "BeraTalk Language Pack")
                put("version", 1)
                put("language", language)
                put("exportedAt", System.currentTimeMillis())
                put("entryCount", entries.count { it.language.equals(language, true) })
            }
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(manifest.toString(2).toByteArray())
            zip.closeEntry()

            val array = JSONArray()
            entries.filter { it.language.equals(language, true) }.forEach { e ->
                var includedAudio: String? = null
                e.audioPath?.let { path ->
                    runCatching {
                        val input = if (path.startsWith("https://") || path.startsWith("http://")) {
                            URL(path).openStream()
                        } else {
                            File(path).takeIf { it.exists() }?.inputStream()
                        }
                        input?.use { source ->
                            val name = "audio/${e.id}.m4a"
                            zip.putNextEntry(ZipEntry(name))
                            source.copyTo(zip)
                            zip.closeEntry()
                            includedAudio = name
                        }
                    }
                }

                array.put(JSONObject().apply {
                    put("id", e.id)
                    put("type", e.type.name)
                    put("nativeText", e.nativeText)
                    put("meaning", e.meaning)
                    put("notes", e.notes)
                    put("dialect", e.dialect)
                    put("verified", e.verified)
                    put("createdAt", e.createdAt)
                    includedAudio?.let { put("audioFile", it) }
                })
            }
            zip.putNextEntry(ZipEntry("entries.json"))
            zip.write(array.toString(2).toByteArray())
            zip.closeEntry()
        }
        out
    }
}
