package com.beratalk.app.model

import java.util.UUID

enum class BankType(val label: String) { WORD("Words"), SENTENCE("Sentences"), CONVERSATION("Conversations"), STORY("Stories") }

data class LanguageEntry(
    val id: String = UUID.randomUUID().toString(),
    val type: BankType = BankType.WORD,
    val language: String = "Esan",
    val nativeText: String = "",
    val meaning: String = "",
    val notes: String = "",
    val dialect: String = "",
    val audioPath: String? = null,
    val verified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class VoiceMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String = "me",
    val localAudioPath: String,
    val durationMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val correctionFor: String? = null
)

data class Mission(
    val id: String,
    val title: String,
    val subtitle: String,
    val minutes: Int,
    val progress: Float,
    val steps: List<String>
)

data class AppProfile(
    val displayName: String = "",
    val speaks: String = "Esan",
    val learning: String = "Igala",
    val dialect: String = "",
    val dailyMinutes: Int = 10,
    val partnerName: String = "Partner",
    val pairId: String? = null
)
