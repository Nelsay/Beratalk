# BeraTalk keeps release builds readable for easier private debugging during early development.
