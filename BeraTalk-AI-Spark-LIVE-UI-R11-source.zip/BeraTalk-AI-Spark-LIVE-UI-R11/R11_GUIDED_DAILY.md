# BeraTalk 1.4.0-guided (R11)

Core runtime:
- Home / Chat / Learn / Library bottom navigation; Chat and Us are immersive screens.
- AI plans one shared English-only real-world conversation for the day.
- Both partners select a daily line in Chat and reply with their own natural text/voice; messages retain the daily-line link.
- Learn practices the partner's real daily text/voice instead of fabricated target-language wording.
- Library is guided: BeraTalk assigns up to 5 English prompts per day rather than asking users to invent vocabulary.
- Shared category progression requires parallel verified material from both active languages.
- Thresholds: 50 words -> 25 sentences -> 10 short conversations -> 3 stories, then the next category unlocks.
- Current categories: Everyday & survival, Family, Home, Market & food, School & work, Travel, Relationships, Health & safety, Culture & community.
- Quick Review is surfaced from Home and uses verified partner-language words only.
- Chat supports working text input, voice notes, slower playback, meaning/correction actions, multi-select Add to Bank, and shared deletion for curation.
- Settings: light/dark mode, theme choices, typed language switching, pair code display/regeneration, notifications, AI keys/provider.
- Notifications: daily local reminder, foreground partner-activity banners/notifications, FCM token registration and FCM receive service.

Important: publish `firebase/firestore.rules` before testing R11 text chat, shared message deletion, daily plans, or pair-code regeneration.
