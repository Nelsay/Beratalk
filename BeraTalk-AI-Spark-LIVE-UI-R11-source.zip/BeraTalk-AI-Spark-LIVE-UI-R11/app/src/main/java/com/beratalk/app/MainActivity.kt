package com.beratalk.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.beratalk.app.audio.VoicePlayer
import com.beratalk.app.audio.VoiceRecorder
import com.beratalk.app.data.FirebaseGateway
import com.beratalk.app.data.CurriculumCatalog
import com.beratalk.app.data.AiClientRouter
import com.beratalk.app.data.AiProvider
import com.beratalk.app.data.HybridAiLessonEngine
import com.beratalk.app.data.SecureAiSettings
import com.beratalk.app.export.LanguagePackExporter
import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.ChatMessage
import com.beratalk.app.model.DailyConversation
import com.beratalk.app.model.BankType
import com.beratalk.app.model.CoachChallenge
import com.beratalk.app.model.CoachNudge
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.LearningSession
import com.beratalk.app.model.LessonTask
import com.beratalk.app.model.LessonTaskType
import com.beratalk.app.model.Mission
import com.beratalk.app.model.VoiceMessage
import com.beratalk.app.ui.theme.BeraCoral
import com.beratalk.app.ui.theme.BeraCoralDeep
import com.beratalk.app.ui.theme.BeraOrange
import com.beratalk.app.ui.theme.BeraOrangeDeep
import com.beratalk.app.ui.theme.BeraTalkTheme
import com.beratalk.app.ui.theme.BeraUiTheme
import com.beratalk.app.ui.theme.UiThemePreferences
import com.beratalk.app.ui.theme.BeraTeal
import com.beratalk.app.ui.theme.BeraTealDeep
import com.beratalk.app.ui.theme.ActionColor
import com.beratalk.app.ui.theme.OnActionColor
import com.beratalk.app.ui.theme.SurfaceTone
import com.beratalk.app.ui.theme.IsBeraDark
import com.beratalk.app.ui.theme.Canvas
import com.beratalk.app.ui.theme.Border
import com.beratalk.app.ui.theme.CoralTint
import com.beratalk.app.ui.theme.OrangeTint
import com.beratalk.app.ui.theme.TealTint
import com.beratalk.app.ui.theme.Ink
import com.beratalk.app.ui.theme.Muted
import com.beratalk.app.ui.theme.Soft
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.io.File
import java.net.URL
import java.time.LocalDate
import android.os.Build
import com.beratalk.app.notifications.BeraNotifications
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val uiPreferences = remember { UiThemePreferences(context) }
            var uiTheme by remember { mutableStateOf(uiPreferences.loadTheme()) }
            var darkMode by remember { mutableStateOf(uiPreferences.loadDarkMode()) }
            BeraTalkTheme(theme = uiTheme, darkMode = darkMode) {
                BeraTalkRoot(
                    uiTheme = uiTheme,
                    darkMode = darkMode,
                    onUiThemeChange = { next ->
                        uiTheme = next
                        uiPreferences.saveTheme(next)
                    },
                    onDarkModeChange = { enabled ->
                        darkMode = enabled
                        uiPreferences.saveDarkMode(enabled)
                    }
                )
            }
        }
    }
}

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    LEARN("Learn", Icons.Default.AutoAwesome),
    CHAT("Chat", Icons.Default.ChatBubble),
    LIBRARY("Library", Icons.Default.LibraryBooks),
    US("Us", Icons.Default.People)
}

@Composable
fun BeraTalkRoot(uiTheme: BeraUiTheme, darkMode: Boolean, onUiThemeChange: (BeraUiTheme) -> Unit, onDarkModeChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val gateway = remember { FirebaseGateway(context) }
    var signedIn by remember { mutableStateOf(gateway.currentUid != null) }
    var profile by remember { mutableStateOf<AppProfile?>(null) }
    var checkingProfile by remember { mutableStateOf(false) }

    LaunchedEffect(signedIn) {
        if (signedIn && gateway.configured) {
            checkingProfile = true
            profile = runCatching { gateway.loadProfile() }.getOrNull()?.takeIf { !it.pairId.isNullOrBlank() }
            checkingProfile = false
        }
    }

    AnimatedContent(targetState = signedIn, label = "auth") { active ->
        if (!active) {
            AuthScreen(gateway = gateway, onSignedIn = { signedIn = true })
        } else if (checkingProfile) {
            LoadingScreen()
        } else if (profile == null) {
            SetupScreen(gateway = gateway) { completed -> profile = completed }
        } else {
            MainShell(profile = profile!!, gateway = gateway, uiTheme = uiTheme, darkMode = darkMode, onUiThemeChange = onUiThemeChange, onDarkModeChange = onDarkModeChange, onSignOut = {
                gateway.signOut()
                signedIn = false
                profile = null
            })
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(SurfaceTone), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandLockup(markSize = 44.dp)
            Spacer(Modifier.height(22.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(150.dp).height(5.dp).clip(CircleShape),
                color = BeraTealDeep,
                trackColor = TealTint
            )
            Spacer(Modifier.height(14.dp))
            Text("Loading your language pair…", color = Muted)
        }
    }
}

@Composable
private fun SetupScreen(gateway: FirebaseGateway, onComplete: (AppProfile) -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf(0) }
    var speaks by remember { mutableStateOf("") }
    var learning by remember { mutableStateOf("") }
    var dialect by remember { mutableStateOf("") }
    var dailyMinutes by remember { mutableStateOf(10) }
    var joinMode by remember { mutableStateOf(false) }
    var inviteCode by remember { mutableStateOf("") }
    var createdCode by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val totalSteps = 4

    Surface(color = Canvas, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (step > 0 && createdCode == null) {
                        IconButton(onClick = { step--; error = null }) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    BrandLockup(markSize = 34.dp, compact = true)
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.size(48.dp))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    repeat(totalSteps) { index ->
                        val active = index <= step
                        Box(
                            Modifier.weight(1f).height(5.dp).clip(CircleShape)
                                .background(if (active) BeraTealDeep else Border)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("STEP ${step + 1} OF $totalSteps", color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
            }
            item {
                AnimatedContent(targetState = step, label = "setupStep") { current ->
                    SetupStepCard {
                        when (current) {
                            0 -> {
                                Text("What do you naturally speak?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("Type it exactly as you call it.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(20.dp))
                                OutlinedTextField(
                                    value = speaks,
                                    onValueChange = { speaks = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Language") },
                                    placeholder = { Text("Type the language you speak") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(18.dp)
                                )
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue", enabled = speaks.trim().isNotBlank()) { step = 1 }
                            }
                            1 -> {
                                Text("What do you want to learn?", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text("You can change or add another journey later.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(20.dp))
                                OutlinedTextField(
                                    value = learning,
                                    onValueChange = { learning = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Language") },
                                    placeholder = { Text("Type the language you want to learn") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(18.dp)
                                )
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue", enabled = learning.trim().isNotBlank() && !learning.trim().equals(speaks.trim(), true)) { step = 2 }
                            }
                            2 -> {
                                Text("Make the learning fit your life", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Spacer(Modifier.height(18.dp))
                                OutlinedTextField(
                                    value = dialect,
                                    onValueChange = { dialect = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Dialect / local variant (optional)") },
                                    supportingText = { Text("The variety you naturally use at home.") },
                                    shape = RoundedCornerShape(18.dp)
                                )
                                Spacer(Modifier.height(20.dp))
                                Text("Daily practice", style = MaterialTheme.typography.titleMedium, color = Ink)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(5, 10, 20, 30).forEach { minutes ->
                                        val active = dailyMinutes == minutes
                                        Surface(
                                            modifier = Modifier.weight(1f).clickable { dailyMinutes = minutes },
                                            color = if (active) ActionColor else SurfaceTone,
                                            shape = RoundedCornerShape(15.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (active) ActionColor else Border)
                                        ) {
                                            Text("$minutes min", Modifier.padding(vertical = 12.dp), color = if (active) OnActionColor else Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                                PrimaryButton("Continue") { step = 3 }
                            }
                            else -> {
                                Text(if (createdCode == null) "Connect with your partner" else "Your pair is ready", style = MaterialTheme.typography.headlineLarge, color = Ink)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (createdCode == null) "Create the pair on one phone, then use the six-character code on the other." else "Send this code to your partner. You can enter BeraTalk now and they can join from their phone.",
                                    color = Muted,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Spacer(Modifier.height(22.dp))
                                if (createdCode == null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        PairModeChip("Create pair", !joinMode) { joinMode = false; error = null }
                                        PairModeChip("Join partner", joinMode) { joinMode = true; error = null }
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    if (joinMode) {
                                        OutlinedTextField(
                                            value = inviteCode,
                                            onValueChange = { inviteCode = it.uppercase().filter { it.isLetterOrDigit() }.take(6) },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("Partner code") },
                                            supportingText = { Text("Enter the six-character code from your partner's phone.") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(18.dp)
                                        )
                                    } else {
                                        Surface(color = TealTint, shape = RoundedCornerShape(18.dp)) {
                                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.People, null, tint = BeraTealDeep)
                                                Spacer(Modifier.width(11.dp))
                                                Text("You'll get a private code after creating the pair.", color = Ink, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                } else {
                                    Surface(color = Ink, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("YOUR PRIVATE PAIR CODE", color = Color.White.copy(.72f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.height(8.dp))
                                            Text(createdCode.orEmpty(), style = MaterialTheme.typography.displaySmall, color = Color.White, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                                error?.let {
                                    Spacer(Modifier.height(14.dp))
                                    Surface(color = CoralTint, shape = RoundedCornerShape(16.dp)) { Text(it, Modifier.fillMaxWidth().padding(13.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium) }
                                }
                                Spacer(Modifier.height(22.dp))
                                val label = when {
                                    busy -> "Setting things up…"
                                    createdCode != null -> "Enter BeraTalk"
                                    joinMode -> "Join language pair"
                                    else -> "Create language pair"
                                }
                                PrimaryButton(label, enabled = !busy && (createdCode != null || !joinMode || inviteCode.length == 6)) {
                                    val base = AppProfile(
                                        displayName = gateway.currentDisplayName,
                                        speaks = speaks.trim(),
                                        learning = learning.trim(),
                                        dialect = dialect.trim(),
                                        dailyMinutes = dailyMinutes
                                    )
                                    if (createdCode != null) {
                                        scope.launch {
                                            val stored = runCatching { gateway.loadProfile() }.getOrNull()
                                            if (stored?.pairId.isNullOrBlank()) error = "Your pair could not be loaded. Please create it again." else onComplete(stored!!)
                                        }
                                    } else scope.launch {
                                        busy = true
                                        error = null
                                        if (!gateway.configured) {
                                            error = "Firebase is not configured in this build. BeraTalk will not create fake local pairs."
                                        } else {
                                            runCatching {
                                                gateway.saveProfile(base)
                                                if (joinMode) {
                                                    val pairId = gateway.joinPair(inviteCode)
                                                    val final = base.copy(pairId = pairId)
                                                    gateway.saveProfile(final)
                                                    onComplete(final)
                                                } else {
                                                    val created = gateway.createPair(base)
                                                    gateway.saveProfile(base.copy(pairId = created.pairId))
                                                    createdCode = created.inviteCode
                                                }
                                            }.onFailure { error = it.message ?: "Could not connect the pair." }
                                        }
                                        busy = false
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupStepCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceTone),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border.copy(alpha = .65f))
    ) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) { content() }
    }
}

@Composable
private fun LanguageChoice(selected: String, onSelected: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Esan", "Igala").forEach { language ->
            val active = selected == language
            Surface(
                modifier = Modifier.weight(1f).clickable { onSelected(language) },
                color = if (active) ActionColor else SurfaceTone, shape = RoundedCornerShape(16.dp), shadowElevation = if (active) 5.dp else 0.dp, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) ActionColor else Border)
            ) {
                Text(language, Modifier.padding(vertical = 14.dp), color = if (active) OnActionColor else Ink, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PairModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) ActionColor else SurfaceTone, shape = RoundedCornerShape(999.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) ActionColor else Border), shadowElevation = if (selected) 4.dp else 0.dp, modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = if (selected) OnActionColor else Ink, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AuthScreen(gateway: FirebaseGateway, onSignedIn: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var signUp by remember { mutableStateOf(false) }

    val infinite = rememberInfiniteTransition(label = "logoFloat")
    val logoScale by infinite.animateFloat(
        initialValue = .99f, targetValue = 1.015f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale"
    )

    Surface(color = SurfaceTone, modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.scale(logoScale)) { BrandLockup(markSize = 48.dp) }
                    Spacer(Modifier.height(26.dp))
                    Text(
                        "Learn their language from them.",
                        style = MaterialTheme.typography.displaySmall,
                        color = Ink,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Real voices, real corrections, and AI-guided conversations built around the person you care about.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Muted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
            item {
                OutlinedTextField(
                    value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email") }, leadingIcon = { Icon(Icons.Outlined.Mail, null, tint = Ink) },
                    singleLine = true, shape = RoundedCornerShape(18.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }
            item {
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") }, leadingIcon = { Icon(Icons.Default.Lock, null, tint = Ink) },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true, shape = RoundedCornerShape(18.dp)
                )
            }
            item {
                PrimaryButton(
                    text = if (busy) "Please wait…" else if (signUp) "Create account" else "Continue",
                    enabled = !busy && email.isNotBlank() && password.length >= 6
                ) {
                    scope.launch {
                        busy = true; error = null
                        runCatching {
                            if (signUp) gateway.createEmailAccount(email, password) else gateway.signInEmail(email, password)
                        }.onSuccess { onSignedIn() }.onFailure { error = it.message }
                        busy = false
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                    Text("  or  ", color = Muted, style = MaterialTheme.typography.labelMedium)
                    HorizontalDivider(Modifier.weight(1f), color = Border)
                }
            }
            item {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            error = null
                            if (!gateway.configured) {
                                error = "Add your Firebase google-services.json first to enable Google sign-in."
                                return@launch
                            }
                            runCatching { googleSignIn(context, gateway) }
                                .onSuccess { onSignedIn() }
                                .onFailure { error = it.message ?: "Google sign-in failed" }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border)
                ) {
                    Text("G", fontWeight = FontWeight.Black, color = Color(0xFF1A73E8))
                    Spacer(Modifier.width(12.dp))
                    Text("Continue with Google", color = Ink, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (signUp) "Already have an account?" else "New to BeraTalk?", color = Muted)
                    TextButton(onClick = { signUp = !signUp }) { Text(if (signUp) "Sign in" else "Create account", color = ActionColor, fontWeight = FontWeight.Bold) }
                }
            }
            error?.let { message ->
                item {
                    Surface(color = CoralTint, shape = RoundedCornerShape(18.dp)) {
                        Text(message, modifier = Modifier.fillMaxWidth().padding(15.dp), color = BeraCoralDeep, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (!gateway.configured) {
                item {
                    Surface(color = TealTint, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BeraTealDeep.copy(alpha = .12f))) {
                        Column(Modifier.padding(17.dp)) {
                            Text("Firebase-ready build", style = MaterialTheme.typography.titleMedium, color = Ink)
                            Spacer(Modifier.height(5.dp))
                            Text("Authentication activates after app/google-services.json is added.", color = Muted)
                        }
                    }
                }
            }
        }
    }
}

private suspend fun googleSignIn(context: Context, gateway: FirebaseGateway) {
    val clientIdRes = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    require(clientIdRes != 0) { "Google web client ID not found. Re-download google-services.json after enabling Google sign-in in Firebase." }
    val webClientId = context.getString(clientIdRes)
    val googleOption = GetGoogleIdOption.Builder()
        .setServerClientId(webClientId)
        .setFilterByAuthorizedAccounts(false)
        .setAutoSelectEnabled(false)
        .build()
    val request = GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
    val result = CredentialManager.create(context).getCredential(context, request)
    val credential = GoogleIdTokenCredential.createFrom(result.credential.data)
    gateway.signInGoogle(credential.idToken)
}

@Composable
private fun MainShell(profile: AppProfile, gateway: FirebaseGateway, uiTheme: BeraUiTheme, darkMode: Boolean, onUiThemeChange: (BeraUiTheme) -> Unit, onDarkModeChange: (Boolean) -> Unit, onSignOut: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val entries = remember { mutableStateListOf<LanguageEntry>() }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val aiRouter = remember { AiClientRouter(context) }
    var currentProfile by remember(profile) { mutableStateOf(profile) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var lastTab by remember { mutableStateOf(Tab.HOME) }
    var showSettings by remember { mutableStateOf(false) }
    var showGame by remember { mutableStateOf(false) }
    var bankDraft by remember { mutableStateOf<BankDraft?>(null) }
    var daily by remember { mutableStateOf<DailyConversation?>(null) }
    var entriesReady by remember { mutableStateOf(false) }
    var aiSettingsRevision by remember { mutableStateOf(0) }
    var banner by remember { mutableStateOf<String?>(null) }
    var messagesInitialized by remember { mutableStateOf(false) }
    val knownMessageIds = remember { mutableStateListOf<String>() }
    val photoUrl = gateway.currentPhotoUrl
    val mainTabs = listOf(Tab.HOME, Tab.CHAT, Tab.LEARN, Tab.LIBRARY)

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) BeraNotifications.scheduleDaily(context)
    }

    fun navigate(next: Tab) {
        if (next in mainTabs) lastTab = next
        tab = next
    }

    fun saveEntry(entry: LanguageEntry) {
        val normalized = if (entry.trackKey.isBlank()) entry.copy(trackKey = CurriculumCatalog.trackKey(currentProfile)) else entry
        val beforeCategory = CurriculumCatalog.activeCategory(entries, currentProfile)
        val beforeType = CurriculumCatalog.activeType(entries, beforeCategory, currentProfile)
        fun announceUnlock() {
            val projected = entries.toList() + normalized
            val afterCategory = CurriculumCatalog.activeCategory(projected, currentProfile)
            val afterType = CurriculumCatalog.activeType(projected, afterCategory, currentProfile)
            banner = when {
                afterCategory != beforeCategory -> "${afterCategory.label} unlocked"
                afterType != beforeType -> "${afterType.label} unlocked"
                else -> banner
            }
        }
        val pairId = currentProfile.pairId
        if (gateway.configured && pairId != null) {
            scope.launch {
                runCatching { gateway.addEntry(pairId, normalized) }
                    .onSuccess { announceUnlock() }
                    .onFailure { banner = it.message ?: "Could not save." }
            }
        } else {
            entries.add(0, normalized)
            announceUnlock()
        }
    }

    fun updateEntry(entry: LanguageEntry) {
        val normalized = if (entry.trackKey.isBlank()) entry.copy(trackKey = CurriculumCatalog.trackKey(currentProfile)) else entry
        val pairId = currentProfile.pairId
        if (gateway.configured && pairId != null) {
            scope.launch { runCatching { gateway.updateEntry(pairId, normalized) }.onFailure { banner = it.message ?: "Could not update." } }
        } else {
            val index = entries.indexOfFirst { it.id == normalized.id }
            if (index >= 0) entries[index] = normalized
        }
    }

    fun deleteEntry(entry: LanguageEntry) {
        val pairId = currentProfile.pairId
        if (gateway.configured && pairId != null) {
            scope.launch { runCatching { gateway.deleteEntry(pairId, entry.id) }.onFailure { banner = it.message ?: "Could not delete." } }
        } else entries.removeAll { it.id == entry.id }
    }

    LaunchedEffect(Unit) {
        BeraNotifications.createChannels(context)
        BeraNotifications.scheduleDaily(context)
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (gateway.configured && gateway.currentUid != null) {
            runCatching { FirebaseMessaging.getInstance().token.await() }.getOrNull()?.let { token ->
                runCatching { gateway.registerMessagingToken(token) }
            }
        }
    }

    LaunchedEffect(currentProfile.pairId) {
        currentProfile.pairId?.let { pairId ->
            runCatching { gateway.ensurePairMemberName(pairId) }
            runCatching { gateway.loadPartnerName(pairId) }.getOrNull()?.let { name -> currentProfile = currentProfile.copy(partnerName = name) }
        }
    }

    DisposableEffect(currentProfile.pairId, gateway.configured) {
        val pairId = currentProfile.pairId?.takeIf { gateway.configured }
        val partnerRegistration = pairId?.let { id -> gateway.observePartnerName(id) { name -> currentProfile = currentProfile.copy(partnerName = name) } }
        val messageRegistration = pairId?.let { id ->
            gateway.observeChatMessages(id) { incoming ->
                if (messagesInitialized) {
                    val freshPartner = incoming.filter { it.id !in knownMessageIds && it.senderId != "me" }
                    if (freshPartner.isNotEmpty()) {
                        banner = if (freshPartner.last().kind == com.beratalk.app.model.ChatMessageKind.VOICE) "${currentProfile.partnerName} sent a voice note" else "${currentProfile.partnerName} sent a message"
                        BeraNotifications.showPartner(context, "BeraTalk", banner ?: "New partner activity")
                    }
                }
                messages.clear(); messages.addAll(incoming)
                knownMessageIds.clear(); knownMessageIds.addAll(incoming.map { it.id })
                messagesInitialized = true
            }
        }
        val entryRegistration = pairId?.let { id -> gateway.observeEntries(id) { incoming -> entries.clear(); entries.addAll(incoming); entriesReady = true } }
        if (pairId == null) entriesReady = true
        onDispose { partnerRegistration?.remove(); messageRegistration?.remove(); entryRegistration?.remove() }
    }

    LaunchedEffect(entriesReady, entries.size, currentProfile.speaks, currentProfile.learning, aiSettingsRevision) {
        if (!entriesReady) return@LaunchedEffect
        val category = CurriculumCatalog.activeCategory(entries, currentProfile)
        val today = LocalDate.now()
        val stage = CurriculumCatalog.activeType(entries, category, currentProfile)
        val track = CurriculumCatalog.trackKey(currentProfile)
        val planKey = "${track}__${today}"
        val fallback = CurriculumCatalog.localConversation(category, today).copy(id = planKey, dateKey = planKey)
        val pairId = currentProfile.pairId
        val existing = if (pairId != null && gateway.configured) runCatching { gateway.loadDailyConversation(pairId, planKey) }.getOrNull() else null
        if (existing != null) {
            daily = existing
        } else {
            val ai = runCatching { aiRouter.buildDailyConversation(category, currentProfile.learning, stage) }.getOrNull()
            val candidate = (ai ?: fallback).copy(id = planKey, dateKey = planKey)
            daily = if (pairId != null && gateway.configured) runCatching { gateway.getOrCreateDailyConversation(pairId, candidate) }.getOrDefault(candidate) else candidate
        }
    }

    LaunchedEffect(banner) {
        if (banner != null) { delay(4200); banner = null }
    }

    BackHandler(enabled = showSettings || showGame || tab != Tab.HOME) {
        when {
            showSettings -> showSettings = false
            showGame -> showGame = false
            tab == Tab.US -> tab = lastTab
            tab == Tab.CHAT -> tab = Tab.HOME
            tab != Tab.HOME -> tab = Tab.HOME
        }
    }

    if (showSettings) {
        R11SettingsScreen(
            profile = currentProfile,
            gateway = gateway,
            uiTheme = uiTheme,
            darkMode = darkMode,
            onUiThemeChange = onUiThemeChange,
            onDarkModeChange = onDarkModeChange,
            onProfileChange = { currentProfile = it },
            onBack = { showSettings = false },
            onAiSettingsChanged = { aiSettingsRevision++ }
        )
        return
    }

    if (showGame) {
        R11QuickGameScreen(entries, currentProfile, onBack = { showGame = false })
        return
    }

    Scaffold(
        containerColor = Canvas,
        bottomBar = {
            if (tab != Tab.CHAT && tab != Tab.US) {
                R11BottomBar(if (tab in mainTabs) tab else lastTab) { navigate(it) }
            }
        }
    ) { insets ->
        Box(Modifier.fillMaxSize().padding(insets)) {
            Crossfade(targetState = tab, label = "r11-tabs") { current ->
                when (current) {
                    Tab.HOME -> R11HomeScreen(
                        profile = currentProfile,
                        daily = daily,
                        entries = entries,
                        messages = messages,
                        photoUrl = photoUrl,
                        onConversation = { navigate(Tab.CHAT) },
                        onBank = { navigate(Tab.LIBRARY) },
                        onGame = { showGame = true },
                        onProfile = { tab = Tab.US }
                    )
                    Tab.CHAT -> R11ChatScreen(
                        profile = currentProfile,
                        daily = daily,
                        messages = messages,
                        entries = entries,
                        photoUrl = photoUrl,
                        resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                        onBack = { tab = Tab.HOME },
                        onProfile = { tab = Tab.US },
                        onSendText = { text, dailyLineId ->
                            val pairId = currentProfile.pairId
                            if (pairId != null && gateway.configured) scope.launch { runCatching { gateway.sendTextMessage(pairId, text, dailyLineId) }.onFailure { banner = it.message ?: "Message failed." } }
                        },
                        onSendVoice = { file, duration, correctionFor, dailyLineId ->
                            val pairId = currentProfile.pairId
                            if (pairId != null && gateway.configured) scope.launch { runCatching { gateway.sendVoiceMessage(pairId, file, duration, correctionFor, dailyLineId) }.onFailure { banner = it.message ?: "Voice note failed." } }
                        },
                        onDelete = { ids ->
                            val pairId = currentProfile.pairId
                            if (pairId != null && gateway.configured) scope.launch { runCatching { gateway.deleteChatMessages(pairId, ids) }.onFailure { banner = it.message ?: "Delete failed." } }
                        },
                        onBankSelection = { draft -> bankDraft = draft; tab = Tab.LIBRARY }
                    )
                    Tab.LEARN -> R11LearnScreen(
                        profile = currentProfile,
                        daily = daily,
                        messages = messages,
                        photoUrl = photoUrl,
                        resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                        onChat = { navigate(Tab.CHAT) },
                        onProfile = { tab = Tab.US }
                    )
                    Tab.LIBRARY -> R11LibraryScreen(
                        profile = currentProfile,
                        entries = entries,
                        initialDraft = bankDraft,
                        resolveAudio = { path -> if (gateway.configured) gateway.materializeAudioPath(path) else path },
                        onSave = ::saveEntry,
                        onUpdate = ::updateEntry,
                        onDelete = ::deleteEntry,
                        onDraftConsumed = { bankDraft = null }
                    )
                    Tab.US -> R11UsScreen(currentProfile, entries, photoUrl, onSettings = { showSettings = true }, onSignOut = onSignOut)
                }
            }
            AnimatedVisibility(
                visible = banner != null,
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(color = ActionColor, shape = RoundedCornerShape(999.dp), shadowElevation = 10.dp) {
                    Text(banner.orEmpty(), Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = OnActionColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun BrandMonogram(size: Dp = 38.dp, modifier: Modifier = Modifier) {
    val stroke = size * .14f
    Box(modifier = modifier.size(size)) {
        Box(
            Modifier.offset(x = size * .08f, y = size * .08f)
                .width(stroke).height(size * .78f)
                .clip(RoundedCornerShape(999.dp)).background(Color.Black)
        )
        Box(
            Modifier.offset(x = size * .15f, y = size * .39f)
                .size(size * .43f)
                .border(stroke, Color.Black, CircleShape)
        )
        Box(
            Modifier.offset(x = size * .62f, y = size * .19f)
                .width(stroke).height(size * .66f)
                .clip(RoundedCornerShape(999.dp)).background(Color.Black)
        )
        Box(
            Modifier.offset(x = size * .50f, y = size * .31f)
                .width(size * .41f).height(stroke)
                .clip(RoundedCornerShape(999.dp)).background(Color.Black)
        )
    }
}

@Composable
private fun BrandLockup(markSize: Dp = 40.dp, compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (IsBeraDark) {
            Surface(color = Color.White, shape = RoundedCornerShape(12.dp)) {
                BrandMonogram(size = markSize, modifier = Modifier.padding(5.dp))
            }
        } else {
            BrandMonogram(size = markSize)
        }
        Spacer(Modifier.width(if (compact) 9.dp else 11.dp))
        Text(
            "BeraTalk",
            color = Ink,
            style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor, disabledContainerColor = Soft, disabledContentColor = Muted)
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}
