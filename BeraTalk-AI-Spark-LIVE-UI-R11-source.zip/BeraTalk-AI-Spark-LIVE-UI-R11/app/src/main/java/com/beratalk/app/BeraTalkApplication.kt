package com.beratalk.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.beratalk.app.notifications.BeraNotifications

class BeraTalkApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching { FirebaseApp.initializeApp(this) }
        BeraNotifications.createChannels(this)
        BeraNotifications.scheduleDaily(this)
    }
}
