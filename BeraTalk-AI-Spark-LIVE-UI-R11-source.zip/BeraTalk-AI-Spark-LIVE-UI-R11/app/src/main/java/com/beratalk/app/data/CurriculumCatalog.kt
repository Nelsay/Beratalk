package com.beratalk.app.data

import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.BankPrompt
import com.beratalk.app.model.BankTask
import com.beratalk.app.model.BankType
import com.beratalk.app.model.CategoryProgress
import com.beratalk.app.model.ContentCategory
import com.beratalk.app.model.DailyConversation
import com.beratalk.app.model.LanguageEntry
import java.time.LocalDate
import java.time.ZoneId

/**
 * English-only curriculum spine. It tells partners WHAT concept to contribute.
 * It never supplies minority-language wording; that comes from the people who speak it.
 */
object CurriculumCatalog {
    private data class Content(
        val words: List<String>,
        val sentences: List<String>,
        val conversations: List<List<String>>,
        val stories: List<String>
    )

    private val everyday = Content(
        words = listOf(
            "yes", "no", "please", "thank you", "sorry", "hello", "good morning", "good afternoon", "good evening", "goodbye",
            "come", "go", "stop", "wait", "sit", "stand", "eat", "drink", "sleep", "wake up",
            "give", "take", "bring", "keep", "open", "close", "look", "listen", "speak", "help",
            "where", "what", "who", "when", "why", "how", "here", "there", "now", "later",
            "today", "tomorrow", "yesterday", "morning", "night", "water", "food", "money", "house", "road",
            "person", "friend", "child", "big", "small", "good", "bad", "hot", "cold", "enough"
        ),
        sentences = listOf(
            "Come here.", "Wait for me.", "Sit down.", "Stand up.", "Give me water.",
            "I want to eat.", "I am tired.", "I am coming.", "I am going now.", "Where are you going?",
            "What are you doing?", "Who is there?", "When are you coming?", "How are you?", "I am fine.",
            "Please help me.", "Bring it here.", "Take this with you.", "Open the door.", "Close the door.",
            "I do not understand.", "Say it again.", "Speak slowly.", "I will come later.", "See you tomorrow.",
            "It is too hot.", "It is too cold.", "That is enough.", "I do not have money.", "Let us go home."
        ),
        conversations = listOf(
            listOf("How are you?", "I am fine. How are you?", "I am fine too."),
            listOf("Where are you going?", "I am going home.", "When will you come back?", "I will come back later."),
            listOf("Are you hungry?", "Yes, I want to eat.", "What do you want?", "Anything is fine."),
            listOf("Please wait for me.", "How long?", "Just a little while.", "Okay, I will wait."),
            listOf("Who is at the door?", "It is me.", "Come in.", "Thank you."),
            listOf("Do you understand?", "No, say it again.", "Should I speak slowly?", "Yes, please."),
            listOf("Are you coming with me?", "Yes, where are we going?", "We are going nearby.", "Okay, let us go."),
            listOf("What time are you leaving?", "I am leaving now.", "Call me when you arrive.", "I will."),
            listOf("Can you help me?", "What do you need?", "Please bring that for me.", "No problem."),
            listOf("Are you ready?", "Not yet.", "What are you waiting for?", "Give me one minute.")
        ),
        stories = listOf(
            "This morning I woke up early, drank water, ate something small, and left the house.",
            "Yesterday I went out with a friend. We talked for a while, bought food, and came home later.",
            "I was tired in the evening, so I closed the door, ate dinner, and went to sleep early."
        )
    )

    private val family = Content(
        words = listOf(
            "mother", "father", "parents", "child", "children", "son", "daughter", "brother", "sister", "older brother",
            "younger brother", "older sister", "younger sister", "husband", "wife", "partner", "grandmother", "grandfather", "aunt", "uncle",
            "cousin", "niece", "nephew", "family", "home town", "elder", "baby", "relative", "in-law", "visitor",
            "name", "age", "married", "single", "pregnant", "born", "grow up", "love", "respect", "care",
            "visit", "call", "miss", "live", "stay", "together", "alone", "argument", "peace", "advice",
            "wedding", "funeral", "birthday", "household", "responsibility", "permission", "greeting", "blessing", "story", "memory"
        ),
        sentences = listOf(
            "This is my mother.", "That is my younger brother.", "How is your family?", "My parents are fine.", "I have two sisters.",
            "Where does your family live?", "My family lives in my home town.", "I am going to visit my parents.", "Call your mother.", "Your father is asking for you.",
            "My sister is getting married.", "The baby is sleeping.", "My brother is at work.", "We grew up together.", "I miss my family.",
            "Please greet your parents for me.", "My grandmother told me this story.", "We are expecting visitors.", "Who is the oldest child?", "I am the youngest.",
            "My cousin is coming tomorrow.", "We had a small family argument.", "Everything is fine now.", "I need my father's advice.", "We are going home for the weekend.",
            "My aunt lives nearby.", "The children are outside.", "Please look after the baby.", "Our family is large.", "We will see everyone at the wedding."
        ),
        conversations = listOf(
            listOf("How is your mother?", "She is fine.", "And your father?", "He is fine too."),
            listOf("How many brothers do you have?", "I have two brothers.", "Are they older or younger?", "One is older and one is younger."),
            listOf("Are you going home this weekend?", "Yes, I want to see my parents.", "When will you return?", "On Sunday evening."),
            listOf("Who is that?", "That is my cousin.", "Is this their first visit?", "Yes, they arrived today."),
            listOf("Please greet your family for me.", "I will.", "Tell your mother I asked about her.", "Of course."),
            listOf("The baby is crying.", "Is the baby hungry?", "I think so.", "Let me check."),
            listOf("When is your sister's wedding?", "Next month.", "Are you travelling for it?", "Yes, the whole family is going."),
            listOf("Who is the oldest in your family?", "My elder brother.", "Does he live nearby?", "No, he lives in another city."),
            listOf("Why did you call your father?", "I needed advice.", "Did he help?", "Yes, we talked for a long time."),
            listOf("Are visitors still coming?", "Yes, they will arrive tonight.", "Should we prepare food?", "Yes, let us start now.")
        ),
        stories = listOf(
            "Last weekend I went home to visit my parents. My brothers and sisters were there, and we ate together and talked late into the night.",
            "My grandmother used to tell us stories when we were children. Everyone would sit around her and listen before going to sleep.",
            "We had a family celebration last month. Relatives came from different places, the children played outside, and the elders gave us advice."
        )
    )

    private val home = Content(
        words = listOf(
            "room", "bedroom", "sitting room", "kitchen", "bathroom", "door", "window", "roof", "floor", "wall",
            "chair", "table", "bed", "mattress", "cup", "plate", "spoon", "pot", "bucket", "broom",
            "soap", "water", "light", "electricity", "fan", "key", "clothes", "shoe", "bag", "phone",
            "charge", "cook", "wash", "sweep", "clean", "dirty", "inside", "outside", "upstairs", "downstairs",
            "rent", "landlord", "neighbour", "compound", "gate", "lock", "bath", "laundry", "meal", "leftover",
            "morning", "evening", "chore", "rest", "noise", "quiet", "broken", "repair", "full", "empty"
        ),
        sentences = listOf(
            "Open the window.", "Lock the door.", "The light is off.", "There is no electricity.", "Please charge my phone.",
            "The water is finished.", "I am cooking in the kitchen.", "Please wash the plates.", "Sweep the floor.", "The room is dirty.",
            "I have finished cleaning.", "Where is the key?", "The key is on the table.", "My clothes are outside.", "Bring the clothes inside.",
            "I want to take a bath.", "The food is ready.", "Keep the leftover food.", "The neighbour is calling you.", "Someone is at the gate.",
            "The fan is not working.", "We need to repair it.", "The bucket is full.", "The pot is empty.", "Please keep the room quiet.",
            "I am going to rest.", "The landlord came today.", "We need to pay the rent.", "I left my bag in the bedroom.", "Let us clean before the visitors arrive."
        ),
        conversations = listOf(
            listOf("Where is the key?", "It is on the table.", "Which table?", "The one in the sitting room."),
            listOf("Is the food ready?", "Almost.", "Should I set the table?", "Yes, please."),
            listOf("There is no water.", "Did you check the bucket?", "It is empty.", "I will get some."),
            listOf("Who is at the gate?", "It is our neighbour.", "Should I open it?", "Yes."),
            listOf("The room is hot.", "Open the window.", "The fan is also on.", "That should help."),
            listOf("Did you wash the plates?", "Not yet.", "Please do it before you rest.", "Okay."),
            listOf("My phone is almost dead.", "Use my charger.", "Where is it?", "Beside the bed."),
            listOf("The light is not working.", "Is there electricity?", "Yes.", "Then the bulb may be bad."),
            listOf("The landlord came today.", "What did he say?", "He asked about the rent.", "We will sort it out."),
            listOf("Visitors are coming.", "When?", "This evening.", "Let us clean the sitting room.")
        ),
        stories = listOf(
            "I woke up and cleaned the house before breakfast. I swept the floor, washed the plates, and opened the windows because the room was hot.",
            "Yesterday the electricity went off in the evening. We sat outside for a while, talked with our neighbour, and came back inside when the light returned.",
            "We had visitors at home, so we cooked extra food, cleaned the sitting room, and brought more chairs before they arrived."
        )
    )

    private val marketFood = Content(
        words = listOf(
            "market", "shop", "seller", "customer", "price", "money", "change", "cash", "transfer", "cheap",
            "expensive", "reduce", "buy", "sell", "pay", "bag", "basket", "food", "rice", "beans",
            "yam", "garri", "bread", "meat", "fish", "chicken", "egg", "vegetable", "pepper", "tomato",
            "onion", "oil", "salt", "sugar", "water", "drink", "fruit", "banana", "orange", "plantain",
            "breakfast", "lunch", "dinner", "hungry", "thirsty", "cook", "eat", "taste", "sweet", "spicy",
            "fresh", "spoilt", "small", "large", "one", "two", "many", "enough", "takeaway", "restaurant"
        ),
        sentences = listOf(
            "How much is this?", "That is too expensive.", "Please reduce the price.", "I want to buy this.", "Give me two.",
            "Do you have change?", "I will pay by transfer.", "The transfer has gone through.", "Please put it in a bag.", "I do not want that one.",
            "Give me the fresh one.", "I need rice and beans.", "Buy some tomatoes.", "We need cooking oil.", "The food is ready.",
            "I am hungry.", "I am thirsty.", "What do you want to eat?", "This food is spicy.", "It tastes good.",
            "The meat is not fresh.", "Do you have a smaller one?", "That is enough for us.", "Keep the change.", "I am going to the market.",
            "What did you buy?", "We are cooking dinner.", "Please wash the vegetables.", "I want takeaway.", "Let us eat before we leave."
        ),
        conversations = listOf(
            listOf("How much is this?", "It is two thousand naira.", "That is too expensive. Please reduce it.", "What price do you want to pay?"),
            listOf("Do you have fresh tomatoes?", "Yes, these came today.", "Give me some of these.", "How many do you want?"),
            listOf("Can I pay by transfer?", "Yes.", "I have sent it.", "Let me confirm."),
            listOf("What do you want to eat?", "Rice is fine.", "Do you want meat or fish?", "Fish, please."),
            listOf("Are you going to the market?", "Yes.", "Please buy onions and pepper.", "Okay, anything else?"),
            listOf("This food is too spicy.", "Do you want water?", "Yes, please.", "Here you are."),
            listOf("Do you have a smaller one?", "Yes, this one is smaller.", "How much is it?", "It is cheaper."),
            listOf("Have you eaten?", "Not yet.", "There is food in the kitchen.", "I will eat now."),
            listOf("Is the meat fresh?", "Yes, it is fresh.", "Give me this piece.", "Okay."),
            listOf("The transfer has not shown yet.", "Please check again.", "I can see it now.", "Thank you.")
        ),
        stories = listOf(
            "I went to the market in the morning to buy food. I bought rice, vegetables, fish, and fruit, then paid by transfer and went home.",
            "We were hungry after work, so we stopped at a small restaurant. I ordered rice and fish, while my friend ordered beans and plantain.",
            "The seller first gave me a high price, so I asked her to reduce it. We agreed on a better price and I bought what I needed."
        )
    )

    private val schoolWork = Content(
        words = listOf(
            "school", "class", "student", "teacher", "lecturer", "book", "notebook", "pen", "exam", "test",
            "assignment", "result", "course", "subject", "lesson", "study", "learn", "read", "write", "question",
            "answer", "office", "work", "job", "boss", "colleague", "customer", "meeting", "email", "computer",
            "phone", "deadline", "salary", "money", "break", "late", "early", "busy", "free", "finish",
            "start", "send", "receive", "print", "design", "report", "project", "client", "interview", "application",
            "skill", "experience", "problem", "solution", "correct", "wrong", "easy", "difficult", "today", "tomorrow"
        ),
        sentences = listOf(
            "I am going to school.", "Class starts at eight.", "The teacher is here.", "I have an assignment.", "When is the exam?",
            "I need to study tonight.", "I do not understand this question.", "Please explain it again.", "I have finished the assignment.", "What result did you get?",
            "I am going to work.", "I am already at the office.", "My boss is in a meeting.", "I have a lot of work today.", "The deadline is tomorrow.",
            "Please send me the file.", "I have sent the email.", "The client called me.", "We need to finish this project.", "I am taking a short break.",
            "I will be late today.", "I finished work early.", "I am looking for a job.", "I have an interview tomorrow.", "Please check my application.",
            "This task is difficult.", "I know how to do it.", "Can you help me with this?", "The meeting has started.", "Let us continue tomorrow."
        ),
        conversations = listOf(
            listOf("When is your exam?", "On Friday.", "Have you started studying?", "Yes, but I still have a lot to read."),
            listOf("Did you finish the assignment?", "Almost.", "When will you submit it?", "Tonight."),
            listOf("Why are you late?", "There was traffic.", "Has the meeting started?", "Yes, but you can still join."),
            listOf("Did the client reply?", "Yes, they sent feedback.", "Is there a lot to change?", "Only a few things."),
            listOf("Can you send me the file?", "I am sending it now.", "Did you receive it?", "Yes, I have it."),
            listOf("Are you busy?", "A little.", "Can we talk after work?", "Yes, call me later."),
            listOf("How was the interview?", "It went well.", "When will they reply?", "They said next week."),
            listOf("What are you studying?", "I am reading for tomorrow's class.", "Is it difficult?", "Some parts are."),
            listOf("Are you done for today?", "Not yet.", "What is left?", "I need to finish one report."),
            listOf("Did you get your result?", "Yes.", "How did you do?", "I did well." )
        ),
        stories = listOf(
            "I had an exam in the morning, so I woke up early and read my notes again before going to school. The exam was difficult, but I finished on time.",
            "Work was busy today. I had a meeting, answered emails, spoke with a client, and finished a report before leaving the office.",
            "I applied for a new job and was invited for an interview. I prepared my documents, arrived early, and answered several questions about my experience."
        )
    )

    private val travel = Content(
        words = listOf(
            "travel", "journey", "road", "bus", "car", "taxi", "bike", "driver", "passenger", "station",
            "park", "airport", "flight", "ticket", "seat", "bag", "luggage", "passport", "hotel", "room",
            "city", "village", "town", "country", "home", "left", "right", "straight", "near", "far",
            "here", "there", "where", "direction", "address", "map", "traffic", "stop", "enter", "come down",
            "leave", "arrive", "early", "late", "morning", "evening", "price", "fare", "book", "cancel",
            "delay", "lost", "find", "call", "wait", "safe", "danger", "police", "fuel", "distance"
        ),
        sentences = listOf(
            "Where are you going?", "I am travelling tomorrow.", "I am going to the bus park.", "How much is the fare?", "Please stop here.",
            "I want to come down here.", "Go straight.", "Turn left.", "Turn right.", "It is not far.",
            "I do not know this road.", "Please show me the way.", "What is the address?", "I am stuck in traffic.", "I will be late.",
            "The bus has arrived.", "The flight is delayed.", "I have booked a ticket.", "Where is my seat?", "My bag is missing.",
            "I need a hotel room.", "Call me when you arrive.", "I arrived safely.", "Wait for me at the station.", "The driver is coming.",
            "We need fuel.", "How long is the journey?", "I am already on the road.", "I missed the bus.", "Let us leave early."
        ),
        conversations = listOf(
            listOf("Where are you going?", "I am going to the bus park.", "Are you travelling today?", "Yes, this afternoon."),
            listOf("How much is the fare?", "It is three thousand naira.", "Does this bus go directly?", "Yes."),
            listOf("Please stop here.", "Here?", "Yes, I want to come down here.", "Okay."),
            listOf("How do I get there?", "Go straight and turn left.", "Is it far?", "No, it is nearby."),
            listOf("Have you arrived?", "Not yet, there is traffic.", "How long will you be?", "Maybe thirty minutes."),
            listOf("Where is your ticket?", "It is on my phone.", "And your ID?", "I have it with me."),
            listOf("The flight is delayed.", "For how long?", "About one hour.", "Let us wait here."),
            listOf("I cannot find my bag.", "Where did you last see it?", "Beside my seat.", "Let us check there."),
            listOf("Do you need a hotel?", "Yes, for one night.", "I know a place nearby.", "Please show me."),
            listOf("Are you on the road?", "Yes, we just left.", "Call me when you get close.", "I will." )
        ),
        stories = listOf(
            "I travelled to another city by bus. We left early, spent several hours on the road, stopped once for food, and arrived in the evening.",
            "My flight was delayed, so I waited at the airport for more than an hour. When boarding started, I found my seat and called home before takeoff.",
            "I did not know the road, so I asked someone for directions. They told me to go straight, turn left, and look for a building near the junction."
        )
    )

    private val relationships = Content(
        words = listOf(
            "love", "like", "miss", "care", "trust", "respect", "happy", "sad", "angry", "upset",
            "tired", "worried", "jealous", "proud", "sorry", "forgive", "promise", "truth", "lie", "joke",
            "laugh", "smile", "hug", "kiss", "date", "partner", "friend", "together", "alone", "call",
            "text", "reply", "listen", "understand", "explain", "argue", "peace", "problem", "support", "help",
            "plan", "future", "marriage", "home", "family", "visit", "remember", "forget", "wait", "late",
            "busy", "free", "attention", "feeling", "mood", "kind", "serious", "playful", "beautiful", "handsome"
        ),
        sentences = listOf(
            "I miss you.", "I love you.", "Are you okay?", "I am upset.", "I am not angry with you.",
            "Please listen to me.", "Let me explain.", "I understand you.", "I am sorry.", "Please forgive me.",
            "I was only joking.", "You made me laugh.", "Call me when you are free.", "Why did you not reply?", "I was busy.",
            "I am proud of you.", "Thank you for helping me.", "I trust you.", "Do not worry.", "We will sort it out.",
            "I want to see you.", "When are we meeting?", "Let us make a plan.", "I remember what you said.", "Do not forget me.",
            "I need some time.", "Let us talk later.", "I am happy with you.", "Tell me how you feel.", "We are in this together."
        ),
        conversations = listOf(
            listOf("Are you okay?", "I am a little upset.", "Do you want to talk about it?", "Yes, but give me a minute."),
            listOf("Why did you not reply?", "I was busy at work.", "I thought you were ignoring me.", "No, I was not."),
            listOf("I am sorry.", "What are you sorry for?", "I should have listened better.", "Thank you for saying that."),
            listOf("I miss you.", "I miss you too.", "When will I see you?", "This weekend."),
            listOf("Are you angry with me?", "No, I am just tired.", "Do you want to rest?", "Yes, let us talk later."),
            listOf("You look happy today.", "I got good news.", "Tell me.", "I will tell you everything."),
            listOf("Can we make a plan for tomorrow?", "Yes.", "What time are you free?", "After work."),
            listOf("I was only joking.", "That joke was not funny.", "I understand. I am sorry.", "Okay."),
            listOf("Thank you for helping me.", "You do not need to thank me.", "It meant a lot to me.", "I am glad."),
            listOf("What are you thinking about?", "Our future.", "Is something worrying you?", "No, I just want us to plan well." )
        ),
        stories = listOf(
            "We had a misunderstanding because I did not reply for several hours. Later we talked calmly, explained what happened, and made peace.",
            "My partner had a difficult day, so I listened, encouraged them, and stayed on the phone until they felt better.",
            "We spent the weekend together, visited family, ate out, laughed about old stories, and made plans for the next month."
        )
    )

    private val health = Content(
        words = listOf(
            "health", "sick", "well", "pain", "headache", "stomach", "fever", "cough", "cold", "wound",
            "blood", "medicine", "tablet", "hospital", "clinic", "doctor", "nurse", "pharmacy", "appointment", "emergency",
            "help", "danger", "safe", "accident", "fall", "burn", "cut", "swelling", "weak", "dizzy",
            "sleep", "rest", "eat", "drink", "water", "food", "allergy", "pregnant", "child", "adult",
            "morning", "night", "today", "yesterday", "better", "worse", "check", "wait", "call", "ambulance",
            "police", "address", "name", "age", "breathe", "slowly", "quickly", "careful", "clean", "bandage"
        ),
        sentences = listOf(
            "I am not feeling well.", "My head hurts.", "I have a fever.", "My stomach hurts.", "I have been coughing.",
            "I need to see a doctor.", "Let us go to the hospital.", "Where is the nearest pharmacy?", "I need this medicine.", "Have you taken your medicine?",
            "Drink some water.", "You need to rest.", "Are you feeling better?", "I feel worse today.", "Please call for help.",
            "There has been an accident.", "Be careful.", "The wound is bleeding.", "We need a bandage.", "Do not touch it.",
            "Can you breathe well?", "Sit down slowly.", "I feel dizzy.", "What is your name?", "How old are you?",
            "The doctor is coming.", "Please wait here.", "I have an appointment today.", "The child is sick.", "Everything is okay now."
        ),
        conversations = listOf(
            listOf("Are you feeling well?", "No, I have a headache.", "Did you take anything?", "Not yet."),
            listOf("You feel hot.", "I think I have a fever.", "Let us check.", "Okay."),
            listOf("Where is the nearest pharmacy?", "There is one down the road.", "Is it still open?", "Yes."),
            listOf("Did you take your medicine?", "Yes, this morning.", "Are you feeling better?", "A little."),
            listOf("I feel dizzy.", "Sit down.", "Should I get water?", "Yes, please."),
            listOf("There has been an accident.", "Is anyone hurt?", "Yes, please call for help.", "I am calling now."),
            listOf("When is your appointment?", "This afternoon.", "Do you want me to come with you?", "Yes."),
            listOf("The child is coughing.", "For how long?", "Since yesterday.", "We should see a doctor."),
            listOf("Where does it hurt?", "My stomach.", "Is the pain severe?", "Not too severe."),
            listOf("Can you breathe well?", "Yes, but I feel weak.", "Lie down and rest.", "Okay." )
        ),
        stories = listOf(
            "I woke up feeling sick, so I stayed home and rested. Later I went to the clinic, spoke with a doctor, and bought medicine from the pharmacy.",
            "Someone fell near our house and hurt their leg. We helped them sit down, cleaned the wound, and called a family member.",
            "The child had a fever during the night. We gave them water, checked the temperature, and went to the hospital in the morning."
        )
    )

    private val culture = Content(
        words = listOf(
            "community", "village", "home town", "elder", "chief", "family", "visitor", "greeting", "respect", "welcome",
            "festival", "ceremony", "wedding", "funeral", "birthday", "meeting", "dance", "music", "song", "story",
            "proverb", "name", "title", "language", "dialect", "tradition", "custom", "food", "clothes", "gift",
            "blessing", "prayer", "thanks", "invitation", "guest", "host", "neighbour", "friend", "child", "adult",
            "morning", "evening", "journey", "return", "visit", "sit", "eat", "drink", "speak", "listen",
            "learn", "teach", "remember", "old", "new", "together", "peace", "celebrate", "help", "home"
        ),
        sentences = listOf(
            "Welcome to our home.", "Please come and sit down.", "Greet the elders first.", "Thank you for coming.", "We are happy to see you.",
            "Where is your home town?", "I am going home for a ceremony.", "The family meeting is tomorrow.", "There will be many visitors.", "Please wear traditional clothes.",
            "What does this name mean?", "My grandmother taught me this proverb.", "Tell me the story again.", "How do elders say this?", "This is how we greet at home.",
            "The ceremony has started.", "The food is being shared.", "Everyone is dancing.", "Please give this gift to them.", "Thank the host for me.",
            "We are visiting our neighbours.", "The children are learning the language.", "Teach me how to say it properly.", "I want to remember this tradition.", "We will return home tomorrow.",
            "The visitors have arrived.", "Let us welcome them.", "The elders are speaking.", "Listen carefully.", "We celebrated together."
        ),
        conversations = listOf(
            listOf("Welcome to our home.", "Thank you.", "Please come and sit down.", "Thank you for receiving me."),
            listOf("Where is your home town?", "My home town is far from here.", "Do you go often?", "Yes, especially for family events."),
            listOf("How should I greet the elders?", "Greet them first when you arrive.", "Is there anything else I should do?", "Just be respectful and listen."),
            listOf("What does this name mean?", "It has a family meaning.", "Who gave you the name?", "My grandfather."),
            listOf("Is the ceremony today?", "Yes, it starts in the afternoon.", "Are many people coming?", "Yes, relatives and neighbours."),
            listOf("Who taught you that proverb?", "My grandmother.", "Can you explain it to me?", "Yes, I will."),
            listOf("The visitors have arrived.", "Should we bring more chairs?", "Yes, and some water.", "I will get them."),
            listOf("Are you wearing traditional clothes?", "Yes.", "They look beautiful.", "Thank you."),
            listOf("Can you teach me this greeting?", "Yes, listen first.", "Should I repeat it?", "Yes, slowly."),
            listOf("When are you returning home?", "Tomorrow morning.", "Did you enjoy the celebration?", "Yes, very much." )
        ),
        stories = listOf(
            "We travelled home for a family ceremony. When we arrived, we greeted the elders, met relatives we had not seen for a long time, and ate together.",
            "My grandmother taught me an old family story and explained why certain greetings and names are important in our community.",
            "Visitors came from different towns for the celebration. There was music, dancing, food, speeches from the elders, and a lot of laughter."
        )
    )

    private val all: Map<ContentCategory, Content> = mapOf(
        ContentCategory.EVERYDAY to everyday,
        ContentCategory.FAMILY to family,
        ContentCategory.HOME to home,
        ContentCategory.MARKET_FOOD to marketFood,
        ContentCategory.SCHOOL_WORK to schoolWork,
        ContentCategory.TRAVEL to travel,
        ContentCategory.RELATIONSHIPS to relationships,
        ContentCategory.HEALTH to health,
        ContentCategory.CULTURE to culture
    )

    fun prompts(category: ContentCategory, type: BankType): List<BankPrompt> {
        val content = all.getValue(category)
        val raw: List<String> = when (type) {
            BankType.WORD -> content.words
            BankType.SENTENCE -> content.sentences
            BankType.CONVERSATION -> content.conversations.map { it.joinToString("\n") }
            BankType.STORY -> content.stories
        }
        return raw.mapIndexed { index, text ->
            BankPrompt("${category.key}:${type.name.lowercase()}:${index + 1}", text)
        }
    }

    fun trackKey(speaks: String, learning: String): String = listOf(speaks, learning)
        .map { it.trim().lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), "_").trim('_') }
        .filter { it.isNotBlank() }
        .sorted()
        .joinToString("__")
        .ifBlank { "default" }

    fun trackKey(profile: AppProfile): String = trackKey(profile.speaks, profile.learning)

    fun scopedEntries(profile: AppProfile, entries: List<LanguageEntry>): List<LanguageEntry> {
        val key = trackKey(profile)
        return entries.filter { entry ->
            entry.trackKey == key || (
                entry.trackKey.isBlank() &&
                    (entry.language.equals(profile.speaks, true) || entry.language.equals(profile.learning, true))
            )
        }
    }

    fun progress(entries: List<LanguageEntry>, profile: AppProfile): List<CategoryProgress> = progressScoped(
        scopedEntries(profile, entries),
        requiredLanguages = setOf(profile.speaks.trim().lowercase(), profile.learning.trim().lowercase()).filter { it.isNotBlank() }.toSet()
    )

    /** Legacy aggregate view retained only for older internal screens. */
    fun progress(entries: List<LanguageEntry>): List<CategoryProgress> = progressScoped(entries)

    private fun progressScoped(entries: List<LanguageEntry>, requiredLanguages: Set<String> = emptySet()): List<CategoryProgress> {
        var previousComplete = true
        return ContentCategory.entries.map { category ->
            fun count(type: BankType): Int {
                val grouped = entries.asSequence()
                    .filter { it.verified && it.type == type && it.category == category.key }
                    .groupBy { it.promptId.ifBlank { "legacy:${it.meaning.trim().lowercase()}" } }
                return grouped.count { (promptId, versions) ->
                    promptId.isNotBlank() && (requiredLanguages.size < 2 || requiredLanguages.all { required ->
                        versions.any { it.language.trim().lowercase() == required }
                    })
                }
            }
            val item = CategoryProgress(
                category = category,
                wordCount = count(BankType.WORD),
                sentenceCount = count(BankType.SENTENCE),
                conversationCount = count(BankType.CONVERSATION),
                storyCount = count(BankType.STORY),
                unlocked = previousComplete
            )
            previousComplete = previousComplete && item.complete
            item
        }
    }

    fun activeCategory(entries: List<LanguageEntry>, profile: AppProfile): ContentCategory =
        progress(entries, profile).firstOrNull { it.unlocked && !it.complete }?.category ?: ContentCategory.entries.last()

    /** Legacy aggregate view retained only for older internal screens. */
    fun activeCategory(entries: List<LanguageEntry>): ContentCategory =
        progress(entries).firstOrNull { it.unlocked && !it.complete }?.category ?: ContentCategory.entries.last()

    fun activeType(entries: List<LanguageEntry>, category: ContentCategory, profile: AppProfile): BankType {
        val p = progress(entries, profile).first { it.category == category }
        return when {
            p.wordCount < BankType.WORD.threshold -> BankType.WORD
            p.sentenceCount < BankType.SENTENCE.threshold -> BankType.SENTENCE
            p.conversationCount < BankType.CONVERSATION.threshold -> BankType.CONVERSATION
            else -> BankType.STORY
        }
    }

    fun activeType(entries: List<LanguageEntry>, category: ContentCategory): BankType {
        val p = progress(entries).first { it.category == category }
        return when {
            p.wordCount < BankType.WORD.threshold -> BankType.WORD
            p.sentenceCount < BankType.SENTENCE.threshold -> BankType.SENTENCE
            p.conversationCount < BankType.CONVERSATION.threshold -> BankType.CONVERSATION
            else -> BankType.STORY
        }
    }

    fun dailyBankTask(profile: AppProfile, entries: List<LanguageEntry>, maxItems: Int = 5): BankTask {
        val category = activeCategory(entries, profile)
        val type = activeType(entries, category, profile)
        val scoped = scopedEntries(profile, entries).filter {
            it.language.equals(profile.speaks, true) && it.category == category.key && it.type == type
        }
        val todayStart = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val completedBeforeToday = scoped.asSequence()
            .filter { it.createdAt < todayStart }
            .map { it.promptId }
            .filter { it.isNotBlank() }
            .distinct()
            .count()
        val assigned = prompts(category, type).drop(completedBeforeToday).take(maxItems)
        val completedIds = scoped.asSequence().map { it.promptId }.filter { it.isNotBlank() }.toSet()
        val remaining = assigned.filterNot { it.id in completedIds }
        val completedToday = assigned.size - remaining.size
        return BankTask(
            category = category,
            type = type,
            prompts = remaining,
            completedToday = completedToday,
            targetToday = assigned.size
        )
    }

    fun localConversation(category: ContentCategory, date: LocalDate = LocalDate.now()): DailyConversation {
        val content = all.getValue(category)
        val index = ((date.toEpochDay() % content.conversations.size).toInt() + content.conversations.size) % content.conversations.size
        val lines = content.conversations[index]
        val titles = mapOf(
            ContentCategory.EVERYDAY to "A normal check-in",
            ContentCategory.FAMILY to "Talking about family",
            ContentCategory.HOME to "At home",
            ContentCategory.MARKET_FOOD to "Market and food",
            ContentCategory.SCHOOL_WORK to "School and work",
            ContentCategory.TRAVEL to "Getting around",
            ContentCategory.RELATIONSHIPS to "Talking things through",
            ContentCategory.HEALTH to "Checking on someone",
            ContentCategory.CULTURE to "Home and community"
        )
        return DailyConversation(
            id = date.toString(),
            dateKey = date.toString(),
            category = category.key,
            title = titles.getValue(category),
            situation = "A short conversation you could realistically have today.",
            lines = lines,
            source = "local"
        )
    }
}
