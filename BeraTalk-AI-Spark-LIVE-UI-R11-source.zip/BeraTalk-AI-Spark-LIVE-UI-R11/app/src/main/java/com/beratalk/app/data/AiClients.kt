package com.beratalk.app.data

import android.content.Context
import com.beratalk.app.model.CoachChallenge
import com.beratalk.app.model.CoachNudge
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.DailyConversation
import com.beratalk.app.model.ContentCategory
import com.beratalk.app.model.BankType
import com.beratalk.app.model.LessonTask
import com.beratalk.app.model.LessonTaskType
import com.beratalk.app.model.Mission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val SYSTEM_RULES = """
You are BeraTalk's live language-learning coach. You organize practice between two real people.
CRITICAL LANGUAGE SAFETY RULES:
1. Never invent, translate, normalize, spell-correct, or pronounce minority-language words yourself.
2. Any target-language wording you reference must come only from the VERIFIED BANK supplied in the request.
3. When you choose existing language material, refer to it by entry_id. Do not rewrite its native wording.
4. If the verified bank is insufficient, create a task that asks the learner to get a real recording/phrase from their partner.
5. Focus on listening, recall, speaking, partner correction, real conversation, and gradual difficulty.
6. Keep coaching concise, warm, active, and specific. No generic motivational filler.
Return only valid JSON matching the keys requested by the user prompt.
"""

class AiClientRouter(context: Context) {
    private val settings = SecureAiSettings(context)

    fun isConfigured(): Boolean {
        val cfg = settings.snapshot()
        return cfg.geminiApiKey.isNotBlank() || cfg.openAiApiKey.isNotBlank()
    }

    suspend fun buildMission(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentWeaknesses: List<String>
    ): Mission? {
        val usable = verifiedEntries.filter { it.verified && it.language.equals(learningLanguage, true) }
        val prompt = missionPrompt(learningLanguage, usable, recentWeaknesses)
        val raw = requestJson(prompt) ?: return null
        return parseMission(raw, usable)
    }


    suspend fun buildDailyConversation(
        category: ContentCategory,
        learningLanguage: String,
        masteryStage: BankType = BankType.WORD,
        recentTitles: List<String> = emptyList()
    ): DailyConversation? {
        val dateKey = java.time.LocalDate.now().toString()
        val prompt = buildString {
            append("Plan today's shared real-world conversation lesson. Category: ")
            append(category.label)
            append(". The learner is studying ")
            append(learningLanguage)
            append(" but you MUST output the conversation structure in English only. ")
            append("Choose a normal human situation people genuinely encounter in daily life. ")
            append("Current mastery stage: ${masteryStage.name}. ")
            append(when (masteryStage) {
                BankType.WORD -> "Keep it very simple: 4 short lines using basic everyday meanings. "
                BankType.SENTENCE -> "Use 4-5 short natural lines with one clear exchange. "
                BankType.CONVERSATION -> "Use 5-6 connected lines with a realistic back-and-forth. "
                BankType.STORY -> "Use 5-6 natural lines that invite explanation, reaction, or a tiny story. "
            })
            append("The purpose is structured progression toward real conversational mastery. ")
            append("Avoid repeating these recent lesson titles: ")
            append(JSONArray(recentTitles.takeLast(7)).toString())
            append(". Return JSON only: {\"title\":string,\"situation\":string,\"lines\":[string,string,string,string]}. ")
            append("Do not translate the lines into the target language. Both real speakers will provide their own natural versions.")
        }
        val raw = requestJson(prompt) ?: return null
        return runCatching {
            val obj = extractObject(raw)
            val array = obj.optJSONArray("lines") ?: JSONArray()
            val lines = buildList {
                for (i in 0 until array.length()) {
                    val line = array.optString(i).trim()
                    if (line.isNotBlank()) add(line)
                }
            }.take(6)
            require(lines.size >= 4)
            DailyConversation(
                id = dateKey,
                dateKey = dateKey,
                category = category.key,
                title = obj.optString("title").ifBlank { category.label },
                situation = obj.optString("situation").ifBlank { "A short conversation you could realistically have today." },
                lines = lines,
                source = "ai"
            )
        }.getOrNull()
    }

    suspend fun buildConversationChallenge(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        recentMessageCount: Int
    ): CoachChallenge? {
        val usable = verifiedEntries.filter { it.verified && it.language.equals(learningLanguage, true) }
        val prompt = buildString {
            append("Create one live partner-conversation challenge for a beginner learning ")
            append(learningLanguage)
            append(". It should take 30-120 seconds and be immediately doable by voice. ")
            append("Recent voice-message count: $recentMessageCount. ")
            append("VERIFIED BANK: ")
            append(bankJson(usable, 30))
            append(". Return JSON only: {\"title\":string,\"instruction\":string,\"duration_seconds\":integer,\"entry_id\":string|null}. ")
            append("If entry_id is used it MUST be one supplied in VERIFIED BANK. Do not include invented target-language text in title or instruction.")
        }
        val raw = requestJson(prompt) ?: return null
        return parseChallenge(raw, usable)
    }

    suspend fun buildCoachNudge(
        learningLanguage: String,
        verifiedEntries: List<LanguageEntry>,
        completed: Int,
        total: Int,
        lastTaskTitle: String
    ): CoachNudge? {
        val usable = verifiedEntries.filter { it.verified && it.language.equals(learningLanguage, true) }
        val prompt = buildString {
            append("The learner just completed task: ")
            append(JSONObject.quote(lastTaskTitle))
            append(". Progress is $completed/$total in a live $learningLanguage lesson. ")
            append("VERIFIED BANK: ")
            append(bankJson(usable, 18))
            append(". Give one concise next-step coaching nudge. Return JSON only: {\"headline\":string,\"message\":string}. ")
            append("Do not invent target-language wording and do not claim pronunciation correctness.")
        }
        val raw = requestJson(prompt) ?: return null
        return runCatching {
            val obj = extractObject(raw)
            CoachNudge(
                headline = obj.optString("headline").ifBlank { "Keep the momentum" },
                message = obj.optString("message").ifBlank { "Move into the next task while the phrase is still fresh." },
                source = "ai"
            )
        }.getOrNull()
    }

    suspend fun test(provider: AiProvider): Result<String> {
        val cfg = settings.snapshot()
        return runCatching {
            val result = when (provider) {
                AiProvider.GEMINI -> {
                    require(cfg.geminiApiKey.isNotBlank()) { "Add your Gemini API key first." }
                    gemini(cfg.geminiApiKey, cfg.geminiModel, "Connection test", "Reply exactly with: BeraTalk connected", jsonMode = false)
                }
                AiProvider.OPENAI -> {
                    require(cfg.openAiApiKey.isNotBlank()) { "Add your OpenAI API key first." }
                    openAi(cfg.openAiApiKey, cfg.openAiModel, "Connection test", "Reply exactly with: BeraTalk connected")
                }
                AiProvider.AUTO -> error("Choose Gemini or OpenAI to test a connection.")
            }
            require(!result.isNullOrBlank()) { "The provider returned an empty response." }
            result.trim().take(180)
        }
    }

    private suspend fun requestJson(prompt: String): String? {
        val cfg = settings.snapshot()
        val order = when (cfg.preferredProvider) {
            AiProvider.GEMINI -> listOf(AiProvider.GEMINI)
            AiProvider.OPENAI -> listOf(AiProvider.OPENAI)
            AiProvider.AUTO -> listOf(AiProvider.GEMINI, AiProvider.OPENAI)
        }
        for (provider in order) {
            val response = runCatching {
                when (provider) {
                    AiProvider.GEMINI -> if (cfg.geminiApiKey.isNotBlank()) gemini(cfg.geminiApiKey, cfg.geminiModel, prompt) else null
                    AiProvider.OPENAI -> if (cfg.openAiApiKey.isNotBlank()) openAi(cfg.openAiApiKey, cfg.openAiModel, prompt) else null
                    AiProvider.AUTO -> null
                }
            }.getOrNull()
            if (!response.isNullOrBlank()) return response
        }
        return null
    }

    private fun missionPrompt(language: String, entries: List<LanguageEntry>, weaknesses: List<String>): String = buildString {
        append("Create one adaptive 8-15 minute speaking mission for a beginner learning ")
        append(language)
        append(" from their real partner. VERIFIED BANK: ")
        append(bankJson(entries, 36))
        append(". RECENT WEAKNESSES: ")
        append(JSONArray(weaknesses).toString())
        append(". Return JSON only with: title, subtitle, minutes, coach_message, tasks. ")
        append("tasks must contain 4-6 objects with keys type, entry_id, title, instruction, duration_seconds. ")
        append("Allowed type values: LISTEN, RECALL, SPEAK, CONVERSATION, ASK_PARTNER. ")
        append("LISTEN/RECALL/SPEAK must use a supplied entry_id. LISTEN should prefer entries with audio=true. ")
        append("CONVERSATION may reference an entry_id or null. ASK_PARTNER must be used when the bank lacks enough material. ")
        append("Do not put invented target-language words in title/instruction; the app will render native text directly from the selected verified entry.")
    }

    private fun bankJson(entries: List<LanguageEntry>, limit: Int): String {
        val bank = JSONArray()
        entries.take(limit).forEach { entry ->
            bank.put(JSONObject().apply {
                put("entry_id", entry.id)
                put("type", entry.type.label)
                put("native", entry.nativeText)
                put("meaning", entry.meaning)
                put("dialect", entry.dialect)
                put("notes", entry.notes)
                put("audio", !entry.audioPath.isNullOrBlank())
            })
        }
        return bank.toString()
    }

    private fun parseMission(raw: String, usable: List<LanguageEntry>): Mission? = runCatching {
        val obj = extractObject(raw)
        val byId = usable.associateBy { it.id }
        val tasksJson = obj.optJSONArray("tasks") ?: JSONArray()
        val tasks = buildList {
            for (i in 0 until tasksJson.length()) {
                val item = tasksJson.optJSONObject(i) ?: continue
                val type = runCatching { LessonTaskType.valueOf(item.optString("type").uppercase()) }.getOrNull() ?: continue
                val entryId = item.optString("entry_id").takeIf { it.isNotBlank() && it != "null" }
                val requiresEntry = type == LessonTaskType.LISTEN || type == LessonTaskType.RECALL || type == LessonTaskType.SPEAK
                if (requiresEntry && (entryId == null || byId[entryId] == null)) continue
                val safeEntryId = entryId?.takeIf { byId.containsKey(it) }
                add(
                    LessonTask(
                        id = "ai-${System.currentTimeMillis()}-$i",
                        type = type,
                        title = item.optString("title").ifBlank { fallbackTaskTitle(type) },
                        instruction = item.optString("instruction").ifBlank { fallbackTaskInstruction(type) },
                        entryId = safeEntryId,
                        durationSeconds = item.optInt("duration_seconds", defaultDuration(type)).coerceIn(0, 300)
                    )
                )
            }
        }
        require(tasks.size >= 3)
        Mission(
            id = "ai-${System.currentTimeMillis()}",
            title = obj.optString("title").ifBlank { "Today's real conversation" },
            subtitle = obj.optString("subtitle").ifBlank { "Listen, remember, speak, then use it with your partner." },
            minutes = obj.optInt("minutes", 12).coerceIn(5, 25),
            progress = 0f,
            steps = tasks.map { it.title },
            tasks = tasks,
            coachMessage = obj.optString("coach_message").ifBlank { "I built this from the language your partner has actually verified." },
            source = "ai"
        )
    }.getOrNull()

    private fun parseChallenge(raw: String, usable: List<LanguageEntry>): CoachChallenge? = runCatching {
        val obj = extractObject(raw)
        val requested = obj.optString("entry_id").takeIf { it.isNotBlank() && it != "null" }
        val safeId = requested?.takeIf { id -> usable.any { it.id == id } }
        CoachChallenge(
            title = obj.optString("title").ifBlank { "Keep the conversation moving" },
            instruction = obj.optString("instruction").ifBlank { "Use one verified phrase and respond by voice." },
            durationSeconds = obj.optInt("duration_seconds", 60).coerceIn(30, 120),
            entryId = safeId,
            source = "ai"
        )
    }.getOrNull()

    private fun extractObject(raw: String): JSONObject {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        require(start >= 0 && end > start)
        return JSONObject(raw.substring(start, end + 1))
    }

    private fun fallbackTaskTitle(type: LessonTaskType): String = when (type) {
        LessonTaskType.LISTEN -> "Listen closely"
        LessonTaskType.RECALL -> "Recall it without help"
        LessonTaskType.SPEAK -> "Say it yourself"
        LessonTaskType.CONVERSATION -> "Use it in conversation"
        LessonTaskType.ASK_PARTNER -> "Get a real phrase from your partner"
    }

    private fun fallbackTaskInstruction(type: LessonTaskType): String = when (type) {
        LessonTaskType.LISTEN -> "Play the real recording twice before moving on."
        LessonTaskType.RECALL -> "Try to remember the meaning before revealing it."
        LessonTaskType.SPEAK -> "Say the verified phrase aloud, then compare with the real recording."
        LessonTaskType.CONVERSATION -> "Use the material naturally in a voice exchange with your partner."
        LessonTaskType.ASK_PARTNER -> "Ask your partner to teach and record the missing phrase."
    }

    private fun defaultDuration(type: LessonTaskType): Int = when (type) {
        LessonTaskType.LISTEN -> 45
        LessonTaskType.RECALL -> 45
        LessonTaskType.SPEAK -> 60
        LessonTaskType.CONVERSATION -> 180
        LessonTaskType.ASK_PARTNER -> 0
    }

    private suspend fun gemini(
        apiKey: String,
        model: String,
        prompt: String,
        system: String = SYSTEM_RULES,
        jsonMode: Boolean = true
    ): String? = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/${urlSegment(model)}:generateContent"
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system.trimIndent()))))
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.3)
                put("maxOutputTokens", 1100)
                if (jsonMode) put("responseMimeType", "application/json")
            })
        }
        val json = postJson(endpoint, body, mapOf("x-goog-api-key" to apiKey))
        val candidates = json.optJSONArray("candidates") ?: return@withContext null
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return@withContext null
        buildString {
            for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
        }.takeIf { it.isNotBlank() }
    }

    private suspend fun openAi(apiKey: String, model: String, prompt: String, system: String = SYSTEM_RULES): String? = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", model)
            put("instructions", system.trimIndent())
            put("input", prompt)
            put("max_output_tokens", 1100)
        }
        val json = postJson(
            "https://api.openai.com/v1/responses",
            body,
            mapOf("Authorization" to "Bearer $apiKey")
        )
        json.optString("output_text").takeIf { it.isNotBlank() } ?: extractOpenAiText(json)
    }

    private fun extractOpenAiText(json: JSONObject): String? {
        val output = json.optJSONArray("output") ?: return null
        val text = StringBuilder()
        for (i in 0 until output.length()) {
            val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val item = content.optJSONObject(j) ?: continue
                val value = item.optString("text")
                if (value.isNotBlank()) text.append(value)
            }
        }
        return text.toString().takeIf { it.isNotBlank() }
    }

    private fun postJson(endpoint: String, body: JSONObject, headers: Map<String, String>): JSONObject {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 35_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            headers.forEach { (key, value) -> setRequestProperty(key, value) }
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                error(message?.takeIf { it.isNotBlank() } ?: "HTTP $code from AI provider")
            }
            return JSONObject(response)
        } finally {
            connection.disconnect()
        }
    }

    private fun urlSegment(model: String): String = java.net.URLEncoder.encode(model.trim(), "UTF-8")
}
