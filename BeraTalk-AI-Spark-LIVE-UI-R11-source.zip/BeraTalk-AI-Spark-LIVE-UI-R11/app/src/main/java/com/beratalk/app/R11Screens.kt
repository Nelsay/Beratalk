package com.beratalk.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.beratalk.app.audio.VoicePlayer
import com.beratalk.app.audio.VoiceRecorder
import com.beratalk.app.data.AiClientRouter
import com.beratalk.app.data.AiProvider
import com.beratalk.app.data.CurriculumCatalog
import com.beratalk.app.data.FirebaseGateway
import com.beratalk.app.data.SecureAiSettings
import com.beratalk.app.model.AppProfile
import com.beratalk.app.model.BankPrompt
import com.beratalk.app.model.BankTask
import com.beratalk.app.model.BankType
import com.beratalk.app.model.ChatMessage
import com.beratalk.app.model.ChatMessageKind
import com.beratalk.app.model.ContentCategory
import com.beratalk.app.model.DailyConversation
import com.beratalk.app.model.LanguageEntry
import com.beratalk.app.model.LearningSession
import com.beratalk.app.notifications.BeraNotifications
import com.beratalk.app.notifications.NotificationPreferences
import com.beratalk.app.ui.theme.ActionColor
import com.beratalk.app.ui.theme.BeraCoral
import com.beratalk.app.ui.theme.BeraOrange
import com.beratalk.app.ui.theme.BeraTalkTheme
import com.beratalk.app.ui.theme.BeraTeal
import com.beratalk.app.ui.theme.BeraTealDeep
import com.beratalk.app.ui.theme.BeraUiTheme
import com.beratalk.app.ui.theme.Border
import com.beratalk.app.ui.theme.Canvas
import com.beratalk.app.ui.theme.CoralTint
import com.beratalk.app.ui.theme.Ink
import com.beratalk.app.ui.theme.IsBeraDark
import com.beratalk.app.ui.theme.Muted
import com.beratalk.app.ui.theme.OnActionColor
import com.beratalk.app.ui.theme.OrangeTint
import com.beratalk.app.ui.theme.Soft
import com.beratalk.app.ui.theme.SurfaceTone
import com.beratalk.app.ui.theme.TealTint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.net.URL
import java.time.LocalDate
import kotlin.math.roundToInt

data class BankDraft(
    val type: BankType,
    val nativeText: String = "",
    val meaning: String = "",
    val audioPath: String? = null
)

@Composable
fun R11BottomBar(selected: Tab, onSelected: (Tab) -> Unit) {
    val tabs = listOf(Tab.HOME, Tab.CHAT, Tab.LEARN, Tab.LIBRARY)
    Surface(color = SurfaceTone, shadowElevation = 12.dp, tonalElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                val active = selected == tab
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable { onSelected(tab) }.padding(vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(if (active) 40.dp else 34.dp).clip(CircleShape).background(if (active) BeraTeal else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(tab.icon, tab.label, tint = if (active) Color.White else Muted, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(tab.label, color = if (active) BeraTealDeep else Muted, style = MaterialTheme.typography.labelMedium, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun R11ProfileAvatar(photoUrl: String?, name: String, size: Dp = 43.dp, onClick: (() -> Unit)? = null) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, photoUrl) {
        value = if (photoUrl.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching { URL(photoUrl).openStream().use(BitmapFactory::decodeStream) }.getOrNull()
        }
    }
    var avatarModifier = Modifier.size(size).clip(CircleShape).background(Soft).border(1.dp, Border, CircleShape)
    if (onClick != null) avatarModifier = avatarModifier.clickable(onClick = onClick)
    Box(
        avatarModifier,
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(name.trim().firstOrNull()?.uppercase() ?: "B", color = Ink, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun R11HomeScreen(
    profile: AppProfile,
    daily: DailyConversation?,
    entries: List<LanguageEntry>,
    messages: List<ChatMessage>,
    photoUrl: String?,
    onConversation: () -> Unit,
    onBank: () -> Unit,
    onGame: () -> Unit,
    onProfile: () -> Unit
) {
    val progress = CurriculumCatalog.progress(entries, profile)
    val active = CurriculumCatalog.activeCategory(entries, profile)
    val activeProgress = progress.first { it.category == active }
    val bankTask = CurriculumCatalog.dailyBankTask(profile, entries)
    val today = LocalDate.now()
    val startOfDay = today.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
    val todayMessages = messages.count { it.createdAt >= startOfDay }
    val scoped = CurriculumCatalog.scopedEntries(profile, entries)
    val todayEntries = scoped.count { it.createdAt >= startOfDay }
    val reviewReady = scoped.count { it.verified && it.type == BankType.WORD && it.language.equals(profile.learning, true) } >= 4
    val todayPractice = daily?.lines?.indices?.count { index ->
        val id = "daily:${daily.dateKey}:$index"
        messages.any { it.senderId == "me" && it.dailyLineId == id }
    } ?: 0

    LazyColumn(
        Modifier.fillMaxSize().background(Canvas).statusBarsPadding(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(currentGreetingR11(), color = Muted, style = MaterialTheme.typography.bodyMedium)
                    Text(profile.displayName.ifBlank { "BeraTalk" }, color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                }
                R11ProfileAvatar(photoUrl, profile.displayName, onClick = onProfile)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().height(222.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    modifier = Modifier.weight(1.18f).fillMaxSize().clickable(onClick = onConversation),
                    color = if (IsBeraDark) Color(0xFF20231A) else TealTint,
                    shape = RoundedCornerShape(27.dp),
                    shadowElevation = 8.dp
                ) {
                    Column(Modifier.padding(17.dp)) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(BeraTeal.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AutoAwesome, null, tint = BeraTealDeep)
                        }
                        Spacer(Modifier.weight(1f))
                        Text(daily?.title ?: "Today's conversation", color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, maxLines = 3)
                        Spacer(Modifier.height(6.dp))
                        Text(daily?.situation ?: "Building today's lesson…", color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(12.dp))
                        R11BlackPill(if (daily == null) "Preparing…" else "Start") { if (daily != null) onConversation() }
                    }
                }
                Column(Modifier.weight(.9f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        Modifier.weight(1f).fillMaxWidth().clickable(onClick = onBank),
                        color = if (IsBeraDark) Color(0xFF27221D) else OrangeTint,
                        shape = RoundedCornerShape(24.dp),
                        shadowElevation = 6.dp
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Icon(Icons.Default.LibraryBooks, null, tint = BeraOrange, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.weight(1f))
                            Text(if (bankTask.targetToday == 0) "Partner turn" else "Build ${bankTask.type.label.lowercase()}", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(if (bankTask.targetToday == 0) "Waiting for their ${profile.learning}" else "${bankTask.completedToday}/${bankTask.targetToday} today", color = Muted, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    Surface(
                        Modifier.weight(1f).fillMaxWidth().clickable(enabled = reviewReady, onClick = onGame),
                        color = if (IsBeraDark) Color(0xFF222127) else CoralTint,
                        shape = RoundedCornerShape(24.dp),
                        shadowElevation = 6.dp
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Icon(Icons.Default.Timer, null, tint = BeraCoral, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.weight(1f))
                            Text("Quick review", color = if (reviewReady) Ink else Muted, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(if (reviewReady) "5 questions" else "Build 4 words first", color = Muted, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(active.label, Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Text("${(activeProgress.fraction * 100).roundToInt()}%", color = Muted, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { activeProgress.fraction },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = BeraTeal,
                    trackColor = Soft
                )
                Spacer(Modifier.height(9.dp))
                Text(
                    "${activeProgress.wordCount}/50 words  ·  ${activeProgress.sentenceCount}/25 sentences  ·  ${activeProgress.conversationCount}/10 conversations  ·  ${activeProgress.storyCount}/3 stories",
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
        item {
            Text("Today", color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(9.dp))
            R11ActivityRow(Icons.Default.ChatBubble, "$todayMessages conversation ${if (todayMessages == 1) "message" else "messages"}", onConversation)
            R11ActivityRow(Icons.Default.LibraryBooks, "$todayEntries bank ${if (todayEntries == 1) "entry" else "entries"}", onBank)
            R11ActivityRow(Icons.Default.CheckCircle, "$todayPractice conversation lines contributed", onConversation)
        }
    }
}

@Composable
private fun R11ActivityRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 11.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(35.dp).clip(CircleShape).background(Soft), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Ink, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(text, Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Icon(Icons.Default.ArrowForward, null, tint = Muted, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun R11BlackPill(text: String, onClick: () -> Unit) {
    Surface(color = ActionColor, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = OnActionColor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
    }
}

@Composable
fun R11LearnScreen(
    profile: AppProfile,
    daily: DailyConversation?,
    messages: List<ChatMessage>,
    photoUrl: String?,
    resolveAudio: suspend (String) -> String?,
    onChat: () -> Unit,
    onProfile: () -> Unit
) {
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    var lineIndex by remember(daily?.id) { mutableIntStateOf(0) }
    var revealSpelling by remember(daily?.id, lineIndex) { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var playingSlow by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    if (daily == null) {
        Box(Modifier.fillMaxSize().background(Canvas), contentAlignment = Alignment.Center) {
            Text("Preparing today…", color = Muted)
        }
        return
    }

    val safeIndex = lineIndex.coerceIn(0, daily.lines.lastIndex)
    val english = daily.lines[safeIndex]
    val lineId = "daily:${daily.dateKey}:$safeIndex"
    val partnerMessages = messages.filter { it.senderId != "me" && it.dailyLineId == lineId }
    val ownMessages = messages.filter { it.senderId == "me" && it.dailyLineId == lineId }
    val targetText = partnerMessages.lastOrNull { it.kind == ChatMessageKind.TEXT && it.text.isNotBlank() }
    val targetVoice = partnerMessages.lastOrNull { it.kind == ChatMessageKind.VOICE && !it.audioPath.isNullOrBlank() }
    val availableLines = daily.lines.indices.count { index ->
        val id = "daily:${daily.dateKey}:$index"
        messages.any { it.senderId != "me" && it.dailyLineId == id }
    }

    Column(
        Modifier.fillMaxSize().background(Canvas).statusBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(ContentCategory.fromKey(daily.category).label, color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                Text("Learn", color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            }
            R11ProfileAvatar(photoUrl, profile.displayName, onClick = onProfile)
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${safeIndex + 1}/${daily.lines.size}", color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("$availableLines ready", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (safeIndex + 1).toFloat() / daily.lines.size.coerceAtLeast(1) },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = BeraTeal,
                trackColor = Soft
            )
        }

        Spacer(Modifier.height(18.dp))

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            color = SurfaceTone,
            shape = RoundedCornerShape(28.dp),
            shadowElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, Border)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(english, color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(20.dp))

                if (targetText == null && targetVoice == null) {
                    Surface(color = Soft, shape = RoundedCornerShape(18.dp)) {
                        Text("Waiting for ${profile.partnerName}", Modifier.fillMaxWidth().padding(16.dp), color = Muted, fontWeight = FontWeight.Medium)
                    }
                } else {
                    Text(profile.learning, color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    if (targetText != null) {
                        if (revealSpelling) {
                            Text(targetText.text, color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        } else {
                            Surface(color = Soft, shape = RoundedCornerShape(15.dp), modifier = Modifier.clickable { revealSpelling = true }) {
                                Text("Reveal spelling", Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Ink, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    if (targetVoice != null) {
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Button(
                                onClick = {
                                    targetVoice.audioPath?.let { path -> scope.launch {
                                        val resolved = resolveAudio(path) ?: return@launch
                                        playing = true; playingSlow = false
                                        player.play(resolved, 1f) { playing = false }
                                    } }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(if (playing && !playingSlow) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Listen", fontWeight = FontWeight.Black)
                            }
                            OutlinedButton(
                                onClick = {
                                    targetVoice.audioPath?.let { path -> scope.launch {
                                        val resolved = resolveAudio(path) ?: return@launch
                                        playing = true; playingSlow = true
                                        player.play(resolved, .75f) { playing = false }
                                    } }
                                },
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text("Slower", color = Ink, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = onChat,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Mic, null)
                    Spacer(Modifier.width(7.dp))
                    Text(if (ownMessages.isEmpty()) "Practice in Chat" else "Use it again", fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp).navigationBarsPadding(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { if (safeIndex > 0) { lineIndex = safeIndex - 1; revealSpelling = false } },
                enabled = safeIndex > 0,
                modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(17.dp)
            ) { Text("Back", color = if (safeIndex > 0) Ink else Muted, fontWeight = FontWeight.Bold) }
            Button(
                onClick = { if (safeIndex < daily.lines.lastIndex) { lineIndex = safeIndex + 1; revealSpelling = false } else lineIndex = 0 },
                modifier = Modifier.weight(1f).height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor),
                shape = RoundedCornerShape(17.dp)
            ) { Text(if (safeIndex == daily.lines.lastIndex) "Again" else "Next", fontWeight = FontWeight.Black) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun R11ChatScreen(
    profile: AppProfile,
    daily: DailyConversation?,
    messages: List<ChatMessage>,
    entries: List<LanguageEntry>,
    photoUrl: String?,
    resolveAudio: suspend (String) -> String?,
    onBack: () -> Unit,
    onProfile: () -> Unit,
    onSendText: (String, String?) -> Unit,
    onSendVoice: (java.io.File, Long, String?, String?) -> Unit,
    onDelete: (Set<String>) -> Unit,
    onBankSelection: (BankDraft) -> Unit
) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    var draft by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var correctionFor by remember { mutableStateOf<String?>(null) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var showToday by remember { mutableStateOf(false) }
    var activeDailyLineId by remember(daily?.id) { mutableStateOf<String?>(null) }
    var activeDailyEnglish by remember(daily?.id) { mutableStateOf<String?>(null) }
    var playingId by remember { mutableStateOf<String?>(null) }
    var playbackProgress by remember { mutableStateOf(0f) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { recorder.start(); recording = true }
    }
    DisposableEffect(Unit) { onDispose { player.stop(); if (recording) recorder.cancel() } }
    LaunchedEffect(playingId) {
        while (playingId != null) {
            playbackProgress = player.progress()
            if (!player.isPlaying() && playbackProgress > 0f) playingId = null
            delay(80)
        }
    }

    Column(Modifier.fillMaxSize().background(Canvas).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selected.isNotEmpty()) {
                IconButton(onClick = { selected.clear() }) { Icon(Icons.Default.Close, "Cancel", tint = Ink) }
                Text(selected.size.toString(), Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                IconButton(onClick = {
                    val chosen = messages.filter { it.id in selected }
                    val text = chosen.mapNotNull { it.text.takeIf(String::isNotBlank) }.joinToString("\n")
                    val kind = when {
                        chosen.size == 1 && text.trim().split(Regex("\\s+")).size <= 3 -> BankType.WORD
                        chosen.size == 1 -> BankType.SENTENCE
                        chosen.size <= 6 -> BankType.CONVERSATION
                        else -> BankType.STORY
                    }
                    onBankSelection(BankDraft(kind, nativeText = text, audioPath = chosen.firstOrNull { !it.audioPath.isNullOrBlank() }?.audioPath))
                    selected.clear()
                }) { Icon(Icons.Default.LibraryBooks, "Add to bank", tint = Ink) }
                IconButton(onClick = { onDelete(selected.toSet()); selected.clear() }) { Icon(Icons.Default.Delete, "Delete", tint = BeraCoral) }
            } else {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(profile.partnerName, color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text("${profile.speaks} ↔ ${profile.learning}", color = Muted, style = MaterialTheme.typography.labelMedium)
                }
                R11ProfileAvatar(photoUrl, profile.displayName, size = 38.dp, onClick = onProfile)
            }
        }
        if (selected.isEmpty()) {
            Surface(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp).fillMaxWidth().clickable { showToday = true },
                color = Soft,
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = BeraTealDeep, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(9.dp))
                    Text("What are we doing today?", Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Black)
                    Text(daily?.title ?: "…", color = Muted, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.GraphicEq, null, tint = Muted, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(9.dp))
                        Text("Start with a voice note", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
            items(messages, key = { it.id }) { message ->
                val mine = message.senderId == "me"
                val isSelected = message.id in selected
                R11ChatBubble(
                    message = message,
                    mine = mine,
                    selected = isSelected,
                    expanded = expandedId == message.id && selected.isEmpty(),
                    playing = playingId == message.id,
                    progress = if (playingId == message.id) playbackProgress else 0f,
                    onTap = {
                        if (selected.isNotEmpty()) {
                            if (isSelected) selected.remove(message.id) else selected.add(message.id)
                        } else expandedId = if (expandedId == message.id) null else message.id
                    },
                    onLongPress = { if (!isSelected) selected.add(message.id) },
                    onPlay = {
                        message.audioPath?.let { path -> scope.launch {
                            val resolved = resolveAudio(path) ?: return@launch
                            playingId = message.id; playbackProgress = 0f
                            player.play(resolved, 1f) { playingId = null }
                        } }
                    },
                    onSlower = {
                        message.audioPath?.let { path -> scope.launch {
                            val resolved = resolveAudio(path) ?: return@launch
                            playingId = message.id; playbackProgress = 0f
                            player.play(resolved, .75f) { playingId = null }
                        } }
                    },
                    onMeaning = { draft = "What does this mean?" },
                    onCorrect = if (!mine) ({ correctionFor = message.id }) else null
                )
            }
        }
        if (correctionFor != null) {
            Row(Modifier.fillMaxWidth().background(Soft).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Send a correction", Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                TextButton(onClick = { correctionFor = null }) { Text("Cancel", color = Ink) }
            }
        }
        if (activeDailyLineId != null && selected.isEmpty()) {
            Surface(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth(),
                color = Soft,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = BeraTealDeep, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(activeDailyEnglish.orEmpty(), Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = { activeDailyLineId = null; activeDailyEnglish = null }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Close, "Clear", tint = Muted, modifier = Modifier.size(17.dp)) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (recording) "Recording…" else "Message") },
                shape = RoundedCornerShape(24.dp),
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(54.dp).clip(CircleShape).background(if (recording) BeraCoral else ActionColor).clickable {
                    if (draft.isNotBlank() && !recording) {
                        onSendText(draft.trim(), activeDailyLineId); draft = ""
                    } else if (recording) {
                        val (file, duration) = recorder.stop(); recording = false
                        file?.let { onSendVoice(it, duration, correctionFor, activeDailyLineId) }
                        correctionFor = null
                    } else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        recorder.start(); recording = true
                    } else permission.launch(Manifest.permission.RECORD_AUDIO)
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    when { draft.isNotBlank() && !recording -> Icons.Default.Send; recording -> Icons.Default.Stop; else -> Icons.Default.Mic },
                    null,
                    tint = if (recording) Color.White else OnActionColor
                )
            }
        }
    }

    if (showToday && daily != null) {
        ModalBottomSheet(onDismissRequest = { showToday = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = SurfaceTone) {
            Column(Modifier.padding(20.dp).navigationBarsPadding()) {
                Text(daily.title, color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(4.dp))
                Text(daily.situation, color = Muted)
                Spacer(Modifier.height(15.dp))
                daily.lines.forEachIndexed { index, line ->
                    val lineId = "daily:${daily.dateKey}:$index"
                    val ownCount = messages.count { it.senderId == "me" && it.dailyLineId == lineId }
                    val partnerCount = messages.count { it.senderId != "me" && it.dailyLineId == lineId }
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable {
                            activeDailyLineId = lineId
                            activeDailyEnglish = line
                            showToday = false
                        },
                        color = Soft,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(28.dp).clip(CircleShape).background(SurfaceTone), contentAlignment = Alignment.Center) {
                                Text("${index + 1}", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(line, color = Ink, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                if (ownCount + partnerCount > 0) {
                                    Text("You $ownCount  ·  ${profile.partnerName} $partnerCount", color = Muted, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Icon(Icons.Default.ArrowForward, null, tint = Muted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun R11ChatBubble(
    message: ChatMessage,
    mine: Boolean,
    selected: Boolean,
    expanded: Boolean,
    playing: Boolean,
    progress: Float,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onPlay: () -> Unit,
    onSlower: () -> Unit,
    onMeaning: () -> Unit,
    onCorrect: (() -> Unit)?
) {
    val mineBg = if (IsBeraDark) Color(0xFF312D2D) else Color.Black
    val otherBg = Soft
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Surface(
            modifier = Modifier.widthIn(max = 286.dp).combinedClickable(onClick = onTap, onLongClick = onLongPress),
            color = if (selected) BeraTeal.copy(alpha = .22f) else if (mine) mineBg else otherBg,
            shape = if (mine) RoundedCornerShape(22.dp, 6.dp, 22.dp, 22.dp) else RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp),
            border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, BeraTeal) else null
        ) {
            when (message.kind) {
                ChatMessageKind.TEXT -> Text(
                    message.text,
                    Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    color = if (mine) Color.White else Ink,
                    style = MaterialTheme.typography.bodyLarge
                )
                ChatMessageKind.VOICE -> Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(if (mine) Color.White.copy(.12f) else SurfaceTone).clickable(onClick = onPlay), contentAlignment = Alignment.Center) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = if (mine) Color.White else Ink)
                    }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.width(150.dp)) {
                        LinearProgressIndicator(progress = { if (playing) progress else 0f }, Modifier.fillMaxWidth().height(4.dp).clip(CircleShape), color = BeraTeal, trackColor = if (mine) Color.White.copy(.16f) else Border)
                        Spacer(Modifier.height(6.dp))
                        Text(formatSecondsR11((message.durationMs / 1000).toInt()), color = if (mine) Color.White.copy(.7f) else Muted, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        AnimatedVisibility(visible = expanded && !selected, enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (message.kind == ChatMessageKind.VOICE) R11ActionChip("Slower", onSlower)
                R11ActionChip("Meaning", onMeaning)
                if (onCorrect != null) R11ActionChip("Correct", onCorrect)
            }
        }
    }
}

@Composable
private fun R11ActionChip(text: String, onClick: () -> Unit) {
    Surface(color = ActionColor, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = OnActionColor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun R11LibraryScreen(
    profile: AppProfile,
    entries: List<LanguageEntry>,
    initialDraft: BankDraft?,
    resolveAudio: suspend (String) -> String?,
    onSave: (LanguageEntry) -> Unit,
    onUpdate: (LanguageEntry) -> Unit,
    onDelete: (LanguageEntry) -> Unit,
    onDraftConsumed: () -> Unit
) {
    val progress = CurriculumCatalog.progress(entries, profile)
    val activeCategory = CurriculumCatalog.activeCategory(entries, profile)
    val activeType = CurriculumCatalog.activeType(entries, activeCategory, profile)
    var category by remember(activeCategory) { mutableStateOf(activeCategory) }
    var type by remember(activeType) { mutableStateOf(activeType) }
    var search by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<LanguageEntry?>(null) }
    var chatDraft by remember { mutableStateOf<BankDraft?>(null) }
    LaunchedEffect(initialDraft) {
        if (initialDraft != null) { chatDraft = initialDraft; onDraftConsumed() }
    }
    val categoryProgress = progress.first { it.category == category }
    val availableTypes = BankType.entries.filter { candidate ->
        when (candidate) {
            BankType.WORD -> true
            BankType.SENTENCE -> categoryProgress.wordCount >= BankType.WORD.threshold
            BankType.CONVERSATION -> categoryProgress.sentenceCount >= BankType.SENTENCE.threshold
            BankType.STORY -> categoryProgress.conversationCount >= BankType.CONVERSATION.threshold
        }
    }
    if (type !in availableTypes) type = availableTypes.last()
    val task = CurriculumCatalog.dailyBankTask(profile, entries)
    val filtered = CurriculumCatalog.scopedEntries(profile, entries).filter {
        it.category == category.key && it.type == type &&
            (search.isBlank() || it.nativeText.contains(search, true) || it.meaning.contains(search, true))
    }

    LazyColumn(
        Modifier.fillMaxSize().background(Canvas).statusBarsPadding(),
        contentPadding = PaddingValues(18.dp, 18.dp, 18.dp, 34.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Library", color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(progress) { item ->
                    val active = category == item.category
                    Surface(
                        color = if (active) ActionColor else SurfaceTone,
                        shape = RoundedCornerShape(999.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) ActionColor else Border),
                        modifier = Modifier.clickable(enabled = item.unlocked) { category = item.category; type = CurriculumCatalog.activeType(entries, item.category, profile) }
                    ) {
                        Row(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (!item.unlocked) { Icon(Icons.Default.Lock, null, tint = Muted, modifier = Modifier.size(13.dp)); Spacer(Modifier.width(4.dp)) }
                            Text(item.category.label, color = if (active) OnActionColor else if (item.unlocked) Ink else Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (category == activeCategory && task.prompts.isNotEmpty()) {
            item {
                R11DailyBankCard(profile, task, onSave)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(category.label, Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text("${(categoryProgress.fraction * 100).roundToInt()}%", color = Muted, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            LinearProgressIndicator(progress = { categoryProgress.fraction }, Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = BeraTeal, trackColor = Soft)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(BankType.entries) { candidate ->
                    val unlocked = candidate in availableTypes
                    val active = type == candidate
                    Surface(
                        color = if (active) ActionColor else SurfaceTone,
                        shape = RoundedCornerShape(999.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) ActionColor else Border),
                        modifier = Modifier.clickable(enabled = unlocked) { type = candidate }
                    ) {
                        Row(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (!unlocked) { Icon(Icons.Default.Lock, null, tint = Muted, modifier = Modifier.size(13.dp)); Spacer(Modifier.width(4.dp)) }
                            Text(candidate.label, color = if (active) OnActionColor else if (unlocked) Ink else Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search") }, singleLine = true, shape = RoundedCornerShape(18.dp))
        }
        if (filtered.isEmpty()) {
            item { Text("No ${type.label.lowercase()} here yet.", Modifier.padding(vertical = 24.dp), color = Muted) }
        }
        items(filtered, key = { it.id }) { entry ->
            R11EntryRow(entry, resolveAudio, onEdit = { editing = entry }, onDelete = { onDelete(entry) })
        }
        val currentIndex = ContentCategory.entries.indexOf(category)
        if (currentIndex < ContentCategory.entries.lastIndex && !progress[currentIndex + 1].unlocked) {
            item {
                Surface(color = Soft, shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = Muted)
                        Spacer(Modifier.width(9.dp))
                        Text("Finish ${category.label} to unlock ${ContentCategory.entries[currentIndex + 1].label}.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    editing?.let { entry -> R11EditEntrySheet(entry, profile, onDismiss = { editing = null }, onSave = { onUpdate(it); editing = null }) }
    chatDraft?.let { draft -> R11ChatBankSheet(draft, profile, activeCategory, onDismiss = { chatDraft = null }, onSave = { onSave(it); chatDraft = null }) }
}

@Composable
private fun R11DailyBankCard(profile: AppProfile, task: BankTask, onSave: (LanguageEntry) -> Unit) {
    var index by remember(task.category, task.type, task.prompts) { mutableIntStateOf(0) }
    if (task.prompts.isEmpty()) return
    val prompt = task.prompts[index.coerceIn(0, task.prompts.lastIndex)]
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    var text by remember(prompt.id) { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var audioPath by remember(prompt.id) { mutableStateOf<String?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) { recorder.start(); recording = true } }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel() } }

    Surface(color = if (IsBeraDark) Color(0xFF20231A) else TealTint, shape = RoundedCornerShape(26.dp), shadowElevation = 8.dp) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${task.category.label} · ${task.type.label}", Modifier.weight(1f), color = BeraTealDeep, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black)
                Text("${index + 1}/${task.prompts.size}", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(10.dp))
            Text(prompt.english, color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(13.dp))
            OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Your ${profile.speaks} version") }, minLines = if (task.type.ordinal >= BankType.CONVERSATION.ordinal) 3 else 1, maxLines = 7, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = {
                    if (recording) { val (file, _) = recorder.stop(); recording = false; audioPath = file?.absolutePath }
                    else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true }
                    else permission.launch(Manifest.permission.RECORD_AUDIO)
                }, shape = RoundedCornerShape(15.dp)) {
                    Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) BeraCoral else Ink)
                    Spacer(Modifier.width(5.dp)); Text(if (audioPath != null) "Recorded" else if (recording) "Stop" else "Voice", color = Ink)
                }
                Button(
                    onClick = {
                        onSave(LanguageEntry(type = task.type, language = profile.speaks, nativeText = text.trim(), meaning = prompt.english, dialect = profile.dialect, category = task.category.key, promptId = prompt.id, trackKey = CurriculumCatalog.trackKey(profile), audioPath = audioPath, verified = true))
                        text = ""; audioPath = null
                        if (index < task.prompts.lastIndex) index++
                    },
                    enabled = text.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor),
                    shape = RoundedCornerShape(15.dp)
                ) { Text(if (index == task.prompts.lastIndex) "Done" else "Save & next", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
private fun R11EntryRow(entry: LanguageEntry, resolveAudio: suspend (String) -> String?, onEdit: () -> Unit, onDelete: () -> Unit) {
    val player = remember { VoicePlayer() }
    val scope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { player.stop() } }
    Surface(color = SurfaceTone, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(entry.nativeText, color = Ink, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(entry.meaning, color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (!entry.audioPath.isNullOrBlank()) IconButton(onClick = { scope.launch { resolveAudio(entry.audioPath!!)?.let { player.play(it) } } }) { Icon(Icons.Default.PlayArrow, "Play", tint = Ink) }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit", tint = Muted) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete", tint = BeraCoral) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun R11EditEntrySheet(entry: LanguageEntry, profile: AppProfile, onDismiss: () -> Unit, onSave: (LanguageEntry) -> Unit) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    var text by remember(entry.id) { mutableStateOf(entry.nativeText) }
    var dialect by remember(entry.id) { mutableStateOf(entry.dialect) }
    var audioPath by remember(entry.id) { mutableStateOf(entry.audioPath) }
    var recording by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) { recorder.start(); recording = true } }
    DisposableEffect(Unit) { onDispose { if (recording) recorder.cancel() } }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SurfaceTone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(20.dp).navigationBarsPadding()) {
            Text(entry.meaning, color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(13.dp))
            OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), label = { Text(entry.language.ifBlank { profile.speaks }) }, minLines = if (entry.type.ordinal >= BankType.CONVERSATION.ordinal) 3 else 1, maxLines = 8, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = dialect, onValueChange = { dialect = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Dialect (optional)") }, singleLine = true, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = {
                if (recording) { val (file, _) = recorder.stop(); recording = false; audioPath = file?.absolutePath }
                else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { recorder.start(); recording = true }
                else permission.launch(Manifest.permission.RECORD_AUDIO)
            }, shape = RoundedCornerShape(15.dp)) { Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) BeraCoral else Ink); Spacer(Modifier.width(6.dp)); Text(if (audioPath != entry.audioPath) "New voice saved" else if (recording) "Stop" else "Replace voice", color = Ink) }
            Spacer(Modifier.height(14.dp))
            Button(onClick = { onSave(entry.copy(nativeText = text.trim(), dialect = dialect.trim(), audioPath = audioPath, updatedAt = System.currentTimeMillis())) }, enabled = text.isNotBlank(), modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor), shape = RoundedCornerShape(17.dp)) { Text("Save changes", fontWeight = FontWeight.Black) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun R11ChatBankSheet(draft: BankDraft, profile: AppProfile, category: ContentCategory, onDismiss: () -> Unit, onSave: (LanguageEntry) -> Unit) {
    var type by remember { mutableStateOf(draft.type) }
    var nativeText by remember { mutableStateOf(draft.nativeText) }
    var meaning by remember { mutableStateOf(draft.meaning) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SurfaceTone, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(20.dp).navigationBarsPadding()) {
            Text("Add to bank", color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(11.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(BankType.entries) { option ->
                    Surface(color = if (type == option) ActionColor else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { type = option }) {
                        Text(option.label, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = if (type == option) OnActionColor else Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = nativeText, onValueChange = { nativeText = it }, modifier = Modifier.fillMaxWidth(), label = { Text(profile.speaks) }, minLines = if (type.ordinal >= BankType.CONVERSATION.ordinal) 3 else 1, maxLines = 8, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = meaning, onValueChange = { meaning = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("English meaning") }, minLines = if (type.ordinal >= BankType.CONVERSATION.ordinal) 2 else 1, maxLines = 6, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(13.dp))
            Button(onClick = { onSave(LanguageEntry(type = type, language = profile.speaks, nativeText = nativeText.trim(), meaning = meaning.trim(), dialect = profile.dialect, category = category.key, promptId = "chat:${System.currentTimeMillis()}", trackKey = CurriculumCatalog.trackKey(profile), audioPath = draft.audioPath, verified = true)) }, enabled = nativeText.isNotBlank() && meaning.isNotBlank(), modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor), shape = RoundedCornerShape(17.dp)) { Text("Save", fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
fun R11UsScreen(profile: AppProfile, entries: List<LanguageEntry>, photoUrl: String?, onSettings: () -> Unit, onSignOut: () -> Unit) {
    val active = CurriculumCatalog.activeCategory(entries, profile)
    val p = CurriculumCatalog.progress(entries, profile).first { it.category == active }
    LazyColumn(Modifier.fillMaxSize().background(Canvas).statusBarsPadding(), contentPadding = PaddingValues(20.dp, 24.dp, 20.dp, 34.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                R11ProfileAvatar(photoUrl, profile.displayName, size = 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(profile.displayName.ifBlank { "BeraTalk" }, color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("${profile.speaks} → ${profile.learning}", color = Muted)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Ink) }
            }
        }
        item {
            Surface(color = SurfaceTone, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
                Column(Modifier.padding(16.dp)) {
                    Text(active.label, color = Ink, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { p.fraction }, Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = BeraTeal, trackColor = Soft)
                    Spacer(Modifier.height(8.dp))
                    Text("${(p.fraction * 100).roundToInt()}% built", color = Muted, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        item {
            OutlinedButton(onClick = onSignOut, Modifier.fillMaxWidth().height(53.dp), shape = RoundedCornerShape(17.dp)) { Text("Sign out", color = Ink, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun R11QuickGameScreen(entries: List<LanguageEntry>, profile: AppProfile, onBack: () -> Unit) {
    val words = CurriculumCatalog.scopedEntries(profile, entries)
        .filter { it.verified && it.type == BankType.WORD && it.language.equals(profile.learning, true) && it.nativeText.isNotBlank() && it.meaning.isNotBlank() }
        .distinctBy { it.promptId.ifBlank { it.nativeText.lowercase() } }
    val questions = remember(words) { if (words.size >= 4) words.shuffled().take(5) else emptyList() }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var remaining by remember(index) { mutableIntStateOf(10) }
    var answered by remember(index) { mutableStateOf(false) }
    var selectedId by remember(index) { mutableStateOf<String?>(null) }
    val current = questions.getOrNull(index)
    val options = remember(current, words) {
        if (current == null) emptyList() else (listOf(current) + words.filter { it.id != current.id }.shuffled().take(3)).shuffled()
    }
    LaunchedEffect(index, current) {
        remaining = 10
        answered = false
        while (remaining > 0 && !answered && current != null) { delay(1000); remaining-- }
        if (!answered && current != null) { answered = true; delay(650); if (index < questions.lastIndex) index++ }
    }
    Column(Modifier.fillMaxSize().background(Canvas).statusBarsPadding().navigationBarsPadding().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
            Text("Quick review", Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text("$score/${questions.size}", color = Muted, fontWeight = FontWeight.Bold)
        }
        if (current == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Build at least 4 verified words first.", color = Muted) }
        } else {
            Spacer(Modifier.height(34.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${index + 1}/${questions.size}", color = Muted)
                Spacer(Modifier.weight(1f))
                Text("${remaining}s", color = if (remaining <= 3) BeraCoral else Ink, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(13.dp))
            Text("Which means", color = Muted, style = MaterialTheme.typography.bodyMedium)
            Text(current.meaning, color = Ink, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(26.dp))
            options.forEach { option ->
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(enabled = !answered) {
                        selectedId = option.id
                        answered = true
                        if (option.id == current.id) score++
                    },
                    color = when {
                        answered && option.id == current.id -> TealTint
                        answered && option.id == selectedId && option.id != current.id -> CoralTint
                        else -> SurfaceTone
                    },
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, when {
                        answered && option.id == current.id -> BeraTeal
                        answered && option.id == selectedId && option.id != current.id -> BeraCoral
                        else -> Border
                    }),
                    shadowElevation = 4.dp
                ) {
                    Text(option.nativeText, Modifier.padding(18.dp), color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
            if (answered) {
                Spacer(Modifier.height(14.dp))
                Button(onClick = { if (index < questions.lastIndex) index++ else onBack() }, Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor), shape = RoundedCornerShape(17.dp)) { Text(if (index == questions.lastIndex) "Finish" else "Next", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
fun R11SettingsScreen(
    profile: AppProfile,
    gateway: FirebaseGateway,
    uiTheme: BeraUiTheme,
    darkMode: Boolean,
    onUiThemeChange: (BeraUiTheme) -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onProfileChange: (AppProfile) -> Unit,
    onBack: () -> Unit,
    onAiSettingsChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { NotificationPreferences(context) }
    val secure = remember { SecureAiSettings(context) }
    var speaks by remember(profile) { mutableStateOf(profile.speaks) }
    var learning by remember(profile) { mutableStateOf(profile.learning) }
    var pairCode by remember { mutableStateOf<String?>(null) }
    var notifications by remember { mutableStateOf(prefs.enabled()) }
    var reminderHour by remember { mutableIntStateOf(prefs.reminderHour()) }
    var aiExpanded by remember { mutableStateOf(false) }
    var provider by remember { mutableStateOf(secure.snapshot().preferredProvider) }
    var geminiKey by remember { mutableStateOf(secure.snapshot().geminiApiKey) }
    var openAiKey by remember { mutableStateOf(secure.snapshot().openAiApiKey) }
    var status by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(profile.pairId) { pairCode = profile.pairId?.let { runCatching { gateway.getPairCode(it) }.getOrNull() } }

    LazyColumn(Modifier.fillMaxSize().background(Canvas).statusBarsPadding(), contentPadding = PaddingValues(18.dp, 12.dp, 18.dp, 36.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Ink) }
                Text("Settings", color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            }
        }
        item {
            R11SettingsCard("Appearance") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark mode", Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                    Switch(checked = darkMode, onCheckedChange = onDarkModeChange, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BeraTeal))
                }
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(BeraUiTheme.entries) { theme ->
                        val selected = uiTheme == theme
                        Surface(color = if (selected) ActionColor else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { onUiThemeChange(theme) }) {
                            Text(theme.label, Modifier.padding(horizontal = 13.dp, vertical = 8.dp), color = if (selected) OnActionColor else Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            R11SettingsCard("Languages") {
                OutlinedTextField(value = speaks, onValueChange = { speaks = it }, modifier = Modifier.fillMaxWidth(), label = { Text("I speak") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(9.dp))
                OutlinedTextField(value = learning, onValueChange = { learning = it }, modifier = Modifier.fillMaxWidth(), label = { Text("I'm learning") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(11.dp))
                Button(onClick = {
                    val next = profile.copy(speaks = speaks.trim(), learning = learning.trim())
                    scope.launch { runCatching { gateway.updateLanguages(next) }.onSuccess { onProfileChange(next); status = "Languages updated." }.onFailure { status = it.message } }
                }, enabled = speaks.isNotBlank() && learning.isNotBlank() && !speaks.equals(learning, true), colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor), shape = RoundedCornerShape(15.dp)) { Text("Save", fontWeight = FontWeight.Black) }
            }
        }
        item {
            R11SettingsCard("Pairing") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pairCode ?: "—", Modifier.weight(1f), color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    OutlinedButton(onClick = {
                        val id = profile.pairId ?: return@OutlinedButton
                        scope.launch { runCatching { gateway.regeneratePairCode(id) }.onSuccess { pairCode = it; status = "New pair code ready." }.onFailure { status = it.message } }
                    }, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Refresh, null, tint = Ink); Spacer(Modifier.width(5.dp)); Text("Regenerate", color = Ink, fontWeight = FontWeight.Bold) }
                }
            }
        }
        item {
            R11SettingsCard("Notifications") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily reminder", Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                    Switch(checked = notifications, onCheckedChange = {
                        notifications = it; prefs.setEnabled(it); BeraNotifications.scheduleDaily(context)
                    }, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BeraTeal))
                }
                if (notifications) {
                    Spacer(Modifier.height(11.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(8, 13, 19).forEach { hour ->
                            val selected = reminderHour == hour
                            Surface(color = if (selected) ActionColor else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { reminderHour = hour; prefs.setReminderHour(hour); BeraNotifications.scheduleDaily(context) }) {
                                Text("${hour.toString().padStart(2, '0')}:00", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = if (selected) OnActionColor else Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        item {
            R11SettingsCard("AI") {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { aiExpanded = !aiExpanded }) {
                    Text(provider.name.lowercase().replaceFirstChar { it.uppercase() }, Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.MoreHoriz, null, tint = Muted)
                }
                AnimatedVisibility(aiExpanded) {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf(AiProvider.AUTO, AiProvider.GEMINI, AiProvider.OPENAI).forEach { option ->
                                val selected = provider == option
                                Surface(color = if (selected) ActionColor else Soft, shape = RoundedCornerShape(999.dp), modifier = Modifier.clickable { provider = option; secure.setPreferredProvider(option); onAiSettingsChanged() }) {
                                    Text(option.name.lowercase().replaceFirstChar { it.uppercase() }, Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = if (selected) OnActionColor else Ink, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini key") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = openAiKey, onValueChange = { openAiKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OpenAI key") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { secure.setGemini(geminiKey, secure.snapshot().geminiModel); secure.setOpenAi(openAiKey, secure.snapshot().openAiModel); onAiSettingsChanged(); status = "AI settings saved." }, colors = ButtonDefaults.buttonColors(containerColor = ActionColor, contentColor = OnActionColor), shape = RoundedCornerShape(15.dp)) { Text("Save", fontWeight = FontWeight.Black) }
                    }
                }
            }
        }
        status?.let { text -> item { Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium) } }
    }
}

@Composable
private fun R11SettingsCard(title: String, content: @Composable () -> Unit) {
    Surface(color = SurfaceTone, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), shadowElevation = 4.dp) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

private fun currentGreetingR11(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening" }
}

private fun formatSecondsR11(seconds: Int): String = "%d:%02d".format(seconds / 60, seconds % 60)
