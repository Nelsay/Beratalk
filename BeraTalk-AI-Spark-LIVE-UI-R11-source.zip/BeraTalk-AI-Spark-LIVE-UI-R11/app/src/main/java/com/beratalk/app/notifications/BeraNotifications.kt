package com.beratalk.app.notifications

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.beratalk.app.MainActivity
import com.beratalk.app.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.util.Calendar

class NotificationPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("beratalk_notifications", Context.MODE_PRIVATE)
    fun enabled(): Boolean = prefs.getBoolean("enabled", true)
    fun reminderHour(): Int = prefs.getInt("hour", 19)
    fun setEnabled(value: Boolean) { prefs.edit().putBoolean("enabled", value).apply() }
    fun setReminderHour(value: Int) { prefs.edit().putInt("hour", value.coerceIn(0, 23)).apply() }
}

object BeraNotifications {
    const val DAILY_CHANNEL = "beratalk_daily"
    const val PARTNER_CHANNEL = "beratalk_partner"
    private const val DAILY_REQUEST = 4401

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                DAILY_CHANNEL,
                "Daily learning",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Daily conversation, bank and review reminders" }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                PARTNER_CHANNEL,
                "Partner activity",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "New partner messages and shared language activity" }
        )
    }

    fun scheduleDaily(context: Context) {
        val prefs = NotificationPreferences(context)
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            DAILY_REQUEST,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pending)
        if (!prefs.enabled()) return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.reminderHour())
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    }

    fun showDaily(context: Context) {
        if (!canNotify(context)) return
        createChannels(context)
        val open = PendingIntent.getActivity(
            context,
            5401,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, DAILY_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Your BeraTalk is ready")
            .setContentText("Today's conversation, bank task and quick review are waiting.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        NotificationManagerCompat.from(context).notify(5401, notification)
    }

    fun showPartner(context: Context, title: String = "New BeraTalk message", body: String = "Your partner added something to the conversation.") {
        if (!canNotify(context)) return
        createChannels(context)
        val open = PendingIntent.getActivity(
            context,
            5402,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, PARTNER_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (NotificationPreferences(context).enabled()) BeraNotifications.showDaily(context)
        BeraNotifications.scheduleDaily(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        BeraNotifications.createChannels(context)
        BeraNotifications.scheduleDaily(context)
    }
}

class BeraMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("users").document(uid)
            .update("fcmTokens", FieldValue.arrayUnion(token))
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "BeraTalk"
        val body = message.notification?.body ?: message.data["body"] ?: "You have new activity."
        BeraNotifications.showPartner(this, title, body)
    }
}
