package com.beratalk.app.model

import java.util.UUID

enum class BankType(val label: String, val threshold: Int) {
    WORD("Words", 50),
    SENTENCE("Sentences", 25),
    CONVERSATION("Conversations", 10),
    STORY("Stories", 3)
}

enum class ContentCategory(val key: String, val label: String) {
    EVERYDAY("everyday", "Everyday & survival"),
    FAMILY("family", "Family"),
    HOME("home", "Home"),
    MARKET_FOOD("market_food", "Market & food"),
    SCHOOL_WORK("school_work", "School & work"),
    TRAVEL("travel", "Travel"),
    RELATIONSHIPS("relationships", "Relationships"),
    HEALTH("health", "Health & safety"),
    CULTURE("culture", "Culture & community");

    companion object {
        fun fromKey(value: String?): ContentCategory = entries.firstOrNull { it.key == value } ?: EVERYDAY
    }
}

enum class LessonTaskType { LISTEN, RECALL, SPEAK, CONVERSATION, ASK_PARTNER }

enum class ChatMessageKind { TEXT, VOICE }

data class BankPrompt(
    val id: String,
    val english: String
)

data class BankTask(
    val category: ContentCategory,
    val type: BankType,
    val prompts: List<BankPrompt>,
    val completedToday: Int = 0,
    val targetToday: Int = 5
)

data class CategoryProgress(
    val category: ContentCategory,
    val wordCount: Int = 0,
    val sentenceCount: Int = 0,
    val conversationCount: Int = 0,
    val storyCount: Int = 0,
    val unlocked: Boolean = false
) {
    val complete: Boolean
        get() = wordCount >= BankType.WORD.threshold &&
            sentenceCount >= BankType.SENTENCE.threshold &&
            conversationCount >= BankType.CONVERSATION.threshold &&
            storyCount >= BankType.STORY.threshold

    val fraction: Float
        get() {
            val stages = listOf(
                (wordCount.toFloat() / BankType.WORD.threshold).coerceIn(0f, 1f),
                (sentenceCount.toFloat() / BankType.SENTENCE.threshold).coerceIn(0f, 1f),
                (conversationCount.toFloat() / BankType.CONVERSATION.threshold).coerceIn(0f, 1f),
                (storyCount.toFloat() / BankType.STORY.threshold).coerceIn(0f, 1f)
            )
            return stages.average().toFloat()
        }
}

data class LanguageEntry(
    val id: String = UUID.randomUUID().toString(),
    val type: BankType = BankType.WORD,
    val language: String = "",
    val nativeText: String = "",
    val meaning: String = "",
    val notes: String = "",
    val dialect: String = "",
    val category: String = ContentCategory.EVERYDAY.key,
    val promptId: String = "",
    val contributorId: String = "",
    val trackKey: String = "",
    val audioPath: String? = null,
    val verified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** Legacy voice model retained for old screen compatibility. New runtime uses ChatMessage. */
data class VoiceMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String = "me",
    val localAudioPath: String,
    val durationMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val correctionFor: String? = null
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String = "me",
    val kind: ChatMessageKind = ChatMessageKind.TEXT,
    val text: String = "",
    val audioPath: String? = null,
    val durationMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val correctionFor: String? = null,
    val dailyLineId: String? = null
)

data class DailyConversation(
    val id: String,
    val dateKey: String,
    val category: String,
    val title: String,
    val situation: String,
    val lines: List<String>,
    val source: String = "local",
    val createdAt: Long = System.currentTimeMillis()
)

data class LessonTask(
    val id: String = UUID.randomUUID().toString(),
    val type: LessonTaskType,
    val title: String,
    val instruction: String,
    val entryId: String? = null,
    val durationSeconds: Int = 0
)

data class CoachChallenge(
    val title: String = "Keep the conversation moving",
    val instruction: String = "Use one verified phrase, then ask your partner a natural follow-up question.",
    val durationSeconds: Int = 60,
    val entryId: String? = null,
    val source: String = "local"
)

data class CoachNudge(
    val headline: String,
    val message: String,
    val source: String = "local"
)

data class Mission(
    val id: String,
    val title: String,
    val subtitle: String,
    val minutes: Int,
    val progress: Float = 0f,
    val steps: List<String> = emptyList(),
    val tasks: List<LessonTask> = emptyList(),
    val coachMessage: String = "",
    val source: String = "local"
) {
    val effectiveTasks: List<LessonTask>
        get() = if (tasks.isNotEmpty()) tasks else steps.mapIndexed { index, text ->
            LessonTask(
                id = "legacy-$index",
                type = if (index == steps.lastIndex) LessonTaskType.CONVERSATION else LessonTaskType.SPEAK,
                title = text,
                instruction = "Complete this step using real partner language."
            )
        }
}

data class LearningSession(
    val mission: Mission,
    val completedTaskIds: Set<String> = emptySet(),
    val reviewNotes: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val progress: Float
        get() = if (mission.effectiveTasks.isEmpty()) 0f else completedTaskIds.size.toFloat() / mission.effectiveTasks.size.toFloat()
}

data class AppProfile(
    val displayName: String = "",
    val speaks: String = "",
    val learning: String = "",
    val dialect: String = "",
    val dailyMinutes: Int = 10,
    val partnerName: String = "Partner",
    val pairId: String? = null
)
