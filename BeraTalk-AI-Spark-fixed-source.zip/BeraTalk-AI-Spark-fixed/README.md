# BeraTalk Android

BeraTalk is a private two-person, voice-first language-learning app. One partner teaches the language they naturally speak; BeraTalk structures practice into real conversations and reusable language banks.

## Current build
- Kotlin + Jetpack Compose
- Package: `com.beratalk.app`
- compileSdk 36 / targetSdk 36 / minSdk 26
- Signed release identity included for private update continuity
- Firebase project wired through `app/google-services.json`
- Email/password + Google authentication
- Two-person pair creation/joining
- Voice messages with no forced transcription
- Slow replay and pronunciation correction flow
- Word, Sentence, Conversation, Story banks
- Native audio attached to bank entries
- Dual AI lesson engine: Gemini + OpenAI, selectable from Settings
- API keys are entered at runtime and encrypted locally with Android Keystore
- Auto mode uses Gemini first with OpenAI fallback
- AI lesson engine uses verified bank content and never invents minority-language translations
- Portable language-pack ZIP export
- Firestore security rules, including private chunked-audio rules

## Main navigation
Home · Learn · Chat · Library · Us

## AI settings
Open **Us → Settings** to add/test Gemini and OpenAI keys, choose Auto/Gemini/OpenAI, and edit model IDs. See `AI_SETUP.md`.

## Release build
The included GitHub Actions workflow builds the signed APK:
`.github/workflows/build-signed-apk.yml`

It installs Android SDK 36, Build Tools 36.0.0 and Gradle 9.6.0, then runs:
`gradle :app:assembleRelease`

Output:
`app/build/outputs/apk/release/app-release.apk`

## Signing
Do not lose `signing/beratalk-release.jks`. Future releases must use the same package name and key to update the installed app.

## Spark plan audio mode

BeraTalk does not require Firebase Cloud Storage in this build. Voice notes, pronunciation clips and corrections are compressed as speech audio, split into small chunks and stored as private Cloud Firestore byte documents under the two-person pair. Playback reconstructs each clip into the app cache. Language-pack export resolves those clips locally before creating the ZIP.

This mode is intentionally for the private/early stage. Firestore's free quota is finite, so when BeraTalk expands to many users the audio layer should move to an object store while preserving the same `audioPath` abstraction.
