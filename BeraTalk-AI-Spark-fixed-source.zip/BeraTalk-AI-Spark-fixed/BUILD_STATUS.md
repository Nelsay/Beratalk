# BeraTalk build status — Spark + dual AI edition

- Firebase project wired through `app/google-services.json`
- Android package: `com.beratalk.app`
- Version: `1.0.2-ai` (`versionCode 3`)
- Email/password auth: wired
- Google Sign-In: wired
- Firestore: wired
- Firebase Cloud Storage: **not used**
- Voice notes: compressed speech audio stored as private chunked Firestore byte documents
- Gemini API: direct private-app integration via runtime Settings key
- OpenAI Responses API: direct private-app integration via runtime Settings key
- AI modes: Auto / Gemini / OpenAI
- AI key storage: encrypted locally with Android Keystore; excluded from backup
- AI connection testing: wired in Settings
- AI lesson engine: live provider call with safe local fallback
- Minority-language rule: AI may organize verified content but may not invent target-language translations
- Release keystore: retained for update continuity

The source is build-ready. This execution environment still lacks the Android SDK/Gradle Android build toolchain required to emit the APK binary locally; the included GitHub workflow performs the signed release build in an Android-capable runner.
