# BeraTalk UI QA — 2026-09-08

## Visual system
- Screen horizontal padding: 20dp across main flows.
- Primary section spacing: 16–18dp.
- Primary action height: 58dp.
- Primary card radius: 22–28dp; supporting surfaces use 16–22dp.
- Shadows are restrained: 1dp on supporting cards, stronger elevation only on the daily mission.
- Home statistics are grouped into one shared strip rather than three competing cards.
- Bright brand teal/orange/coral are used for fills, progress, and emphasis; deep variants are used for readable text/icons on light surfaces.

## Contrast audit
WCAG contrast calculations against white:
- Ink #111315: 18.62:1
- Muted #626970: 5.56:1
- Deep teal #00695C: 6.61:1
- Deep orange #A84600: 5.93:1
- Deep coral #A92E25: 6.76:1

Dark Ink against bright fills:
- Ink on bright teal #05D6B4: 10.01:1
- Ink on bright orange #FF8A00: 7.88:1
- Ink on bright coral #FF5547: 5.89:1

This is why bright orange/teal buttons/chips use dark foregrounds rather than white.

## Interaction polish
- Auth/logo subtle breathing animation.
- Animated auth/setup transitions.
- Crossfade bottom-tab transitions.
- Daily mission press scale feedback.
- Animated lesson state/background changes.
- Recording pulse + live duration.
- Functional slow playback for partner audio.
- Functional pronunciation-correction recording state.
- Actual bank audio playback when a recording exists.

## Static validation completed here
- Firebase package name matches `com.beratalk.app`.
- Firebase Android OAuth certificate hash matches the release keystore SHA-1.
- 10 Android XML files parse successfully.
- Kotlin source parser scan found no syntax-level errors.
- Core local lesson engine was JVM-compiled successfully during development.

## Binary build environment limitation
This execution environment does not contain Gradle or Android SDK build tools (`sdkmanager`, `aapt2`, `d8`), and outbound binary downloads are unavailable. The checked-in GitHub Actions workflow installs Android SDK 36, Build Tools 36.0.0, Gradle 9.6.0, then runs the signed release build.
